<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../user/login.php');
    exit;
}

require_once '../config/database.php';

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$status = trim($_GET['status'] ?? '');

$fromSafe = mysqli_real_escape_string($conn, $from);
$toSafe = mysqli_real_escape_string($conn, $to);
$statusSafe = mysqli_real_escape_string($conn, $status);

$where = "WHERE DATE(o.created_at) BETWEEN '$fromSafe' AND '$toSafe'";

if ($status === 'Processing') {
    $where .= " AND LOWER(o.status) = 'processing'";
} elseif ($status === 'Shipped') {
    $where .= " AND LOWER(o.status) = 'shipped'";
} elseif ($status === 'Completed') {
    $where .= " AND LOWER(o.status) = 'completed'";
}

// Ambil transaction_code untuk laporan.
$sql = "SELECT
            o.id,
            o.transaction_code,
            o.recipient_name,
            o.total_price,
            o.status,
            o.payment_method,
            o.created_at,
            u.fullname,
            COALESCE(SUM(od.quantity), 0) total_items,
            SUM(CASE WHEN od.cost_price IS NULL THEN 1 ELSE 0 END) missing_cost_items,
            SUM((od.price - od.cost_price) * od.quantity) profit
        FROM orders o
        LEFT JOIN users u ON u.id = o.user_id
        LEFT JOIN order_details od ON od.order_id = o.id
        $where
        GROUP BY
            o.id,
            o.recipient_name,
            o.total_price,
            o.status,
            o.payment_method,
            o.created_at,
            u.fullname
        ORDER BY o.created_at DESC";

$result = mysqli_query($conn, $sql);

$rows = [];
$revenue = 0;
$items = 0;
$totalProfit = 0;
$profitReady = true;

if ($result) {
    while ($r = mysqli_fetch_assoc($result)) {
        $rows[] = $r;

        if (strtolower($r['status']) !== 'cancelled') {
            $revenue += (float) $r['total_price'];
        }

        $items += (int) $r['total_items'];

        if ((int) $r['missing_cost_items'] > 0) {
            $profitReady = false;
        } else {
            $totalProfit += (float) $r['profit'];
        }
    }
}

// Ekspor CSV.
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="laporan-linglungbooks-' . date('Ymd') . '.csv"');

    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));

    fputcsv($out, [
        'Kode Transaksi',
        'Pelanggan',
        'Jumlah Item',
        'Total Penjualan',
        'Keuntungan',
        'Status',
        'Pembayaran',
        'Tanggal'
    ]);

    foreach ($rows as $r) {
        fputcsv($out, [
            ($r['transaction_code'] ?: $r['id']),
            $r['fullname'] ?: $r['recipient_name'],
            $r['total_items'],
            $r['total_price'],
            ((int) $r['missing_cost_items'] > 0 ? 'Belum diatur' : $r['profit']),
            (strtolower($r['status']) === 'completed'
                ? 'Selesai'
                : (strtolower($r['status']) === 'shipped' ? 'Dikirim' : 'Diproses')),
            $r['payment_method'],
            $r['created_at']
        ]);
    }

    fclose($out);
    exit;
}

function h($v) {
    return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <link rel="stylesheet" href="../assets/css/admin-unified.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laporan Transaksi | LinglungBooks</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">

    <style>
        body {
            font-family: Poppins, sans-serif;
        }

        .main {
            padding: 32px;
        }

        .report-head {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 16px;
            flex-wrap: wrap;
            margin-bottom: 24px;
        }

        .report-filters,
        .report-stat,
        .report-table-wrap {
            background: #fff;
            border-radius: 16px;
            padding: 20px;
            box-shadow: 0 8px 24px #4b362110;
            margin-bottom: 20px;
        }

        .report-filters form {
            display: flex;
            gap: 12px;
            align-items: end;
            flex-wrap: wrap;
        }

        .report-filters label {
            display: grid;
            gap: 6px;
            font-size: 13px;
        }

        .report-filters input,
        .report-filters select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        .report-btn {
            border: 0;
            background: #6f4e37;
            color: #fff;
            padding: 11px 16px;
            border-radius: 9px;
            text-decoration: none;
            cursor: pointer;
            font-weight: 600;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 16px;
        }

        .report-stat small {
            color: #777;
        }

        .report-stat strong {
            display: block;
            font-size: 24px;
            color: #6f4e37;
            margin-top: 7px;
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
        }

        .report-table th,
        .report-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            text-align: left;
            font-size: 13px;
        }

        .report-table th {
            background: #f8f3ec;
        }

        .status {
            padding: 5px 9px;
            border-radius: 20px;
            background: #f3e8d8;
            white-space: nowrap;
        }

        @media (max-width: 800px) {
            .main {
                padding: 18px;
            }

            .stats {
                grid-template-columns: 1fr;
            }

            .report-table-wrap {
                overflow: auto;
            }
        }
    </style>
</head>

<body>

<?php include __DIR__ . '/sidebar.php'; ?>

<main class="main">

    <div class="report-head">
        <div>
            <h1>Laporan Transaksi</h1>
            <p>Ringkasan pesanan berdasarkan data transaksi yang sudah ada.</p>
        </div>

        <button class="report-btn no-print" onclick="window.print()">
            <i class="fa-solid fa-print"></i> Cetak Laporan
        </button>
    </div>

    <section class="report-filters no-print">
        <form method="get" id="reportFilterForm">

            <label>
                Dari tanggal
                <input type="date" name="from" value="<?= h($from) ?>">
            </label>

            <label>
                Sampai tanggal
                <input type="date" name="to" value="<?= h($to) ?>">
            </label>

            <label>
                Status
                <select name="status">
                    <option value="">Semua status</option>

                    <?php foreach (['Processing', 'Shipped', 'Completed'] as $st): ?>
                        <option value="<?= h($st) ?>" <?= $status === $st ? 'selected' : '' ?>>
                            <?= $st === 'Processing'
                                ? 'Diproses'
                                : ($st === 'Shipped' ? 'Dikirim' : 'Selesai') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>

            <a class="report-btn" href="?<?= h(http_build_query([
                'from' => $from,
                'to' => $to,
                'status' => $status,
                'export' => 'csv'
            ])) ?>">
                <i class="fa-solid fa-file-csv"></i> Export CSV
            </a>

        </form>
    </section>

    <div class="stats">

        <div class="report-stat">
            <small>Total pesanan</small>
            <strong><?= count($rows) ?></strong>
        </div>

        <div class="report-stat">
            <small>Item terjual</small>
            <strong><?= number_format($items) ?></strong>
        </div>

        <div class="report-stat">
            <small>Omzet (tidak termasuk dibatalkan)</small>
            <strong>Rp <?= number_format($revenue, 0, ',', '.') ?></strong>
        </div>
</div>

    <section class="report-table-wrap">
        <h3>Rincian Pesanan</h3>

        <div style="overflow:auto">
            <table class="report-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Pelanggan</th>
                        <th>Item</th>
                        <th>Total Penjualan</th>
                        <th>Keuntungan</th>
                        <th>Status</th>
                        <th>Pembayaran</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if ($rows): ?>
                        <?php foreach ($rows as $r): ?>
                            <tr>
                                <td>#<?= h($r['transaction_code'] ?: $r['id']) ?></td>

                                <td><?= h($r['fullname'] ?: $r['recipient_name']) ?></td>

                                <td><?= h($r['total_items']) ?></td>

                                <td>
                                    Rp <?= number_format((float) $r['total_price'], 0, ',', '.') ?>
                                </td>

                                <td>
                                    <?= (int) $r['missing_cost_items'] > 0
                                        ? 'Belum diatur'
                                        : 'Rp ' . number_format((float) $r['profit'], 0, ',', '.') ?>
                                </td>

                                <td>
                                    <span class="status">
                                        <?= strtolower($r['status']) === 'completed'
                                            ? 'Selesai'
                                            : (strtolower($r['status']) === 'shipped'
                                                ? 'Dikirim'
                                                : 'Diproses') ?>
                                    </span>
                                </td>

                                <td><?= h($r['payment_method']) ?></td>

                                <td><?= h($r['created_at']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" style="text-align:center;padding:28px">
                                Tidak ada transaksi pada periode ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</main>

<script>
document.querySelectorAll(
    '#reportFilterForm input, #reportFilterForm select'
).forEach(function (field) {
    field.addEventListener('change', function () {
        document.getElementById('reportFilterForm').requestSubmit();
    });
});
</script>

<script src="../assets/js/enhancements.js"></script>

</body>
</html>