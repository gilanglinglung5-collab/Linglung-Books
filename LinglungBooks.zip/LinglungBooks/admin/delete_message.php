<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}


include '../config/database.php';


if(isset($_GET['id'])){


$id = $_GET['id'];


mysqli_query($conn,"
DELETE FROM messages
WHERE id='$id'
");


}


header("Location: messages.php");
exit;


?>