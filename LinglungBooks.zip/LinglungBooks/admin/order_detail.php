<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


/*
|--------------------------------------------------------------------------
| CEK ORDER ID
|--------------------------------------------------------------------------
*/

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = (int) $_GET['id'];


/*
|--------------------------------------------------------------------------
| VERIFIKASI PEMBAYARAN (ADMIN)
| Admin hanya memeriksa bukti; tidak dapat menyelesaikan pesanan.
|--------------------------------------------------------------------------
*/
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$verification_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_payment'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    $decision = $_POST['verification_decision'] ?? '';
    $note = trim($_POST['verification_note'] ?? '');

    if (!hash_equals($_SESSION['csrf_token'], $csrf)) {
        $verification_message = 'Sesi keamanan tidak valid. Muat ulang halaman.';
    } elseif (!in_array($decision, ['approved', 'rejected'], true)) {
        $verification_message = 'Pilihan verifikasi tidak valid.';
    } else {
        $stmt = mysqli_prepare($conn, "
            UPDATE orders
            SET payment_verification = ?,
                status = CASE WHEN ? = 'approved' THEN 'Packed' ELSE status END,
                verification_note = ?,
                verified_at = NOW()
            WHERE id = ?
              AND payment_method <> 'COD'
              AND payment_proof IS NOT NULL
              AND payment_proof <> ''
              AND payment_verification IN ('pending', 'rejected')
        ");
        mysqli_stmt_bind_param($stmt, 'sssi', $decision, $decision, $note, $order_id);
        mysqli_stmt_execute($stmt);
        $updated = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);
        $verification_message = $updated > 0
            ? ($decision === 'approved' ? 'Bukti pembayaran disetujui. Status pesanan berubah menjadi Dikemas.' : 'Bukti pembayaran ditolak. User dapat mengirim bukti baru.')
            : 'Verifikasi tidak dapat dilakukan. Pastikan bukti tersedia dan status masih menunggu.';
    }
}

// Perubahan status pengiriman dan keputusan retur/refund oleh admin.
$workflow_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_order_action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    $action = $_POST['admin_order_action'];
    $note = trim($_POST['return_admin_note'] ?? '');
    if (!hash_equals($_SESSION['csrf_token'], $csrf)) $workflow_message = 'Sesi keamanan tidak valid.';
    else {
        if ($action === 'ship_order') {
            $q=mysqli_prepare($conn,"UPDATE orders SET status='Shipped' WHERE id=? AND status='Packed' AND payment_verification='approved'"); mysqli_stmt_bind_param($q,'i',$order_id);
        } elseif ($action === 'approve_return') {
            $q=mysqli_prepare($conn,"UPDATE orders SET status='ReturnApproved', return_status='approved', return_admin_note=? WHERE id=? AND status='ReturnRequested'"); mysqli_stmt_bind_param($q,'si',$note,$order_id);
        } elseif ($action === 'reject_return') {
            $q=mysqli_prepare($conn,"UPDATE orders SET status='ReturnRejected', return_status='rejected', return_admin_note=? WHERE id=? AND status='ReturnRequested'"); mysqli_stmt_bind_param($q,'si',$note,$order_id);
        } elseif ($action === 'receive_return') {
            $q=mysqli_prepare($conn,"UPDATE orders SET status='Returned', return_status='received', return_received_at=NOW(), refund_status='pending' WHERE id=? AND status='ReturnShipped'"); mysqli_stmt_bind_param($q,'i',$order_id);
        } elseif ($action === 'refund_done') {
            $q=mysqli_prepare($conn,"UPDATE orders SET status='Refunded', refund_status='completed', refund_note=? WHERE id=? AND status='Returned' AND refund_status='pending'"); mysqli_stmt_bind_param($q,'si',$note,$order_id);
        } else $q=null;
        if ($q) { mysqli_stmt_execute($q); $ok=mysqli_stmt_affected_rows($q)>0; mysqli_stmt_close($q); $workflow_message=$ok?'Perubahan status berhasil disimpan.':'Aksi tidak sesuai dengan status pesanan saat ini.'; }
    }
}

/*
|--------------------------------------------------------------------------
| AMBIL DATA ORDER
|--------------------------------------------------------------------------
*/

$orderQuery = mysqli_query($conn, "
    SELECT
        orders.*,
        users.fullname,
        users.username,
        users.email
    FROM orders

    LEFT JOIN users
        ON orders.user_id = users.id

    WHERE orders.id = '$order_id'

    LIMIT 1
");


if (!$orderQuery || mysqli_num_rows($orderQuery) === 0) {

    die("Order tidak ditemukan.");
}


$order = mysqli_fetch_assoc($orderQuery);


/*
|--------------------------------------------------------------------------
| AMBIL DETAIL ORDER
|--------------------------------------------------------------------------
*/

$detailQuery = mysqli_query($conn, "
    SELECT
        order_details.*,
        books.title,
        books.author,
        books.cover
    FROM order_details

    LEFT JOIN books
        ON order_details.book_id = books.id

    WHERE order_details.order_id = '$order_id'

    ORDER BY order_details.id ASC
");


/*
|--------------------------------------------------------------------------
| HITUNG JUMLAH ITEM
|--------------------------------------------------------------------------
*/

$total_items = 0;
$total_profit = 0;
$profit_ready = true;
$detail_items = [];

if ($detailQuery) {

    while ($item = mysqli_fetch_assoc($detailQuery)) {

        $total_items += (int) $item['quantity'];
        if (!array_key_exists('cost_price', $item) || $item['cost_price'] === null) { $profit_ready = false; } else { $total_profit += (((float)$item['price'] - (float)$item['cost_price']) * (int)$item['quantity']); }

        $detail_items[] = $item;
    }
}


/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

$status = strtolower(trim($order['status'] ?? ''));

$status_class = in_array($status, ['completed','refunded'], true) ? 'completed' : (in_array($status, ['shipped','returnshipped'], true) ? 'shipped' : 'processing');
$status_label = ['processing'=>'Diproses','packed'=>'Dikemas','shipped'=>'Dikirim','received'=>'Diterima','completed'=>'Selesai','returnrequested'=>'Retur Menunggu','returnapproved'=>'Retur Disetujui','returnrejected'=>'Retur Ditolak','returnshipped'=>'Retur Dikirim','returned'=>'Retur Tiba di Gudang','refunded'=>'Dana Dikembalikan','cancelled'=>'Dibatalkan'][$status] ?? ucfirst($status);


/*
|--------------------------------------------------------------------------
| PAYMENT PROOF
|--------------------------------------------------------------------------
*/

$has_payment_proof = !empty($order['payment_proof']);


/*
|--------------------------------------------------------------------------
| FORMAT TANGGAL
|--------------------------------------------------------------------------
*/

$order_date = '-';

if (!empty($order['created_at'])) {

    $timestamp = strtotime($order['created_at']);

    if ($timestamp !== false) {

        $order_date = date(
            'd M Y, H:i',
            $timestamp
        );
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Order #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order_id, ENT_QUOTES, 'UTF-8'); ?> | LinglungBooks
</title>


<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
    rel="stylesheet"
>


<style>

/* =====================================================
   RESET
===================================================== */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    background: #F8F3EC;
    color: #3E2C23;
}


/* =====================================================
   CONTAINER
===================================================== */

.container {
    width: 94%;
    max-width: 1250px;
    margin: 35px auto 60px;
}


/* =====================================================
   HEADER
===================================================== */

.header {
    background: white;
    padding: 24px 28px;
    border-radius: 18px;
    box-shadow: 0 8px 25px rgba(0,0,0,.07);

    display: flex;
    justify-content: space-between;
    align-items: center;

    gap: 20px;

    margin-bottom: 25px;
}

.header-left {
    min-width: 0;
}

.header-title {
    color: #5A3825;
    font-size: 28px;
    font-weight: 700;
}

.header-subtitle {
    color: #888;
    font-size: 13px;
    margin-top: 4px;
}

.btn-back {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    text-decoration: none;

    background: #6F4E37;
    color: white;

    padding: 11px 19px;

    border-radius: 10px;

    font-size: 14px;
    font-weight: 500;

    white-space: nowrap;

    transition: .2s;
}

.btn-back:hover {
    background: #8B5E3C;
}


/* =====================================================
   GRID
===================================================== */

.top-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 22px;

    margin-bottom: 22px;
}


/* =====================================================
   CARD
===================================================== */

.card {
    background: white;
    border-radius: 18px;
    padding: 26px;

    box-shadow: 0 8px 25px rgba(0,0,0,.07);
}

.card-title {
    color: #5A3825;
    font-size: 20px;
    font-weight: 700;

    margin-bottom: 20px;

    display: flex;
    align-items: center;
    gap: 10px;
}


/* =====================================================
   INFO ROW
===================================================== */

.info-list {
    width: 100%;
}

.info-row {
    display: grid;
    grid-template-columns: 170px minmax(0, 1fr);

    gap: 15px;

    padding: 13px 0;

    border-bottom: 1px solid #eee;
}

.info-row:last-child {
    border-bottom: none;
}

.info-label {
    color: #6F4E37;
    font-size: 13px;
    font-weight: 600;
}

.info-value {
    color: #3E2C23;
    font-size: 14px;

    min-width: 0;

    word-break: break-word;
}


/* =====================================================
   STATUS
===================================================== */

.status {
    display: inline-flex;
    align-items: center;

    padding: 7px 14px;

    border-radius: 20px;

    font-size: 12px;
    font-weight: 600;
}

.status.pending {
    background: #FFF3CD;
    color: #856404;
}

.status.paid {
    background: #D4EDDA;
    color: #155724;
}

.status.processing {
    background: #DDEBFF;
    color: #28527A;
}

.status.shipped {
    background: #E8DDF8;
    color: #5B3A82;
}

.status.completed {
    background: #D8F0E0;
    color: #27643A;
}

.status.cancelled {
    background: #F8D7DA;
    color: #721C24;
}


/* =====================================================
   STATUS FORM
===================================================== */

.status-form {
    margin-top: 22px;

    padding-top: 20px;

    border-top: 1px solid #eee;
}

.status-form label {
    display: block;

    font-size: 13px;
    font-weight: 600;

    color: #6F4E37;

    margin-bottom: 9px;
}

.status-controls {
    display: flex;
    gap: 10px;
}

.status-select {
    flex: 1;

    min-width: 0;

    padding: 11px 13px;

    border: 1px solid #DDD0C3;
    border-radius: 10px;

    background: #FAF7F2;

    font-family: 'Poppins', sans-serif;
    font-size: 13px;

    color: #3E2C23;

    outline: none;
}

.status-select:focus {
    border-color: #8B5E3C;
}

.btn-save {
    border: none;

    padding: 11px 18px;

    border-radius: 10px;

    background: #6F4E37;
    color: white;

    font-family: 'Poppins', sans-serif;
    font-size: 13px;
    font-weight: 600;

    cursor: pointer;

    white-space: nowrap;
}

.btn-save:hover {
    background: #8B5E3C;
}


/* =====================================================
   PAYMENT
===================================================== */

.payment-method {
    display: inline-block;

    padding: 7px 13px;

    border-radius: 9px;

    background: #F3E8D8;

    color: #6F4E37;

    font-size: 13px;
    font-weight: 600;
}


/* =====================================================
   PAYMENT PROOF
===================================================== */

.proof-box {
    margin-top: 20px;

    padding-top: 20px;

    border-top: 1px solid #eee;
}

.proof-title {
    font-size: 14px;
    font-weight: 600;

    color: #6F4E37;

    margin-bottom: 12px;
}

.proof-preview {
    width: 100%;
    max-height: 450px;

    object-fit: contain;

    background: #FAF7F2;

    border: 1px solid #E6D9CC;

    border-radius: 12px;

    padding: 8px;

    display: block;
}

.proof-empty {
    padding: 20px;

    background: #FAF7F2;

    border-radius: 10px;

    color: #888;

    font-size: 13px;

    text-align: center;
}

.btn-proof {
    display: inline-block;

    margin-top: 12px;

    padding: 9px 15px;

    border-radius: 9px;

    background: #6F4E37;

    color: white;

    text-decoration: none;

    font-size: 12px;
}

.btn-proof:hover {
    background: #8B5E3C;
}


/* =====================================================
   ORDER ITEMS
===================================================== */

.items-card {
    background: white;

    border-radius: 18px;

    box-shadow: 0 8px 25px rgba(0,0,0,.07);

    overflow: hidden;

    margin-bottom: 22px;
}

.items-header {
    padding: 25px 28px 20px;
}

.items-header h2 {
    color: #5A3825;
    font-size: 20px;
}

.items-header p {
    color: #888;
    font-size: 13px;
    margin-top: 4px;
}


/* =====================================================
   TABLE WRAPPER
===================================================== */

.table-wrapper {
    width: 100%;

    overflow-x: auto;
}


/* =====================================================
   TABLE
===================================================== */

.order-table {
    width: 100%;

    border-collapse: collapse;

    table-layout: fixed;

    min-width: 850px;
}


/*
   Kolom dibuat tetap supaya nama pendek/panjang
   tidak membuat baris terlihat berantakan.
*/

.order-table col.cover-col {
    width: 100px;
}

.order-table col.book-col {
    width: 28%;
}

.order-table col.author-col {
    width: 20%;
}

.order-table col.price-col {
    width: 15%;
}

.order-table col.qty-col {
    width: 9%;
}

.order-table col.subtotal-col {
    width: 18%;
}


.order-table th {
    background: #6F4E37;

    color: white;

    padding: 15px 14px;

    font-size: 12px;
    font-weight: 600;

    text-align: center;

    white-space: nowrap;
}


.order-table td {
    padding: 15px 14px;

    border-bottom: 1px solid #eee;

    vertical-align: middle;

    font-size: 13px;

    text-align: center;
}


.order-table tbody tr {
    height: 125px;
}

.order-table tbody tr:hover {
    background: #FCF7F1;
}


/* =====================================================
   COVER
===================================================== */

.book-cover {
    width: 65px;
    height: 90px;

    object-fit: contain;

    background: #FAF6F0;

    padding: 5px;

    border-radius: 8px;

    display: block;

    margin: auto;
}


/* =====================================================
   BOOK INFO
===================================================== */

.book-title {
    text-align: left;

    font-weight: 600;

    color: #4B3621;

    line-height: 1.5;

    /*
       Nama panjang tidak merusak tabel.
    */

    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;

    overflow: hidden;

    word-break: break-word;
}

.author {
    color: #777;

    line-height: 1.5;

    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;

    overflow: hidden;

    word-break: break-word;
}

.number {
    white-space: nowrap;
}

.subtotal {
    font-weight: 700;

    color: #6F4E37;

    white-space: nowrap;
}


/* =====================================================
   TOTAL
===================================================== */

.total-section {
    padding: 24px 28px;

    background: #FCF8F3;

    display: flex;

    justify-content: flex-end;
}

.total-content {
    width: 320px;
    max-width: 100%;
}

.total-row {
    display: flex;

    justify-content: space-between;
    align-items: center;

    gap: 20px;

    padding: 8px 0;

    font-size: 14px;
}

.total-row.label {
    color: #777;
}

.total-row.final {
    margin-top: 8px;

    padding-top: 15px;

    border-top: 2px solid #E6D9CC;

    color: #5A3825;

    font-size: 21px;

    font-weight: 700;
}

.total-price {
    color: #6F4E37;

    white-space: nowrap;
}


/* =====================================================
   SHIPPING CARD
===================================================== */

.shipping-card {
    background: white;

    border-radius: 18px;

    padding: 26px;

    box-shadow: 0 8px 25px rgba(0,0,0,.07);

    margin-bottom: 22px;
}

.shipping-grid {
    display: grid;

    grid-template-columns: repeat(2, 1fr);

    gap: 18px;
}

.shipping-item {
    background: #FAF7F2;

    border-radius: 12px;

    padding: 17px;
}

.shipping-item.full {
    grid-column: 1 / -1;
}

.shipping-label {
    display: block;

    color: #8A7566;

    font-size: 11px;

    font-weight: 600;

    text-transform: uppercase;

    letter-spacing: .5px;

    margin-bottom: 7px;
}

.shipping-value {
    color: #3E2C23;

    font-size: 14px;

    line-height: 1.7;

    word-break: break-word;
}


/* =====================================================
   FOOTER BUTTON
===================================================== */

.bottom-actions {
    display: flex;

    justify-content: flex-start;

    gap: 12px;
}

.bottom-btn {
    display: inline-flex;

    align-items: center;
    justify-content: center;

    padding: 11px 19px;

    border-radius: 10px;

    text-decoration: none;

    font-size: 13px;

    font-weight: 500;
}

.bottom-btn.back {
    background: white;

    color: #6F4E37;

    border: 1px solid #DCCCBD;
}

.bottom-btn.back:hover {
    background: #F8F3EC;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media (max-width: 900px) {

    .top-grid {
        grid-template-columns: 1fr;
    }

}


@media (max-width: 700px) {

    .container {
        width: 95%;
        margin-top: 20px;
    }

    .header {
        padding: 20px;

        align-items: flex-start;

        flex-direction: column;
    }

    .header-title {
        font-size: 24px;
    }

    .btn-back {
        width: 100%;
    }

    .card,
    .shipping-card {
        padding: 20px;
    }

    .info-row {
        grid-template-columns: 1fr;
        gap: 5px;
    }

    .status-controls {
        flex-direction: column;
    }

    .btn-save {
        width: 100%;
    }

    .shipping-grid {
        grid-template-columns: 1fr;
    }

    .shipping-item.full {
        grid-column: auto;
    }

    .total-section {
        padding: 20px;
    }

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
<link rel="stylesheet" href="../assets/css/admin-sidebar.css">
<style>.container{margin:35px 3% 60px calc(260px + 3%);width:calc(94% - 260px);max-width:none}@media(max-width:760px){.container{margin:20px auto;width:94%}}</style>
</head>


<body>
<?php include __DIR__ . '/sidebar.php'; ?>


<div class="container">


    <!-- =================================================
         HEADER
    ================================================== -->

    <div class="header">

        <div class="header-left">

            <!-- KODE TRANSAKSI: identitas pesanan yang ditampilkan kepada admin. -->
<div class="header-title">
                Order #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order_id, ENT_QUOTES, 'UTF-8'); ?>
            </div>

            <div class="header-subtitle">
                Detail lengkap pesanan LinglungBooks
            </div>

        </div>
</div>



    <!-- =================================================
         INFORMASI ORDER + CUSTOMER
    ================================================== -->

    <div class="top-grid">


        <!-- ORDER INFORMATION -->

        <div class="card">

            <div class="card-title">
                Order Information
            </div>


            <div class="info-list">


                <div class="info-row">

                    <div class="info-label">
                        Order ID
                    </div>

                    <div class="info-value">
                        #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order_id, ENT_QUOTES, 'UTF-8'); ?>
                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Tanggal Order
                    </div>

                    <div class="info-value">
                        <?= htmlspecialchars(
                            $order_date
                        ); ?>
                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Jumlah Item
                    </div>

                    <div class="info-value">
                        <?= $total_items; ?> item
                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Metode Pembayaran
                    </div>

                    <div class="info-value">

                        <span class="payment-method">

                            <?= htmlspecialchars(match ($order['payment_method'] ?? '') {
                                'VA_BCA' => 'VA BCA',
                                'VA_BRI' => 'VA BRI',
                                'VA_BNI' => 'VA BNI',
                                'VA_MANDIRI' => 'VA Mandiri',
                                'Transfer' => 'Transfer Bank',
                                default => $order['payment_method'] ?? '-'
                            }, ENT_QUOTES, 'UTF-8'); ?>

                        </span>

                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Status
                    </div>

                    <div class="info-value">

                        <span class="status <?= $status_class; ?>">

                            <?= htmlspecialchars($status_label, ENT_QUOTES, 'UTF-8'); ?>

                        </span>

                    </div>

                </div>

            </div>


            <!-- PAYMENT VERIFICATION -->
            <div style="margin-top:22px;padding-top:18px;border-top:1px solid #eee;">
                <div class="card-title">Verifikasi Pembayaran</div>
                <?php if (!empty($verification_message)): ?>
                    <div class="proof-empty" style="margin-bottom:15px;">
                        <?= htmlspecialchars($verification_message, ENT_QUOTES, 'UTF-8'); ?>
                    </div>
                <?php endif; ?>
                <?php if ($has_payment_proof): ?>
                    <div style="margin:12px 0 18px;padding:12px;background:#faf7f2;border:1px solid #eadfd2;border-radius:12px;">
                        <strong style="display:block;margin-bottom:10px;">Bukti Pembayaran</strong>
                        <a href="../assets/payment_proofs/<?= rawurlencode(basename($order['payment_proof'])); ?>" target="_blank" rel="noopener">
                            <img src="../assets/payment_proofs/<?= rawurlencode(basename($order['payment_proof'])); ?>" alt="Bukti pembayaran pesanan #<?= (int)$order_id; ?>" style="display:block;width:100%;max-width:420px;max-height:420px;object-fit:contain;background:#fff;border-radius:9px;border:1px solid #eee;">
                        </a>
                        <small style="display:block;margin-top:7px;color:#817568;">Klik gambar untuk melihat ukuran penuh.</small>
                    </div>
                <?php endif; ?>
                <p style="margin-bottom:12px;">
                    Status verifikasi:
                    <strong><?= htmlspecialchars(ucfirst($order['payment_verification'] ?? 'pending'), ENT_QUOTES, 'UTF-8'); ?></strong>
                </p>
                <?php if (($order['payment_method'] ?? '') !== 'COD' && !empty($order['payment_proof']) && ($order['payment_verification'] ?? 'pending') !== 'approved'): ?>
                    <form method="POST" class="status-form">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                        <label for="verification_note">Catatan untuk user</label>
                        <textarea name="verification_note" id="verification_note" rows="3" style="width:100%;padding:12px;border:1px solid #ddd;border-radius:10px;margin:10px 0;" placeholder="Tuliskan alasan atau catatan verifikasi."></textarea>
                        <input type="hidden" name="verification_decision" value="">
                        <div class="status-controls">
                            <button type="submit" name="verify_payment" value="1" class="btn-save" onclick="this.form.verification_decision.value='approved'">Setujui Bukti</button>
                            <button type="submit" name="verify_payment" value="1" class="btn-save" style="background:#A94442" onclick="this.form.verification_decision.value='rejected'">Tolak Bukti</button>
                        </div>
                    </form>
                <?php elseif (($order['payment_verification'] ?? '') === 'approved'): ?>
                    <p>Bukti sudah disetujui. Status pesanan: <strong><?= strtolower($order['status'] ?? '') === 'completed' ? 'Selesai' : (strtolower($order['status'] ?? '') === 'shipped' ? 'Dikirim' : 'Diproses'); ?></strong>. User dapat menekan Selesaikan Pesanan setelah menerima buku.</p>
                <?php else: ?>
                    <p>Belum ada bukti pembayaran yang dapat diverifikasi.</p>
                <?php endif; ?>
                <p style="margin-top:12px;color:#8a7a6d;font-size:12px;">Admin hanya memverifikasi bukti. Penyelesaian pesanan hanya dapat dilakukan oleh user.</p>
            </div>

        </div>



        <!-- STATUS PENGIRIMAN, RETUR, REFUND -->
        <div class="card" style="margin-top:22px;">
          <div class="card-title">Pengiriman, Retur & Pengembalian Dana</div>
          <?php if ($workflow_message !== ''): ?><p style="padding:10px;background:#F3E8D8;border-radius:8px;margin-bottom:14px;"><?= htmlspecialchars($workflow_message, ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>
          <p style="margin-bottom:14px;">Status saat ini: <strong><?= htmlspecialchars($order['status'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
          <?php if ($order['status'] === 'Packed'): ?><form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><button class="btn-save" name="admin_order_action" value="ship_order">Tandai Dikirim</button></form><?php endif; ?>
          <?php if ($order['status'] === 'ReturnRequested'): ?>
            <p><strong>Alasan retur:</strong> <?= htmlspecialchars($order['return_note'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></p>
            <?php if (!empty($order['return_proof'])): ?><p style="margin:10px 0;"><a href="../assets/return_proofs/<?= rawurlencode(basename($order['return_proof'])); ?>" target="_blank" rel="noopener">Lihat/unduh video bukti unboxing</a></p><?php endif; ?>
            <form method="POST" class="status-form"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><label for="return_admin_note">Catatan admin</label><textarea id="return_admin_note" name="return_admin_note" rows="3" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;margin:8px 0 12px;"></textarea><button class="btn-save" name="admin_order_action" value="approve_return">Setujui Retur</button> <button class="btn-save" style="background:#A94442" name="admin_order_action" value="reject_return">Tolak Retur</button></form>
          <?php elseif ($order['status'] === 'ReturnShipped'): ?><p>User menyatakan barang retur sudah dikirim. Konfirmasi setelah barang fisik tiba di gudang.</p><form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><button class="btn-save" name="admin_order_action" value="receive_return">Konfirmasi Barang Tiba di Gudang</button></form>
          <?php elseif ($order['status'] === 'Returned' && ($order['refund_status'] ?? '') === 'pending'): ?><p>Barang retur telah dikonfirmasi tiba. Lakukan pengembalian uang melalui metode yang disepakati dengan pembeli, lalu catat prosesnya di sini.</p><form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><label for="refund_note">Catatan pengembalian uang</label><textarea id="refund_note" name="return_admin_note" rows="2" style="width:100%;padding:10px;border:1px solid #ddd;border-radius:8px;margin:8px 0 12px;" required></textarea><button class="btn-save" name="admin_order_action" value="refund_done">Tandai Pengembalian Uang Selesai</button></form>
          <?php elseif ($order['status'] === 'Refunded'): ?><p>Pengembalian uang telah ditandai selesai. Catatan: <?= htmlspecialchars($order['refund_note'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></p><?php endif; ?>
        </div>

        <!-- CUSTOMER INFORMATION -->

        <div class="card">

            <div class="card-title">
                Customer Information
            </div>


            <div class="info-list">


                <div class="info-row">

                    <div class="info-label">
                        Nama Customer
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $order['fullname']
                            ?? '-'
                        ); ?>

                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Username
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $order['username']
                            ?? '-'
                        ); ?>

                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Email
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $order['email']
                            ?? '-'
                        ); ?>

                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Nama Penerima
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $order['recipient_name']
                            ?? '-'
                        ); ?>

                    </div>

                </div>


                <div class="info-row">

                    <div class="info-label">
                        Nomor HP
                    </div>

                    <div class="info-value">

                        <?= htmlspecialchars(
                            $order['phone']
                            ?? '-'
                        ); ?>

                    </div>

                </div>


            </div>

        </div>


    </div>



    <!-- =================================================
         SHIPPING ADDRESS
    ================================================== -->

    <div class="shipping-card">

        <div class="card-title">
            Shipping Information
        </div>


        <div class="shipping-grid">


            <div class="shipping-item">

                <span class="shipping-label">
                    Penerima
                </span>

                <div class="shipping-value">

                    <?= htmlspecialchars(
                        $order['recipient_name']
                        ?? '-'
                    ); ?>

                </div>

            </div>


            <div class="shipping-item">

                <span class="shipping-label">
                    Nomor HP
                </span>

                <div class="shipping-value">

                    <?= htmlspecialchars(
                        $order['phone']
                        ?? '-'
                    ); ?>

                </div>

            </div>


            <div class="shipping-item full">

                <span class="shipping-label">
                    Alamat Pengiriman
                </span>

                <div class="shipping-value">

                    <?= nl2br(
                        htmlspecialchars(
                            $order['address']
                            ?? '-'
                        )
                    ); ?>

                </div>

            </div>


        </div>

    </div>



    <!-- =================================================
         PAYMENT PROOF
    ================================================== -->

    <div class="card" style="margin-bottom:22px;">

        <div class="card-title">
            Payment Information
        </div>


        <div class="info-row">

            <div class="info-label">
                Metode Pembayaran
            </div>

            <div class="info-value">

                <span class="payment-method">

                    <?= htmlspecialchars(
                        $order['payment_method']
                        ?? '-'
                    ); ?>

                </span>

            </div>

        </div>


        <?php if (!empty($order['va_number'])): ?>
            <div class="proof-box">
                <div class="proof-title">Detail Virtual Account</div>
                <p>Bank: <strong><?= htmlspecialchars($order['va_bank'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></strong></p>
                <p>Nomor VA: <strong><?= htmlspecialchars($order['va_number'], ENT_QUOTES, 'UTF-8'); ?></strong></p>
                <p>Referensi: <strong><?= htmlspecialchars($order['payment_reference'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></strong></p>
                <p style="font-size:12px;color:#8a7a6d;">VA ini hanya pembayaran dan bukan rekening bank sungguhan.</p>
            </div>
        <?php endif; ?>

        <?php if (
            !empty($order['payment_proof'])
        ): ?>


            <div class="proof-box">

                <div class="proof-title">
                    Bukti Pembayaran
                </div>


                <?php if ($has_payment_proof): ?>


                    <img
                        src="../assets/payment_proofs/<?= htmlspecialchars(
                            $order['payment_proof']
                        ); ?>"
                        alt="Bukti Pembayaran"
                        class="proof-preview"
                    >


                    <a
                        href="../assets/payment_proofs/<?= htmlspecialchars(
                            $order['payment_proof']
                        ); ?>"
                        target="_blank"
                        class="btn-proof"
                    >
                        Buka Bukti Pembayaran
                    </a>


                <?php else: ?>


                    <div class="proof-empty">

                        Belum ada bukti pembayaran
                        yang diupload oleh customer.

                    </div>


                <?php endif; ?>


            </div>


        <?php else: ?>


            <div class="proof-box">

                <div class="proof-empty">

                    Pembayaran menggunakan
                    <?= htmlspecialchars(
                        $order['payment_method']
                        ?? 'metode lain'
                    ); ?>.

                    Tidak ada bukti transfer.

                </div>

            </div>


        <?php endif; ?>


    </div>



    <!-- =================================================
         ORDER ITEMS
    ================================================== -->

    <div class="items-card">


        <div class="items-header">

            <h2>
                Order Items
            </h2>

            <p>
                <?= count($detail_items); ?>
                jenis buku ·
                <?= $total_items; ?>
                total item
            </p>

        </div>


        <div class="table-wrapper">

            <table class="order-table">


                <colgroup>

                    <col class="cover-col">
                    <col class="book-col">
                    <col class="author-col">
                    <col class="price-col">
                    <col class="qty-col">
                    <col class="subtotal-col">

                </colgroup>


                <thead>

                    <tr>

                        <th>
                            Cover
                        </th>

                        <th>
                            Buku
                        </th>

                        <th>
                            Penulis
                        </th>

                        <th>
                            Harga
                        </th>

                        <th>
                            Qty
                        </th>

                        <th>
                            Subtotal
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php if (count($detail_items) > 0): ?>


                    <?php foreach (
                        $detail_items as $item
                    ): ?>


                        <tr>


                            <td>

                                <?php if (
                                    !empty($item['cover'])
                                ): ?>

                                    <img
                                        src="../assets/img/<?= htmlspecialchars(
                                            $item['cover']
                                        ); ?>"
                                        alt="<?= htmlspecialchars(
                                            $item['title']
                                        ); ?>"
                                        class="book-cover"
                                    >

                                <?php else: ?>

                                    <div
                                        style="
                                            width:65px;
                                            height:90px;
                                            margin:auto;
                                            background:#FAF6F0;
                                            border-radius:8px;
                                            display:flex;
                                            align-items:center;
                                            justify-content:center;
                                            color:#999;
                                            font-size:11px;
                                        "
                                    >
                                        No Cover
                                    </div>

                                <?php endif; ?>

                            </td>


                            <td>

                                <div class="book-title">

                                    <?= htmlspecialchars(
                                        $item['title']
                                        ?? '-'
                                    ); ?>

                                </div>

                            </td>


                            <td>

                                <div class="author">

                                    <?= htmlspecialchars(
                                        $item['author']
                                        ?? '-'
                                    ); ?>

                                </div>

                            </td>


                            <td>

                                <span class="number">

                                    Rp<?= number_format(
                                        $item['price'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </span>

                            </td>


                            <td>

                                <span class="number">

                                    <?= (int)$item['quantity']; ?>

                                </span>

                            </td>


                            <td>

                                <span class="subtotal">

                                    Rp<?= number_format(
                                        $item['price'] *
                                        $item['quantity'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </span>

                            </td>


                        </tr>


                    <?php endforeach; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="6"
                            style="
                                padding:40px;
                                color:#888;
                            "
                        >

                            Tidak ada detail buku
                            pada pesanan ini.

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>

            </table>

        </div>



        <!-- TOTAL -->

        <div class="total-section">

            <div class="total-content">


                <div class="total-row label">

                    <span>
                        Total Item
                    </span>

                    <span>
                        <?= $total_items; ?>
                    </span>

                </div>


                <div class="total-row">
                    <span>Keuntungan Transaksi</span>
                    <span style="font-weight:700;color:#6f4e37;">
                        <?= $profit_ready ? 'Rp' . number_format($total_profit, 0, ',', '.') : 'Belum diatur'; ?>
                    </span>
                </div>

                <div class="total-row final">

                    <span>
                        Grand Total
                    </span>

                    <span class="total-price">

                        Rp<?= number_format(
                            $order['total_price'],
                            0,
                            ",",
                            "."
                        ); ?>

                    </span>

                </div>


            </div>

        </div>


    </div>



    <!-- =================================================
         BOTTOM
    ================================================== -->
</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>