<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


/* =========================
   SEARCH
========================= */

$search = trim($_GET['search'] ?? '');
$categoryFilter = (int)($_GET['category'] ?? 0);
$sort = $_GET['sort'] ?? 'title_asc';
$allowedSort = ['title_asc'=>'books.title ASC','title_desc'=>'books.title DESC','stock_asc'=>'books.stock ASC','stock_desc'=>'books.stock DESC','price_asc'=>'books.price ASC','price_desc'=>'books.price DESC'];
$orderBy = $allowedSort[$sort] ?? $allowedSort['title_asc'];
$conditions = [];
if ($search !== '') { $safeSearch=mysqli_real_escape_string($conn,$search); $conditions[]="(books.title LIKE '%$safeSearch%' OR books.author LIKE '%$safeSearch%' OR categories.category_name LIKE '%$safeSearch%')"; }
if ($categoryFilter > 0) $conditions[]="books.category_id=$categoryFilter";
$where = $conditions ? 'WHERE '.implode(' AND ',$conditions) : '';


/* =========================
   GET BOOKS
   URUT BERDASARKAN KATEGORI
========================= */

$query = mysqli_query($conn, "
    SELECT
        books.*,
        categories.category_name

    FROM books

    LEFT JOIN categories
        ON books.category_id = categories.id

    $where

    ORDER BY $orderBy
");


/* =========================
   ADMIN INITIAL
========================= */

$categoryOptions = mysqli_query($conn, "SELECT id, category_name FROM categories ORDER BY category_name");

$initial = strtoupper(
    substr($_SESSION['fullname'], 0, 1)
);

?>

<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Books | LinglungBooks</title>


<!-- GOOGLE FONT -->

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
>


<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Poppins, sans-serif;
}


/* =========================
   BODY
========================= */

body {
    background: #F8F3EC;

    display: flex;

    color: #3E2C23;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {
    width: 260px;

    height: 100vh;

    background: #6F4E37;

    color: white;

    padding: 30px 20px;

    position: fixed;

    display: flex;

    flex-direction: column;
}


/* =========================
   LOGO
========================= */

.logo {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 12px;

    margin-bottom: 45px;
}

.logo-icon {
    display: flex;

    align-items: center;

    justify-content: center;
}

.logo-icon i {
    font-size: 28px;

    color: #E8C39E;
}

.logo-text h2 {
    font-size: 24px;

    font-weight: 700;
}

.logo-text span {
    color: #E8C39E;
}


/* =========================
   SIDEBAR MENU
========================= */

.sidebar a {
    display: flex;

    align-items: center;

    gap: 12px;

    text-decoration: none;

    color: white;

    padding: 15px 18px;

    border-radius: 14px;

    margin-bottom: 12px;

    transition: .25s;

    font-weight: 500;
}

.sidebar a i {
    width: 22px;

    text-align: center;

    font-size: 17px;

    color: #E8C39E;
}

.sidebar a:hover {
    background: #8B5E3C;

    transform: translateX(4px);
}

.sidebar a.active {
    background: #8B5E3C;

    box-shadow: 0 8px 18px rgba(0,0,0,.15);
}


/* =========================
   MAIN
========================= */

.main {
    margin-left: 260px;

    width: calc(100% - 260px);

    min-height: 100vh;
}


/* =========================
   HEADER
========================= */

.header {
    height: 82px;

    background: white;

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 0 40px;

    box-shadow: 0 5px 18px rgba(0,0,0,.06);
}

.header h2 {
    color: #5A3825;

    font-size: 27px;

    font-weight: 700;
}


/* =========================
   ADMIN PROFILE
========================= */

.admin-box {
    display: flex;

    align-items: center;

    gap: 15px;
}

.admin-info {
    text-align: right;
}

.admin-info small {
    display: block;

    font-size: 12px;

    color: #888;

    margin-bottom: 2px;
}

.admin-info strong {
    color: #6F4E37;

    font-size: 15px;
}

.admin-avatar {
    width: 46px;

    height: 46px;

    border-radius: 50%;

    background: #6F4E37;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    font-weight: 600;

    box-shadow: 0 5px 15px rgba(111,78,55,.25);
}


/* =========================
   CONTAINER
========================= */

.container {
    padding: 40px;
}


/* =========================
   TOP ACTION
========================= */

.top {
    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}

.back-btn {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    text-decoration: none;

    color: #6F4E37;

    font-weight: 500;

    transition: .25s;
}

.back-btn:hover {
    color: #8B5E3C;

    transform: translateX(-3px);
}

.add-btn {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    background: #6F4E37;

    color: white;

    padding: 12px 18px;

    border-radius: 12px;

    text-decoration: none;

    transition: .3s;

    font-weight: 500;
}

.add-btn:hover {
    background: #8B5E3C;
}


/* =========================
   SEARCH
========================= */

.search-card {
    background: white;

    padding: 22px;

    border-radius: 22px;

    box-shadow: 0 10px 25px rgba(0,0,0,.08);

    margin-bottom: 30px;
}

.search-box {
    display: flex;

    gap: 12px;
}

.search-box input {
    flex: 1;

    padding: 14px;

    border: 1px solid #ddd;

    border-radius: 12px;

    outline: none;

    font-size: 15px;
}

.search-box input:focus {
    border-color: #6F4E37;
}

.search-box button {
    border: none;

    background: #6F4E37;

    color: white;

    padding: 14px 25px;

    border-radius: 12px;

    cursor: pointer;

    font-weight: 500;

    transition: .3s;
}

.search-box button:hover {
    background: #8B5E3C;
}


/* =========================
   TABLE
========================= */

.table-card {
    background: white;

    border-radius: 22px;

    overflow: hidden;

    box-shadow: 0 10px 25px rgba(0,0,0,.08);
}

table {
    width: 100%;

    border-collapse: collapse;
}

th {
    background: #6F4E37;

    color: white;

    padding: 16px;

    font-size: 14px;

    font-weight: 600;

    text-align: center;
}

td {
    padding: 16px;

    text-align: center;

    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #FCF8F3;
}


/* =========================
   BOOK COVER
========================= */

.cover {
    width: 70px;

    height: 100px;

    object-fit: cover;

    border-radius: 12px;
}


/* =========================
   CATEGORY
========================= */

.category-name {
    color: #6F4E37;

    font-weight: 600;
}


/* =========================
   STOCK BADGE
========================= */

.badge {
    padding: 7px 14px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 600;

    display: inline-block;
}

.available {
    background: #E8DCCF;

    color: #6F4E37;
}

.low {
    background: #F3E8D8;

    color: #8B5E3C;
}

.out {
    background: #E9C8C8;

    color: #7A2727;
}


/* =========================
   ACTION BUTTONS
========================= */

.action-buttons {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 12px;

    white-space: nowrap;
}

.edit,
.delete {
    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 7px;

    min-width: 82px;

    padding: 9px 14px;

    color: white;

    border-radius: 9px;

    text-decoration: none;

    font-size: 13px;

    font-weight: 500;

    transition: .3s;
}

.edit {
    background: #8B5E3C;
}

.edit:hover {
    background: #6F4E37;

    transform: translateY(-1px);
}

.delete {
    background: #6F4E37;
}

.delete:hover {
    background: #4E3324;

    transform: translateY(-1px);
}


/* =========================
   EMPTY
========================= */

.empty {
    padding: 45px;

    color: #777;
}


/* =========================
   FOOTER
========================= */

.admin-footer {
    text-align: center;

    padding: 35px 0 10px;

    color: #888;

    font-size: 14px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1200px) {

    .container {
        padding: 30px;
    }

    .table-card {
        overflow-x: auto;
    }

    table {
        min-width: 1000px;
    }

}


@media (max-width: 1000px) {

    .header {
        padding: 0 30px;
    }

}


@media (max-width: 900px) {

    body {
        display: block;
    }

    .sidebar {
        width: 100%;

        height: auto;

        position: relative;

        padding: 20px;
    }

    .logo {
        margin-bottom: 25px;
    }

    .main {
        margin-left: 0;

        width: 100%;
    }

    .header {
        padding: 20px;

        height: auto;

        flex-direction: column;

        gap: 15px;

        align-items: flex-start;
    }

    .container {
        padding: 20px;
    }

}


@media (max-width: 600px) {

    .admin-info {
        text-align: left;
    }

    .admin-box {
        width: 100%;

        justify-content: space-between;
    }

    .top {
        gap: 15px;

        flex-wrap: wrap;
    }

    .add-btn {
        padding: 10px 13px;

        font-size: 13px;
    }

    .search-box {
        flex-direction: column;
    }

    .search-box button {
        width: 100%;
    }

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">
</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="main">


    <!-- HEADER -->

    <div class="header">


        <h2>
            Manage Books
        </h2>


        <div class="admin-box">


            <div class="admin-info">

                <small>
                    Administrator
                </small>

                <strong>
                    <?= htmlspecialchars($_SESSION['fullname']); ?>
                </strong>

            </div>


            <div class="admin-avatar">

                <?= htmlspecialchars($initial); ?>

            </div>


        </div>


    </div>


    <!-- CONTENT -->

    <div class="container">


        <!-- TOP -->

        <div class="top">
<a
                href="add_book.php"
                class="add-btn"
            >

                <i class="fa-solid fa-plus"></i>

                Add Book

            </a>


        </div>


        <!-- SEARCH -->

        <div class="search-card">


            <form
                class="search-box"
                method="GET"
            >

                <input
                    type="text"
                    name="search"
                    placeholder="Search title, author or category..."
                    value="<?= htmlspecialchars($search); ?>"
                >
                <select name="category" aria-label="Filter kategori"><option value="0">Semua kategori</option><?php if($categoryOptions) while($cat=mysqli_fetch_assoc($categoryOptions)): ?><option value="<?= (int)$cat['id']; ?>" <?= $categoryFilter===(int)$cat['id']?'selected':''; ?>><?= htmlspecialchars($cat['category_name']); ?></option><?php endwhile; ?></select>
                <select name="sort" aria-label="Urutkan"><option value="title_asc" <?= $sort==='title_asc'?'selected':''; ?>>Judul A–Z</option><option value="title_desc" <?= $sort==='title_desc'?'selected':''; ?>>Judul Z–A</option><option value="stock_asc" <?= $sort==='stock_asc'?'selected':''; ?>>Stok terendah</option><option value="stock_desc" <?= $sort==='stock_desc'?'selected':''; ?>>Stok tertinggi</option><option value="price_asc" <?= $sort==='price_asc'?'selected':''; ?>>Harga terendah</option><option value="price_desc" <?= $sort==='price_desc'?'selected':''; ?>>Harga tertinggi</option></select>


                <button type="submit">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    Search

                </button>

            </form>


        </div>


        <!-- TABLE -->

        <div class="table-card">


            <table>


                <thead>

                    <tr>

                        <th>
                            No
                        </th>

                        <th>
                            Cover
                        </th>

                        <th>
                            Title
                        </th>

                        <th>
                            Author
                        </th>

                        <th>
                            Category
                        </th>

                        <th>
                            Price
                        </th>

                        <th>
                            Stock
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($book = mysqli_fetch_assoc($query)) {

                ?>


                    <tr>


                        <!-- NO -->

                        <td>

                            <?= $no++; ?>

                        </td>


                        <!-- COVER -->

                        <td>

                            <img
                                class="cover"
                                src="../assets/img/<?= htmlspecialchars($book['cover']); ?>"
                                alt="<?= htmlspecialchars($book['title']); ?>"
                            >

                        </td>


                        <!-- TITLE -->

                        <td>

                            <strong>

                                <?= htmlspecialchars(
                                    $book['title']
                                ); ?>

                            </strong>

                        </td>


                        <!-- AUTHOR -->

                        <td>

                            <?= htmlspecialchars(
                                $book['author']
                            ); ?>

                        </td>


                        <!-- CATEGORY -->

                        <td>

                            <span class="category-name">

                                <?= htmlspecialchars(
                                    $book['category_name'] ?? '-'
                                ); ?>

                            </span>

                        </td>


                        <!-- PRICE -->

                        <td>

                            <strong>

                                Rp<?= number_format(
                                    $book['price'],
                                    0,
                                    ",",
                                    "."
                                ); ?>

                            </strong>

                        </td>


                        <!-- STOCK -->

                        <td>


                        <?php

                        if ($book['stock'] == 0) {

                        ?>

                            <span class="badge out">

                                Out of Stock

                            </span>


                        <?php

                        } elseif ($book['stock'] <= 5) {

                        ?>

                            <span class="badge low">

                                <?= $book['stock']; ?>

                                Left

                            </span>


                        <?php

                        } else {

                        ?>

                            <span class="badge available">

                                <?= $book['stock']; ?>

                                Available

                            </span>


                        <?php

                        }

                        ?>


                        </td>


                        <!-- ACTION -->

                        <td>


                            <div class="action-buttons">


                                <a
                                    class="edit"
                                    href="edit_book.php?id=<?= $book['id']; ?>"
                                >

                                    <i class="fa-solid fa-pen-to-square"></i>

                                    Edit

                                </a>


                                <a
                                    class="delete"
                                    href="delete_book.php?id=<?= $book['id']; ?>"
                                    onclick="return confirm('Delete this book?')"
                                >

                                    <i class="fa-solid fa-trash"></i>

                                    Delete

                                </a>


                            </div>


                        </td>


                    </tr>


                <?php

                    }

                } else {

                ?>


                    <tr>


                        <td
                            colspan="8"
                            class="empty"
                        >


                            <i
                                class="fa-solid fa-book-open"
                                style="
                                    font-size:45px;
                                    color:#8B5E3C;
                                    margin-bottom:15px;
                                    display:block;
                                "
                            ></i>


                            <h3
                                style="
                                    color:#5A3825;
                                    margin-bottom:8px;
                                "
                            >

                                No Books Found

                            </h3>


                            <p>

                                There are no books available.

                            </p>


                        </td>


                    </tr>


                <?php

                }

                ?>


                </tbody>


            </table>


        </div>


        <!-- FOOTER -->

        <div class="admin-footer">

            © <?= date('Y'); ?> LinglungBooks — Admin Dashboard

        </div>


    </div>


</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>