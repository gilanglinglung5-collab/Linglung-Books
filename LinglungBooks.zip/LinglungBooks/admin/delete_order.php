<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


/* =========================
   CEK ORDER ID
========================= */

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: orders.php");
    exit;
}

$order_id = (int) $_GET['id'];


/* =========================
   CEK ORDER
========================= */

$checkOrder = mysqli_prepare(
    $conn,
    "SELECT id FROM orders WHERE id = ?"
);

mysqli_stmt_bind_param(
    $checkOrder,
    "i",
    $order_id
);

mysqli_stmt_execute($checkOrder);

$result = mysqli_stmt_get_result($checkOrder);

if (mysqli_num_rows($result) == 0) {
    mysqli_stmt_close($checkOrder);

    header("Location: orders.php");
    exit;
}

mysqli_stmt_close($checkOrder);


/* =========================
   MULAI TRANSACTION
========================= */

mysqli_begin_transaction($conn);

try {

    /* =========================
       HAPUS ORDER DETAILS
    ========================= */

    $deleteDetails = mysqli_prepare(
        $conn,
        "DELETE FROM order_details WHERE order_id = ?"
    );

    mysqli_stmt_bind_param(
        $deleteDetails,
        "i",
        $order_id
    );

    if (!mysqli_stmt_execute($deleteDetails)) {
        throw new Exception("Gagal menghapus order details.");
    }

    mysqli_stmt_close($deleteDetails);


    /* =========================
       HAPUS ORDER
    ========================= */

    $deleteOrder = mysqli_prepare(
        $conn,
        "DELETE FROM orders WHERE id = ?"
    );

    mysqli_stmt_bind_param(
        $deleteOrder,
        "i",
        $order_id
    );

    if (!mysqli_stmt_execute($deleteOrder)) {
        throw new Exception("Gagal menghapus order.");
    }

    mysqli_stmt_close($deleteOrder);


    /* =========================
       SIMPAN PERUBAHAN
    ========================= */

    mysqli_commit($conn);

    header("Location: orders.php?deleted=1");
    exit;


} catch (Exception $e) {

    /* =========================
       BATALKAN SEMUA PERUBAHAN
    ========================= */

    mysqli_rollback($conn);

    header("Location: orders.php?deleted=0");
    exit;
}

?>