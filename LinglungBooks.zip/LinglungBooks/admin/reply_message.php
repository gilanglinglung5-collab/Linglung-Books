<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


if(!isset($_GET['id'])){

    header("Location: messages.php");
    exit;

}


$id = $_GET['id'];


// ambil data pesan

$query = mysqli_query($conn,"
SELECT
messages.*,
users.fullname,
users.email
FROM messages
LEFT JOIN users
ON messages.user_id = users.id
WHERE messages.id='$id'
");


$message = mysqli_fetch_assoc($query);



if(!$message){

    echo "Message not found";
    exit;

}


// kirim balasan

if(isset($_POST['send'])){


    $reply = mysqli_real_escape_string(
        $conn,
        $_POST['reply']
    );


    mysqli_query($conn,"
    UPDATE messages
    SET
    reply='$reply',
    reply_date=NOW(),
    status='replied'
    WHERE id='$id'
    ");


    header("Location: messages.php");
    exit;

}


?>


<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<title>Reply Message</title>


<style>

body{

background:#F8F3EC;
font-family:Poppins,sans-serif;

}


.container{

width:700px;
margin:40px auto;
background:white;
padding:30px;
border-radius:18px;

}


h2{

color:#5A3825;

}


.info{

background:#FCF7F1;
padding:20px;
border-radius:12px;
margin-bottom:20px;

}


textarea{

width:100%;
height:150px;
padding:15px;
border-radius:10px;
border:1px solid #ddd;
resize:none;

}


button{

margin-top:15px;
background:#6F4E37;
color:white;
border:none;
padding:12px 25px;
border-radius:10px;
cursor:pointer;

}


button:hover{

background:#8B5E3C;

}


</style>


    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<div class="container">


<h2>Reply Message</h2>


<div class="info">


<p>
<b>Name:</b>
<?= htmlspecialchars($message['fullname']); ?>
</p>


<p>
<b>Email:</b>
<?= htmlspecialchars($message['email']); ?>
</p>


<p>
<b>Subject:</b>
<?= htmlspecialchars($message['subject']); ?>
</p>


<br>


<p>
<b>Message:</b>
</p>


<p>
<?= nl2br(htmlspecialchars($message['message'])); ?>
</p>


</div>



<form method="POST">


<label>
Reply:
</label>


<br><br>


<textarea name="reply" required></textarea>


<br>


<button name="send">
Send Reply
</button>


</form>


</div>


    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>