<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';

$message = "";

if (isset($_POST['save'])) {

    $category_name = mysqli_real_escape_string(
        $conn,
        trim($_POST['category_name'])
    );

    $icon = mysqli_real_escape_string(
        $conn,
        trim($_POST['icon'])
    );

    if ($category_name == "") {
        $message = "Category name is required.";
    } else {

        $check = mysqli_query($conn, "
            SELECT *
            FROM categories
            WHERE category_name='$category_name'
        ");

        if (mysqli_num_rows($check) > 0) {

            $message = "Category already exists.";

        } else {

            $insert = mysqli_query($conn, "
                INSERT INTO categories(category_name, icon)
                VALUES('$category_name','$icon')
            ");

            if ($insert) {

                header("Location: categories.php");
                exit;

            } else {

                $message = "Failed to add category.";

            }

        }

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Add Category | LinglungBooks</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
rel="stylesheet">

<link
rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Poppins,sans-serif;
}

body{
background:#F8F3EC;
}

.container{
width:95%;
max-width:900px;
margin:40px auto;
}

.header{

display:flex;
justify-content:space-between;
align-items:center;

background:#fff;
padding:25px 30px;

border-radius:18px;
box-shadow:0 8px 20px rgba(0,0,0,.08);

margin-bottom:25px;

}

.header h1{

font-size:28px;
color:#6F4E37;

}

.back-btn{

text-decoration:none;
background:#6F4E37;
color:#fff;

padding:11px 18px;

border-radius:10px;
transition:.3s;

}

.back-btn:hover{

background:#8B5E3C;

}

.form-card{

background:#fff;
padding:35px;

border-radius:18px;

box-shadow:0 8px 20px rgba(0,0,0,.08);

}

.message{

background:#F8D7DA;
color:#842029;

padding:14px;

border-radius:10px;

margin-bottom:25px;

}

.input-group{

display:flex;
flex-direction:column;

margin-bottom:25px;

}

label{

font-weight:600;
margin-bottom:10px;
color:#6F4E37;

}

input[type=text]{

width:100%;

padding:13px 15px;

border:1px solid #ddd;

border-radius:10px;

font-size:15px;

outline:none;

transition:.3s;

}

input[type=text]:focus{

border-color:#8B5E3C;

box-shadow:0 0 0 3px rgba(111,78,55,.15);

}

.icon-preview{

display:flex;
align-items:center;
justify-content:center;

height:90px;

font-size:40px;

background:#F8F3EC;

border-radius:15px;

border:2px dashed #D7C0AA;

margin-bottom:20px;

color:#6F4E37;

}

.search-box{

margin-bottom:20px;

}

.search-box input{

width:100%;

padding:13px 15px;

border-radius:10px;

border:1px solid #ddd;

outline:none;

}

.search-box input:focus{

border-color:#8B5E3C;

box-shadow:0 0 0 3px rgba(111,78,55,.15);

}

.icon-grid{

display:grid;

grid-template-columns:repeat(auto-fill,minmax(65px,1fr));

gap:15px;

max-height:350px;

overflow-y:auto;

padding:10px;

border:1px solid #eee;

border-radius:12px;

background:#fafafa;

}

.icon-item{

height:60px;

display:flex;

align-items:center;
justify-content:center;

font-size:24px;

cursor:pointer;

border-radius:12px;

transition:.25s;

border:2px solid transparent;

}

.icon-item:hover{

background:#F3E8D8;

transform:scale(1.08);

}

.icon-item.active{

background:#6F4E37;

color:white;

border-color:#8B5E3C;

}

.button-group{

display:flex;
justify-content:flex-end;
gap:15px;

margin-top:30px;

}

.cancel-btn{

text-decoration:none;

padding:13px 25px;

background:#E7D8C9;

color:#6F4E37;

border-radius:10px;

}

.save-btn{

border:none;

background:#6F4E37;

color:#fff;

padding:13px 30px;

border-radius:10px;

cursor:pointer;

font-weight:600;

}

.save-btn:hover{

background:#8B5E3C;

}

@media(max-width:768px){

.button-group{

flex-direction:column;

}

.cancel-btn,
.save-btn{

width:100%;

text-align:center;

}

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
<link rel="stylesheet" href="../assets/css/admin-sidebar.css">
<style>.container{margin:35px 3% 60px calc(260px + 3%);width:calc(94% - 260px);max-width:none}@media(max-width:760px){.container{margin:20px auto;width:94%}}</style>
</head>

<body>
<?php include __DIR__ . '/sidebar.php'; ?>

<div class="container">

<div class="header">

<h1>➕ Add Category</h1>
</div>

<div class="form-card">

<?php if($message!=""){ ?>

<div class="message">

<?= $message ?>

</div>

<?php } ?>

<form method="POST">

<div class="input-group">

<label>Category Name</label>

<input
type="text"
name="category_name"
required
placeholder="Example : Fantasy">

</div>

<div class="input-group">

<label>Category Icon</label>

<div class="icon-preview">
    <i id="previewIcon" class="fa-solid fa-book"></i>
</div>

<div class="search-box">

<input
type="text"
id="searchIcon"
placeholder="Search icon...">

</div>

<input
type="hidden"
name="icon"
id="selectedIcon"
value="fa-book">

<div class="icon-grid" id="iconGrid">

<?php

$icons = [
    "fa-book",
    "fa-book-open",
    "fa-book-bookmark",
    "fa-bookmark",
    "fa-atlas",
    "fa-scroll",
    "fa-newspaper",
    "fa-file-lines",
    "fa-pen",
    "fa-pencil",
    "fa-feather",
    "fa-graduation-cap",
    "fa-school",
    "fa-user-graduate",
    "fa-chalkboard",
    "fa-glasses",
    "fa-calculator",
    "fa-flask",
    "fa-microscope",
    "fa-atom",
    "fa-dna",
    "fa-brain",
    "fa-lightbulb",
    "fa-heart",
    "fa-gift",
    "fa-ring",
    "fa-cake-candles",
    "fa-rose",
    "fa-face-smile",
    "fa-face-kiss",
    "fa-skull",
    "fa-skull-crossbones",
    "fa-ghost",
    "fa-mask",
    "fa-spider",
    "fa-biohazard",
    "fa-hat-wizard",
    "fa-dragon",
    "fa-wand-magic",
    "fa-crown",
    "fa-shield-halved",
    "fa-chess-knight",
    "fa-gem",
    "fa-fire",
    "fa-earth-asia",
    "fa-globe",
    "fa-map",
    "fa-map-location-dot",
    "fa-compass",
    "fa-mountain",
    "fa-tree",
    "fa-leaf",
    "fa-campground",
    "fa-plane",
    "fa-ship",
    "fa-car",
    "fa-bus",
    "fa-train",
    "fa-motorcycle",
    "fa-bicycle",
    "fa-rocket",
    "fa-robot",
    "fa-satellite",
    "fa-user-astronaut",
    "fa-meteor",
    "fa-laptop-code",
    "fa-code",
    "fa-keyboard",
    "fa-desktop",
    "fa-mobile-screen",
    "fa-server",
    "fa-database",
    "fa-cloud",
    "fa-wifi",
    "fa-terminal",
    "fa-bug",
    "fa-camera",
    "fa-film",
    "fa-video",
    "fa-music",
    "fa-guitar",
    "fa-headphones",
    "fa-palette",
    "fa-paintbrush",
    "fa-futbol",
    "fa-basketball",
    "fa-baseball",
    "fa-volleyball",
    "fa-table-tennis-paddle-ball",
    "fa-dumbbell",
    "fa-medal",
    "fa-trophy",
    "fa-gamepad",
    "fa-dice",
    "fa-puzzle-piece",
    "fa-paw",
    "fa-cat",
    "fa-dog",
    "fa-fish",
    "fa-crow",
    "fa-seedling",
    "fa-briefcase",
    "fa-scale-balanced",
    "fa-landmark"
];

foreach($icons as $index => $icon){

?>

<div class="icon-item <?= $index == 0 ? 'active' : ''; ?>" data-icon="<?= $icon; ?>">
    <i class="fa-solid <?= $icon; ?>"></i>
</div>

<?php } ?>

</div>

</div>

</div>

<div class="button-group">

<a href="categories.php" class="cancel-btn">

Cancel

</a>

<button
type="submit"
name="save"
class="save-btn">

<i class="fa-solid fa-floppy-disk"></i>
&nbsp;
Save Category

</button>

</div>

</form>

</div>

</div>

<script>

const iconItems =
document.querySelectorAll(".icon-item");

const preview =
document.getElementById("previewIcon");

const hidden =
document.getElementById("selectedIcon");

iconItems.forEach(item=>{

item.onclick=function(){

iconItems.forEach(i=>{

i.classList.remove("active");

});

this.classList.add("active");

const icon =
this.dataset.icon;

hidden.value=icon;

preview.className=
"fa-solid "+icon;

}

});

const searchInput =
document.getElementById("searchIcon");

searchInput.addEventListener("keyup", function(){

const keyword =
this.value.toLowerCase();

iconItems.forEach(item=>{

const icon =
item.dataset.icon.toLowerCase();

if(icon.includes(keyword)){

item.style.display="flex";

}else{

item.style.display="none";

}

});

});

window.addEventListener("load",()=>{

preview.className=
"fa-solid "+hidden.value;

});

</script>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>