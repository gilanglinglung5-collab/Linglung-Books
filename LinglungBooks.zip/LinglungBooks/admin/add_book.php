<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';

$categories = mysqli_query($conn,"
SELECT *
FROM categories
ORDER BY category_name ASC
");

$message = "";

if(isset($_POST['save'])){

$category_id = $_POST['category_id'];
$title = mysqli_real_escape_string($conn,$_POST['title']);
$author = mysqli_real_escape_string($conn,$_POST['author']);
$publisher = mysqli_real_escape_string($conn,$_POST['publisher']);
$price = $_POST['price'];
$cost_price = (isset($_POST['cost_price']) && $_POST['cost_price'] !== '') ? (float)$_POST['cost_price'] : null;
$cost_price_sql = ($cost_price === null) ? 'NULL' : (string)$cost_price;
$stock = $_POST['stock'];
$description = mysqli_real_escape_string($conn,$_POST['description']);

$cover_name = $_FILES['cover']['name'];
$cover_tmp = $_FILES['cover']['tmp_name'];

if($cover_name!=""){

$extension = strtolower(pathinfo($cover_name,PATHINFO_EXTENSION));

$allowed=['jpg','jpeg','png','webp'];

if(in_array($extension,$allowed)){

$new_cover = uniqid().".".$extension;

move_uploaded_file(
$cover_tmp,
"../assets/img/".$new_cover
);

$insert=mysqli_query($conn,"
INSERT INTO books
(
category_id,
title,
author,
publisher,
price,
cost_price,
stock,
description,
cover
)
VALUES
(
'$category_id',
'$title',
'$author',
'$publisher',
'$price',
$cost_price_sql,
'$stock',
'$description',
'$new_cover'
)
");

if($insert){
header("Location: books.php");
exit;
}else{
$message="Failed to add book.";
}

}else{

$message="Only JPG, JPEG, PNG & WEBP allowed.";

}

}else{

$message="Please choose a cover image.";

}

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Add Book | LinglungBooks</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
margin:0;
padding:0;
box-sizing:border-box;
font-family:Poppins,sans-serif;
}

body{
background:#F8F3EC;
}

.container{
width:95%;
max-width:900px;
margin:40px auto;
}

.header{
background:white;
padding:25px 30px;
border-radius:18px;
box-shadow:0 8px 20px rgba(0,0,0,.08);
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:25px;
}

.header h1{
font-size:28px;
color:#5A3825;
}

.btn{
text-decoration:none;
background:#6F4E37;
color:white;
padding:11px 18px;
border-radius:10px;
transition:.3s;
}

.btn:hover{
background:#8B5E3C;
}

.form-card{
background:white;
padding:35px;
border-radius:18px;
box-shadow:0 8px 20px rgba(0,0,0,.08);
}

.message{
background:#F8D7DA;
color:#842029;
padding:15px;
border-radius:10px;
margin-bottom:25px;
}

.form-grid{
display:grid;
grid-template-columns:repeat(2,1fr);
gap:20px;
}

.input-group{
display:flex;
flex-direction:column;
}

.input-group.full{
grid-column:1 / 3;
}

label{
margin-bottom:8px;
font-weight:600;
color:#5A3825;
}

input,
select,
textarea{
width:100%;
padding:13px 15px;
border:1px solid #DDD;
border-radius:10px;
font-size:14px;
outline:none;
transition:.3s;
}

input:focus,
select:focus,
textarea:focus{
border-color:#8B5E3C;
box-shadow:0 0 0 3px rgba(111,78,55,.12);
}

textarea{
height:160px;
resize:vertical;
}

input[type=file]{
padding:10px;
background:#FCF8F3;
}

.button-group{
margin-top:30px;
display:flex;
justify-content:flex-end;
gap:15px;
}

.cancel-btn{
text-decoration:none;
padding:13px 24px;
border-radius:10px;
background:#E7D8C9;
color:#5A3825;
transition:.3s;
}

.cancel-btn:hover{
background:#D7C0AA;
}

.save-btn{
border:none;
padding:13px 28px;
border-radius:10px;
background:#6F4E37;
color:white;
font-size:15px;
font-weight:600;
cursor:pointer;
transition:.3s;
}

.save-btn:hover{
background:#8B5E3C;
}

@media(max-width:768px){

.form-grid{
grid-template-columns:1fr;
}

.input-group.full{
grid-column:auto;
}

.button-group{
flex-direction:column;
}

.cancel-btn,
.save-btn{
width:100%;
text-align:center;
}

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
<link rel="stylesheet" href="../assets/css/admin-sidebar.css">
<style>.container{margin:35px 3% 60px calc(260px + 3%);width:calc(94% - 260px);max-width:none}@media(max-width:760px){.container{margin:20px auto;width:94%}}</style>
</head>

<body>
<?php include __DIR__ . '/sidebar.php'; ?>

<div class="container">

<div class="header">

<h1>Add New Book</h1>
</div>

<div class="form-card">

<?php if($message!=""){ ?>

<div class="message">

<?= $message; ?>

</div>

<?php } ?>

<form method="POST" enctype="multipart/form-data">

<div class="form-grid">

<div class="input-group">

<label>Category</label>

<select name="category_id" required>

<option value="">Select Category</option>

<?php while($cat=mysqli_fetch_assoc($categories)){ ?>

<option value="<?= $cat['id']; ?>">

<?= htmlspecialchars($cat['category_name']); ?>

</option>

<?php } ?>

</select>

</div>

<div class="input-group">

<label>Book Title</label>

<input
type="text"
name="title"
required>

</div>

<div class="input-group">

<label>Author</label>

<input
type="text"
name="author"
required>

</div>

<div class="input-group">

<label>Publisher</label>

<input
type="text"
name="publisher">

</div>

<div class="input-group">

<label>Price</label>

<input
type="number"
name="price"
min="0"
placeholder="Enter book price"
required>

</div>

<div class="input-group">
<label>Harga Modal (harga beli buku)</label>
<input type="number" name="cost_price" min="0" step="0.01" placeholder="Harga modal buku">
<small>Isi agar keuntungan transaksi bisa dihitung.</small>
</div>

<div class="input-group">

<label>Stock</label>

<input
type="number"
name="stock"
min="0"
placeholder="Enter stock"
required>

</div>

<div class="input-group full">

<label>Description</label>

<textarea
name="description"
placeholder="Write book description..."></textarea>

</div>

<div class="input-group full">

<label>Book Cover</label>

<input
type="file"
name="cover"
accept=".jpg,.jpeg,.png,.webp"
required>

</div>

</div>

<div class="button-group">

<a href="books.php" class="cancel-btn">

Cancel

</a>

<button
type="submit"
name="save"
class="save-btn">

Save Book

</button>

</div>

</form>

</div>

</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>