<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


/* =========================================================
   SEARCH & FILTER
========================================================= */

$search = "";
$status_filter = "";

$where = "WHERE 1=1";


if (isset($_GET['search']) && trim($_GET['search']) != "") {

    $search = mysqli_real_escape_string(
        $conn,
        trim($_GET['search'])
    );

    $where .= "
        AND (
            users.fullname LIKE '%$search%'
            OR users.username LIKE '%$search%'
            OR orders.recipient_name LIKE '%$search%'
            OR orders.phone LIKE '%$search%'
        )
    ";
}


if (
    isset($_GET['filter_status']) &&
    $_GET['filter_status'] != ""
) {

    $status_filter = mysqli_real_escape_string(
        $conn,
        $_GET['filter_status']
    );

    $where .= "
        AND LOWER(orders.status) = LOWER('$status_filter')
    ";
}


/* =========================================================
   GET ORDERS
   Mengambil jumlah item dari order_details
========================================================= */

$query = mysqli_query(
    $conn,
    "
    SELECT
        orders.id,
        orders.transaction_code,
        orders.user_id,
        orders.recipient_name,
        orders.phone,
        orders.address,
        orders.total_price,
        orders.status,
        orders.payment_method,
        orders.created_at,

        users.fullname,
        users.username,

        COALESCE(
            SUM(order_details.quantity),
            0
        ) AS total_items

    FROM orders

    LEFT JOIN users
        ON orders.user_id = users.id

    LEFT JOIN order_details
        ON orders.id = order_details.order_id

    $where

    GROUP BY
        orders.id,
        orders.transaction_code,
        orders.user_id,
        orders.recipient_name,
        orders.phone,
        orders.address,
        orders.total_price,
        orders.status,
        orders.payment_method,
        orders.created_at,
        users.fullname,
        users.username

    ORDER BY orders.id DESC
    "
);


/* =========================================================
   STATISTICS - seluruh status pesanan ditampilkan
========================================================= */

$status_counts = [
    'Processing' => 0,
    'Packed' => 0,
    'Shipped' => 0,
    'Received' => 0,
    'Completed' => 0,
    'ReturnRequested' => 0,
    'ReturnApproved' => 0,
    'ReturnRejected' => 0,
    'ReturnShipped' => 0,
    'Returned' => 0,
    'Refunded' => 0,
    'Cancelled' => 0,
];
$total_orders = 0;
$countQuery = mysqli_query($conn, "SELECT status, COUNT(*) AS total FROM orders GROUP BY status");
if ($countQuery) {
    while ($countData = mysqli_fetch_assoc($countQuery)) {
        $key = (string)($countData['status'] ?? '');
        $count = (int)($countData['total'] ?? 0);
        if (array_key_exists($key, $status_counts)) {
            $status_counts[$key] = $count;
        }
        $total_orders += $count;
    }
}

$status_cards = [
    ['label' => 'Diproses', 'key' => 'Processing', 'icon' => 'fa-clock'],
    ['label' => 'Dikemas', 'key' => 'Packed', 'icon' => 'fa-box'],
    ['label' => 'Dikirim', 'key' => 'Shipped', 'icon' => 'fa-truck'],
    ['label' => 'Diterima', 'key' => 'Received', 'icon' => 'fa-box-open'],
    ['label' => 'Selesai', 'key' => 'Completed', 'icon' => 'fa-check-circle'],
    ['label' => 'Retur Menunggu', 'key' => 'ReturnRequested', 'icon' => 'fa-clock-rotate-left'],
    ['label' => 'Retur Disetujui', 'key' => 'ReturnApproved', 'icon' => 'fa-clipboard-check'],
    ['label' => 'Retur Ditolak', 'key' => 'ReturnRejected', 'icon' => 'fa-ban'],
    ['label' => 'Retur Dikirim', 'key' => 'ReturnShipped', 'icon' => 'fa-truck-fast'],
    ['label' => 'Retur Tiba di Gudang', 'key' => 'Returned', 'icon' => 'fa-warehouse'],
    ['label' => 'Dana Dikembalikan', 'key' => 'Refunded', 'icon' => 'fa-money-bill-transfer'],
    ['label' => 'Dibatalkan', 'key' => 'Cancelled', 'icon' => 'fa-xmark-circle'],
];


/* =========================================================
   ADMIN PROFILE
========================================================= */

$adminName =
    $_SESSION['fullname'] ?? 'Admin';


$initial =
    strtoupper(
        substr($adminName, 0, 1)
    );

?>

<!DOCTYPE html>

<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    Manage Orders | LinglungBooks
</title>


<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
>


<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
>


<style>

/* =========================================================
   RESET
========================================================= */

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Poppins,sans-serif;
}


/* =========================================================
   BODY
========================================================= */

body{
    background:#F8F3EC;
    display:flex;
    color:#3E2C23;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar{
    width:260px;
    height:100vh;

    background:#6F4E37;
    color:white;

    padding:30px 20px;

    position:fixed;
    left:0;
    top:0;

    display:flex;
    flex-direction:column;

    z-index:10;
}


/* =========================================================
   LOGO
========================================================= */

.logo{
    display:flex;
    align-items:center;
    justify-content:center;

    gap:12px;

    margin-bottom:45px;
}


.logo-icon{
    display:flex;
    align-items:center;
    justify-content:center;
}


.logo-icon i{
    font-size:28px;
    color:#E8C39E;
}


.logo-text h2{
    font-size:24px;
    font-weight:700;
}


.logo-text span{
    color:#E8C39E;
}


/* =========================================================
   SIDEBAR LINKS
========================================================= */

.sidebar a{
    display:flex;
    align-items:center;

    gap:12px;

    text-decoration:none;
    color:white;

    padding:15px 18px;

    border-radius:14px;

    margin-bottom:12px;

    transition:.25s;

    font-weight:500;
}


.sidebar a i{
    width:22px;

    text-align:center;

    font-size:17px;

    color:#E8C39E;
}


.sidebar a:hover{
    background:#8B5E3C;

    transform:translateX(4px);
}


.sidebar a.active{
    background:#8B5E3C;

    box-shadow:0 8px 18px rgba(0,0,0,.15);
}


/* =========================================================
   MAIN
========================================================= */

.main{
    margin-left:260px;

    width:calc(100% - 260px);

    min-height:100vh;
}


/* =========================================================
   HEADER
========================================================= */

.header{
    height:82px;

    background:white;

    display:flex;

    justify-content:space-between;
    align-items:center;

    padding:0 40px;

    box-shadow:0 5px 18px rgba(0,0,0,.06);
}


.header h2{
    color:#5A3825;

    font-size:27px;

    font-weight:700;
}


/* =========================================================
   ADMIN PROFILE
========================================================= */

.admin-box{
    display:flex;

    align-items:center;

    gap:15px;
}


.admin-info{
    text-align:right;
}


.admin-info small{
    display:block;

    font-size:12px;

    color:#888;

    margin-bottom:2px;
}


.admin-info strong{
    color:#6F4E37;

    font-size:15px;
}


.admin-avatar{
    width:46px;
    height:46px;

    border-radius:50%;

    background:#6F4E37;

    color:white;

    display:flex;
    align-items:center;
    justify-content:center;

    font-size:20px;

    font-weight:600;

    box-shadow:0 5px 15px rgba(111,78,55,.25);
}


/* =========================================================
   CONTAINER
========================================================= */

.container{
    padding:40px;
}


/* =========================================================
   TOP BAR
========================================================= */

.top-bar{
    display:flex;

    justify-content:space-between;
    align-items:center;

    margin-bottom:25px;
}


.back{
    display:inline-flex;

    align-items:center;

    gap:8px;

    text-decoration:none;

    font-weight:500;

    color:#6F4E37;

    transition:.25s;
}


.back:hover{
    color:#8B5E3C;

    transform:translateX(-3px);
}


/* =========================================================
   STATISTICS
========================================================= */

.stats {
    display: grid;
    grid-template-columns: repeat(5, minmax(0, 1fr));
    gap: 18px;
    width: 100%;
    margin-bottom: 25px;
}


.stat-card{
    background:white;

    border-radius:16px;

    padding:18px;

    box-shadow:0 8px 20px rgba(0,0,0,.06);

    min-width:0;
}


.stat-top{
    display:flex;

    align-items:center;

    justify-content:space-between;

    margin-bottom:10px;
}


.stat-icon{
    width:38px;
    height:38px;

    border-radius:10px;

    background:#F3E8D8;

    color:#6F4E37;

    display:flex;

    align-items:center;
    justify-content:center;
}


.stat-label{
    font-size:12px;

    color:#888;

    font-weight:500;
}


.stat-number{
    font-size:22px;

    font-weight:700;

    color:#5A3825;
}


/* =========================================================
   SEARCH
========================================================= */

.search-card{
    background:white;

    padding:20px;

    border-radius:18px;

    margin-bottom:25px;

    box-shadow:0 8px 20px rgba(0,0,0,.08);
}


.search-form{
    display:grid;

    grid-template-columns:
        minmax(0,1fr)
        190px
        auto
        auto;

    gap:10px;

    align-items:center;
}


.search-input{
    width:100%;

    padding:13px 15px;

    border:1px solid #DDD;

    border-radius:10px;

    outline:none;

    font-size:14px;
}


.search-input:focus{
    border-color:#8B5E3C;
}


.filter-select{
    width:100%;

    padding:13px 14px;

    border:1px solid #DDD;

    border-radius:10px;

    outline:none;

    background:white;

    color:#3E2C23;

    font-size:13px;

    cursor:pointer;
}


.filter-select:focus{
    border-color:#8B5E3C;
}


.search-btn{
    padding:13px 22px;

    border:none;

    background:#6F4E37;

    color:white;

    border-radius:10px;

    cursor:pointer;

    font-weight:600;

    transition:.25s;

    white-space:nowrap;
}


.search-btn:hover{
    background:#8B5E3C;
}


.reset-btn{
    padding:13px 18px;

    border-radius:10px;

    background:#F3E8D8;

    color:#6F4E37;

    text-decoration:none;

    font-size:13px;

    font-weight:600;

    white-space:nowrap;

    transition:.25s;
}


.reset-btn:hover{
    background:#E8D8C4;
}


/* =========================================================
   TABLE CARD
========================================================= */

.table-card{
    background:white;

    border-radius:20px;

    overflow:hidden;

    box-shadow:0 8px 20px rgba(0,0,0,.08);
}


.table-header{
    padding:20px 24px;

    border-bottom:1px solid #EEE5DB;

    display:flex;

    justify-content:space-between;
    align-items:center;
}


.table-header h3{
    color:#5A3825;

    font-size:18px;
}


.table-header span{
    font-size:12px;

    color:#888;
}


/* =========================================================
   TABLE WRAPPER
========================================================= */

.table-wrapper{
    width:100%;

    overflow-x:auto;
}


/* =========================================================
   TABLE
========================================================= */

.orders-table{
    width:100%;

    min-width:1150px;

    border-collapse:collapse;

    table-layout:fixed;
}


/* =========================================================
   COLUMN WIDTH
========================================================= */

.col-id{
    width:80px;
}

.col-customer{
    width:190px;
}

.col-recipient{
    width:190px;
}

.col-item{
    width:85px;
}

.col-payment{
    width:145px;
}

.col-total{
    width:150px;
}

.col-status{
    width:125px;
}

.col-date{
    width:150px;
}

.col-action{
    width:135px;
}


/* =========================================================
   TABLE HEADER
========================================================= */

.orders-table th{
    background:#6F4E37;

    color:white;

    padding:16px 14px;

    font-size:12px;

    font-weight:600;

    text-align:left;

    white-space:nowrap;
}


.orders-table th.center{
    text-align:center;
}


.orders-table th.right{
    text-align:right;
}


/* =========================================================
   TABLE BODY
========================================================= */

.orders-table tbody tr{
    height:82px;

    transition:.15s;
}


.orders-table tbody tr:hover{
    background:#FCF7F1;
}


.orders-table td{
    padding:13px 14px;

    border-bottom:1px solid #EEE5DB;

    font-size:13px;

    vertical-align:middle;

    height:82px;
}


.orders-table tbody tr:last-child td{
    border-bottom:none;
}


/* =========================================================
   ORDER ID
========================================================= */

.order-id{
    text-align:center;

    font-weight:700;

    color:#6F4E37;
}


/* =========================================================
   CUSTOMER
========================================================= */

.customer-cell{
    display:flex;

    align-items:center;

    gap:10px;

    min-width:0;
}


.avatar{
    width:40px;
    height:40px;

    min-width:40px;

    border-radius:50%;

    background:#F3E8D8;

    display:flex;

    align-items:center;
    justify-content:center;

    font-weight:700;

    color:#6F4E37;
}


.customer-text{
    min-width:0;

    width:calc(100% - 50px);
}


.customer-name{
    display:block;

    color:#4B3621;

    font-size:13px;

    font-weight:600;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}


.customer-username{
    display:block;

    color:#999;

    font-size:11px;

    margin-top:2px;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}


/* =========================================================
   RECIPIENT
========================================================= */

.recipient{
    color:#4B3621;

    font-weight:500;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}


.phone{
    display:block;

    color:#999;

    font-size:11px;

    margin-top:3px;
}


/* =========================================================
   ITEM
========================================================= */

.item-cell{
    text-align:center;
}


.item-number{
    font-size:15px;

    font-weight:700;

    color:#5A3825;
}


.item-label{
    display:block;

    font-size:10px;

    color:#999;

    margin-top:2px;
}


/* =========================================================
   PAYMENT
========================================================= */

.payment{
    color:#5A3825;

    font-weight:600;

    white-space:nowrap;

    overflow:hidden;

    text-overflow:ellipsis;
}


.payment i{
    color:#8B5E3C;

    margin-right:5px;
}


/* =========================================================
   TOTAL
========================================================= */

.total{
    text-align:right;

    color:#4B3621;

    font-weight:700;

    white-space:nowrap;
}


/* =========================================================
   STATUS
========================================================= */

.status-cell{
    text-align:center;
}


.badge{
    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:5px;

    min-width:95px;

    padding:7px 10px;

    border-radius:25px;

    font-size:10px;

    font-weight:600;

    white-space:nowrap;
}


.shipped{
    background:#E2EFFF;
    color:#245A91;
}

.pending{
    background:#FFF3CD;

    color:#856404;
}


.paid{
    background:#D4EDDA;

    color:#155724;
}


.completed{
    background:#E5D9C8;

    color:#5A3825;
}


.cancelled{
    background:#F8D7DA;

    color:#721C24;
}


/* =========================================================
   DATE
========================================================= */

.date-cell{
    line-height:1.5;

    white-space:nowrap;
}


.date-main{
    display:block;

    font-weight:600;

    color:#5A3825;
}


.date-time{
    display:block;

    color:#999;

    font-size:11px;
}


/* =========================================================
   ACTION
========================================================= */

.action-cell{
    text-align:center;
}


.view{
    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:7px;

    width:112px;

    padding:9px 10px;

    background:#6F4E37;

    color:white;

    text-decoration:none;

    border-radius:8px;

    transition:.25s;

    font-size:11px;

    font-weight:600;

    white-space:nowrap;
}


.view:hover{
    background:#8B5E3C;
}

.delete{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;

    width:112px;
    padding:9px 10px;

    background:#F8D7DA;
    color:#721C24;

    text-decoration:none;
    border-radius:8px;

    transition:.25s;

    font-size:11px;
    font-weight:600;

    white-space:nowrap;
}

.delete:hover{
    background:#F1BFC3;
}

.action-cell .view,
.action-cell .delete{
    margin:3px;
}

/* =========================================================
   EMPTY
========================================================= */

.empty{
    padding:65px 40px !important;

    text-align:center;

    color:#777;
}


.empty i{
    display:block;

    font-size:50px;

    color:#C6A27D;

    margin-bottom:15px;
}


.empty h3{
    margin-bottom:8px;

    color:#5A3825;

    font-size:17px;
}


.empty p{
    font-size:13px;

    color:#999;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1250px){

    .stats{
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }


    .search-form{
        grid-template-columns:
            1fr 180px;
    }


    .search-btn,
    .reset-btn{
        text-align:center;
    }

}


@media(max-width:900px){

    body{
        display:block;
    }


    .sidebar{
        width:100%;

        height:auto;

        position:relative;

        padding:20px;
    }


    .logo{
        margin-bottom:25px;
    }


    .main{
        margin-left:0;

        width:100%;
    }


    .header{
        padding:20px;

        height:auto;

        flex-direction:column;

        gap:15px;

        align-items:flex-start;
    }


    .container{
        padding:20px;
    }

}


@media(max-width:600px){

    .stats{
        grid-template-columns:
            repeat(2, minmax(0, 1fr));
    }


    .admin-box{
        width:100%;

        justify-content:space-between;
    }


    .admin-info{
        text-align:left;
    }


    .search-form{
        grid-template-columns:1fr;
    }


    .search-btn,
    .reset-btn{
        width:100%;
    }

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">
</head>


<body>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="main">


    <!-- HEADER -->

    <div class="header">


        <h2>
            Manage Orders
        </h2>


        <div class="admin-box">


            <div class="admin-info">

                <small>
                    Administrator
                </small>

                <strong>
                    <?= htmlspecialchars($adminName); ?>
                </strong>

            </div>


            <div class="admin-avatar">

                <?= htmlspecialchars($initial); ?>

            </div>


        </div>


    </div>



    <!-- CONTENT -->

    <div class="container">


        <!-- BACK -->
<!-- =================================================
             STATISTICS
        ================================================== -->

        <div class="stats">

            <div class="stat-card">
                <div class="stat-top">
                    <span class="stat-label">Total Orders</span>
                    <div class="stat-icon"><i class="fa-solid fa-cart-shopping"></i></div>
                </div>
                <div class="stat-number"><?= $total_orders; ?></div>
            </div>

            <?php foreach ($status_cards as $card): ?>
                <div class="stat-card">
                    <div class="stat-top">
                        <span class="stat-label"><?= htmlspecialchars($card['label']); ?></span>
                        <div class="stat-icon"><i class="fa-solid <?= htmlspecialchars($card['icon']); ?>"></i></div>
                    </div>
                    <div class="stat-number"><?= (int)($status_counts[$card['key']] ?? 0); ?></div>
                </div>
            <?php endforeach; ?>

        </div>


        <div class="search-card">


            <form
                class="search-form"
                method="GET"
            >


                <input
                    type="text"
                    name="search"
                    class="search-input"
                    placeholder="Search customer, username, recipient, or phone..."
                    value="<?= htmlspecialchars($search); ?>"
                >


                <select name="filter_status" class="filter-select">
                    <option value="">Semua Status</option>
                    <option value="Processing" <?= $status_filter === 'Processing' ? 'selected' : ''; ?>>Diproses</option>
                    <option value="Packed" <?= $status_filter === 'Packed' ? 'selected' : ''; ?>>Dikemas</option>
                    <option value="Shipped" <?= $status_filter === 'Shipped' ? 'selected' : ''; ?>>Dikirim</option>
                    <option value="Received" <?= $status_filter === 'Received' ? 'selected' : ''; ?>>Diterima</option>
                    <option value="Completed" <?= $status_filter === 'Completed' ? 'selected' : ''; ?>>Selesai</option>
                    <option value="ReturnRequested" <?= $status_filter === 'ReturnRequested' ? 'selected' : ''; ?>>Retur Menunggu</option>
                    <option value="ReturnApproved" <?= $status_filter === 'ReturnApproved' ? 'selected' : ''; ?>>Retur Disetujui</option>
                    <option value="ReturnRejected" <?= $status_filter === 'ReturnRejected' ? 'selected' : ''; ?>>Retur Ditolak</option>
                    <option value="ReturnShipped" <?= $status_filter === 'ReturnShipped' ? 'selected' : ''; ?>>Retur Dikirim</option>
                    <option value="Returned" <?= $status_filter === 'Returned' ? 'selected' : ''; ?>>Retur Tiba</option>
                    <option value="Refunded" <?= $status_filter === 'Refunded' ? 'selected' : ''; ?>>Dana Dikembalikan</option>
                    <option value="Cancelled" <?= $status_filter === 'Cancelled' ? 'selected' : ''; ?>>Dibatalkan</option>
                </select>


                <button
                    type="submit"
                    class="search-btn"
                >

                    <i class="fa-solid fa-magnifying-glass"></i>

                    Search

                </button>


                <?php if (
                    $search != "" ||
                    $status_filter != ""
                ): ?>

                    <a
                        href="orders.php"
                        class="reset-btn"
                    >

                        <i class="fa-solid fa-rotate-left"></i>

                        Reset

                    </a>

                <?php else: ?>

                    <div></div>

                <?php endif; ?>


            </form>


        </div>



        <!-- =================================================
             ORDER TABLE
        ================================================== -->

        <div class="table-card">


            <div class="table-header">

                <h3>
                    Order List
                </h3>


                <span>

                    <?= $query
                        ? mysqli_num_rows($query)
                        : 0;
                    ?>

                    order ditampilkan

                </span>

            </div>


            <div class="table-wrapper">


                <table class="orders-table">


                    <colgroup>

                        <col class="col-id">

                        <col class="col-customer">

                        <col class="col-recipient">

                        <col class="col-item">

                        <col class="col-payment">

                        <col class="col-total">

                        <col class="col-status">

                        <col class="col-date">

                        <col class="col-action">

                    </colgroup>


                    <thead>

                        <tr>

                            <th class="center">
                                Order ID
                            </th>


                            <th>
                                Customer
                            </th>


                            <th>
                                Recipient
                            </th>


                            <th class="center">
                                Items
                            </th>


                            <th>
                                Payment
                            </th>


                            <th class="right">
                                Total
                            </th>


                            <th class="center">
                                Status
                            </th>


                            <th>
                                Order Date
                            </th>


                            <th class="center">
                                Action
                            </th>

                        </tr>

                    </thead>


                    <tbody>


                    <?php if (
                        $query &&
                        mysqli_num_rows($query) > 0
                    ): ?>


                        <?php while (
                            $order =
                            mysqli_fetch_assoc($query)
                        ): ?>


                            <?php

                            $status =
                                strtolower(
                                    trim(
                                        $order['status']
                                    )
                                );


                            $fullname =
                                !empty($order['fullname'])
                                ? $order['fullname']
                                : 'Unknown Customer';


                            $username =
                                !empty($order['username'])
                                ? $order['username']
                                : '-';


                            $recipient =
                                !empty(
                                    $order['recipient_name']
                                )
                                ? $order['recipient_name']
                                : '-';


                            $phone =
                                !empty(
                                    $order['phone']
                                )
                                ? $order['phone']
                                : '';


                            $payment = match ($order['payment_method'] ?? '') {
                                'Transfer' => 'Transfer Bank',
                                'DANA' => 'DANA',
                                'GoPay' => 'GoPay',
                                'QRIS' => 'QRIS',
                                'COD' => 'COD',
                                default => '-'
                            };


                            $totalItems =
                                (int)
                                $order['total_items'];


                            $firstLetter =
                                strtoupper(
                                    substr(
                                        $fullname,
                                        0,
                                        1
                                    )
                                );


                            $orderDate =
                                strtotime(
                                    $order['created_at']
                                );

                            ?>


                            <tr>


                                <!-- KODE TRANSAKSI: menampilkan kode DDMMYYNNN, bukan primary key internal. -->
<!-- ORDER ID -->

                                <td class="order-id">

                                    #<?= htmlspecialchars($order['transaction_code'] ?? (string)$order['id'], ENT_QUOTES, 'UTF-8'); ?>

                                </td>



                                <!-- CUSTOMER -->

                                <td>

                                    <div class="customer-cell">


                                        <div class="avatar">

                                            <?= htmlspecialchars(
                                                $firstLetter
                                            ); ?>

                                        </div>


                                        <div class="customer-text">


                                            <span
                                                class="customer-name"
                                                title="<?= htmlspecialchars($fullname); ?>"
                                            >

                                                <?= htmlspecialchars(
                                                    $fullname
                                                ); ?>

                                            </span>


                                            <span
                                                class="customer-username"
                                                title="@<?= htmlspecialchars($username); ?>"
                                            >

                                                @<?= htmlspecialchars(
                                                    $username
                                                ); ?>

                                            </span>


                                        </div>


                                    </div>

                                </td>



                                <!-- RECIPIENT -->

                                <td>


                                    <div
                                        class="recipient"
                                        title="<?= htmlspecialchars($recipient); ?>"
                                    >

                                        <?= htmlspecialchars(
                                            $recipient
                                        ); ?>

                                    </div>


                                    <?php if ($phone != ""): ?>

                                        <span class="phone">

                                            <?= htmlspecialchars(
                                                $phone
                                            ); ?>

                                        </span>

                                    <?php endif; ?>


                                </td>



                                <!-- ITEMS -->

                                <td class="item-cell">


                                    <span class="item-number">

                                        <?= $totalItems; ?>

                                    </span>


                                    <span class="item-label">

                                        <?= $totalItems == 1
                                            ? 'book'
                                            : 'books';
                                        ?>

                                    </span>


                                </td>



                                <!-- PAYMENT -->

                                <td>


                                    <div
                                        class="payment"
                                        title="<?= htmlspecialchars($payment); ?>"
                                    >


                                        <i
                                            class="fa-solid fa-credit-card"
                                        ></i>


                                        <?= htmlspecialchars(
                                            $payment
                                        ); ?>


                                    </div>


                                </td>



                                <!-- TOTAL -->

                                <td class="total">

                                    Rp<?= number_format(
                                        $order['total_price'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </td>



                                <!-- STATUS -->
                                <td class="status-cell">
                                    <?php
                                      $statusLabels = ['processing'=>'Diproses','packed'=>'Dikemas','shipped'=>'Dikirim','received'=>'Diterima','completed'=>'Selesai','returnrequested'=>'Retur Menunggu','returnapproved'=>'Retur Disetujui','returnrejected'=>'Retur Ditolak','returnshipped'=>'Retur Dikirim','returned'=>'Retur Tiba di Gudang','refunded'=>'Dana Dikembalikan','cancelled'=>'Dibatalkan'];
                                      $statusKey = strtolower(str_replace('_','',$order['status'] ?? 'processing'));
                                      $statusLabel = $statusLabels[$statusKey] ?? 'Diproses';
                                      $statusBadge = in_array($statusKey,['completed','refunded'],true) ? 'completed' : (in_array($statusKey,['shipped','returnshipped'],true) ? 'shipped' : 'pending');
                                    ?>
                                    <span class="badge <?= $statusBadge; ?>"><?= htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8'); ?></span>
                                </td>


                                <!-- DATE -->

                                <td class="date-cell">


                                    <span class="date-main">

                                        <?= $orderDate
                                            ? date(
                                                "d M Y",
                                                $orderDate
                                            )
                                            : '-';
                                        ?>

                                    </span>


                                    <?php if ($orderDate): ?>

                                        <span class="date-time">

                                            <?= date(
                                                "H:i",
                                                $orderDate
                                            ); ?>

                                            WIB

                                        </span>

                                    <?php endif; ?>


                                </td>



                                <!-- ACTION -->

                               <td class="action-cell">

    <a
        class="view"
        href="order_detail.php?id=<?= (int)$order['id']; ?>"
    >

        <i class="fa-solid fa-eye"></i>

        View Detail

    </a>

    <a
        class="delete"
        href="delete_order.php?id=<?= (int)$order['id']; ?>"
        onclick="return confirm('Are you sure you want to delete this order? This action cannot be undone.');"
    >

        <i class="fa-solid fa-trash"></i>

        Delete

    </a>

</td>


                            </tr>


                        <?php endwhile; ?>


                    <?php else: ?>


                        <tr>

                            <td
                                colspan="9"
                                class="empty"
                            >

                                <i
                                    class="fa-solid fa-cart-shopping"
                                ></i>


                                <h3>
                                    No Orders Found
                                </h3>


                                <p>
                                    There are no orders matching your search.
                                </p>

                            </td>

                        </tr>


                    <?php endif; ?>


                    </tbody>


                </table>


            </div>


        </div>


    </div>


</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>