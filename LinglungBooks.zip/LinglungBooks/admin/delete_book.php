<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}


include '../config/database.php';



if(!isset($_GET['id'])){

    header("Location: books.php");
    exit;

}



$id = (int)$_GET['id'];



// Ambil cover buku

$stmt = mysqli_prepare(
    $conn,
    "SELECT cover FROM books WHERE id=?"
);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);


mysqli_stmt_execute($stmt);



$result = mysqli_stmt_get_result($stmt);


$book = mysqli_fetch_assoc($result);





if($book){


    // Hapus file cover

    if(!empty($book['cover'])){


        $image = "../assets/img/".$book['cover'];


        if(file_exists($image)){

            unlink($image);

        }

    }




    // Hapus data buku

    $delete = mysqli_prepare(
        $conn,
        "DELETE FROM books WHERE id=?"
    );


    mysqli_stmt_bind_param(
        $delete,
        "i",
        $id
    );


    mysqli_stmt_execute($delete);



}



header("Location: books.php");

exit;

?>