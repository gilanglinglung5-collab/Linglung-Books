
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';

/* =====================================================
   STATISTIK DASHBOARD
===================================================== */

// Total Buku
$totalBooks = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM books")
);

// Total Kategori
$totalCategories = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM categories")
);

// Total Pengguna
$totalUsers = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM users")
);

// Total Pesanan
$totalOrders = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM orders")
);

// Total Pesan
$totalMessages = mysqli_num_rows(
    mysqli_query($conn, "SELECT * FROM messages")
);

// Total Pendapatan
$revenueQuery = mysqli_query(
    $conn,
    "SELECT SUM(total_price) AS revenue FROM orders"
);

$revenueData = mysqli_fetch_assoc($revenueQuery);

$totalRevenue = $revenueData['revenue'] ?? 0;

// Informasi Admin
$fullname = $_SESSION['fullname'] ?? 'Admin';

$initial = strtoupper(substr($fullname, 0, 1));

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | LinglungBooks</title>

    <!-- GOOGLE FONT -->
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <!-- FONT AWESOME -->
    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >

    <!-- ADMIN CSS -->
    <link rel="stylesheet" href="../assets/css/admin.css">

    <link rel="stylesheet" href="../assets/css/admin-unified.css">

    <link rel="stylesheet" href="../assets/css/enhancements.css">

    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">

</head>

<body>

    <!-- SIDEBAR -->

    <?php include __DIR__ . '/sidebar.php'; ?>


    <div class="main">

        <!-- HEADER -->

        <div class="header">

            <h2>
                Admin Dashboard
            </h2>

            <div class="admin-box">

                <div class="admin-info">

                    <small>
                        Administrator
                    </small>

                    <strong>
                        <?= htmlspecialchars($fullname); ?>
                    </strong>

                </div>

                <div class="admin-avatar">
                    <?= htmlspecialchars($initial); ?>
                </div>

            </div>

        </div>


        <!-- CONTENT -->

        <div class="container">

            <!-- WELCOME -->

            <div class="welcome">

                <h2>
                    Welcome Back,
                    <?= htmlspecialchars($fullname); ?> 👋
                </h2>

                <p>
                    Manage your LinglungBooks bookstore system here.
                </p>

            </div>


            <!-- STATISTIC CARDS -->

            <div class="cards">

                <!-- BOOKS -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-book"></i>
                    </div>

                    <div class="number">
                        <?= number_format($totalBooks); ?>
                    </div>

                    <p>
                        Total Books
                    </p>

                </div>


                <!-- CATEGORIES -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>

                    <div class="number">
                        <?= number_format($totalCategories); ?>
                    </div>

                    <p>
                        Categories
                    </p>

                </div>


                <!-- USERS -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-users"></i>
                    </div>

                    <div class="number">
                        <?= number_format($totalUsers); ?>
                    </div>

                    <p>
                        Users
                    </p>

                </div>


                <!-- ORDERS -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-cart-shopping"></i>
                    </div>

                    <div class="number">
                        <?= number_format($totalOrders); ?>
                    </div>

                    <p>
                        Orders
                    </p>

                </div>


                <!-- MESSAGES -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-envelope"></i>
                    </div>

                    <div class="number">
                        <?= number_format($totalMessages); ?>
                    </div>

                    <p>
                        Messages
                    </p>

                </div>


                <!-- REVENUE -->

                <div class="card">

                    <div class="icon">
                        <i class="fa-solid fa-money-bill-wave"></i>
                    </div>

                    <div class="number">
                        Rp<?= number_format(
                            $totalRevenue,
                            0,
                            ",",
                            "."
                        ); ?>
                    </div>

                    <p>
                        Revenue
                    </p>

                </div>

            </div>


            <!-- FOOTER -->

            <div class="admin-footer">

                © <?= date('Y'); ?> LinglungBooks — Admin Dashboard

            </div>

        </div>

    </div>


    <script src="../assets/js/enhancements.js" defer></script>

</body>

</html>
