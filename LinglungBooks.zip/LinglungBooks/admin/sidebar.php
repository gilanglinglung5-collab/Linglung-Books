<?php
$currentPage = basename($_SERVER['PHP_SELF'] ?? '');
$adminMenu = [
    ['dashboard.php', 'fa-house', 'Dashboard'],
    ['books.php', 'fa-book', 'Manage Books'],
    ['categories.php', 'fa-layer-group', 'Categories'],
    ['users.php', 'fa-users', 'Users'],
    ['orders.php', 'fa-cart-shopping', 'Orders'],
    ['reports.php', 'fa-chart-line', 'Reports'],
    ['messages.php', 'fa-envelope', 'Messages'],
    ['logout.php', 'fa-right-from-bracket', 'Logout'],
];
?>
<aside class="sidebar lb-admin-sidebar">
    <div class="logo lb-admin-logo">
        <div class="logo-icon"><i class="fa-solid fa-book-open"></i></div>
        <div class="logo-text"><h2>Linglung<span>Books</span></h2></div>
    </div>
    <nav class="lb-admin-nav" aria-label="Menu Admin">
        <?php foreach ($adminMenu as [$href, $icon, $label]): ?>
            <a href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>" class="<?= $currentPage === $href ? 'active' : '' ?>">
                <i class="fa-solid <?= htmlspecialchars($icon, ENT_QUOTES, 'UTF-8') ?>"></i>
                <span><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></span>
            </a>
        <?php endforeach; ?>
    </nav>
</aside>
