<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}


if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}


include '../config/database.php';



if(!isset($_GET['id'])){

    header("Location: categories.php");
    exit;

}



$id = (int)$_GET['id'];




// cek apakah kategori masih dipakai buku

$check = mysqli_prepare(
    $conn,
    "SELECT id FROM books WHERE category_id=?"
);


mysqli_stmt_bind_param(
    $check,
    "i",
    $id
);


mysqli_stmt_execute($check);


$result = mysqli_stmt_get_result($check);





if(mysqli_num_rows($result)>0){


    echo "

    <script>

    alert('Category cannot be deleted because it is still used by books.');

    window.location='categories.php';

    </script>

    ";


    exit;


}





// hapus kategori

$delete = mysqli_prepare(
    $conn,
    "DELETE FROM categories WHERE id=?"
);



mysqli_stmt_bind_param(
    $delete,
    "i",
    $id
);



mysqli_stmt_execute($delete);



header("Location: categories.php");

exit;


?>