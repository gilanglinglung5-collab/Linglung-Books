<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


/* =========================
   SEARCH
========================= */

$search = "";

if (isset($_GET['search'])) {

    $search = mysqli_real_escape_string(
        $conn,
        $_GET['search']
    );

    $where = "
        WHERE fullname LIKE '%$search%'
        OR username LIKE '%$search%'
        OR email LIKE '%$search%'
        OR role LIKE '%$search%'
    ";

} else {

    $where = "";

}


/* =========================
   GET USERS
========================= */

$query = mysqli_query($conn, "
    SELECT
        id,
        fullname,
        email,
        username,
        role,
        created_at
    FROM users
    $where
    ORDER BY id DESC
");


/* =========================
   ADMIN INITIAL
========================= */

$initial = strtoupper(
    substr($_SESSION['fullname'], 0, 1)
);

?>

<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Users | LinglungBooks</title>


<!-- GOOGLE FONT -->

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
>


<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Poppins, sans-serif;
}


/* =========================
   BODY
========================= */

body {
    background: #F8F3EC;

    display: flex;

    color: #3E2C23;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {
    width: 260px;

    height: 100vh;

    background: #6F4E37;

    color: white;

    padding: 30px 20px;

    position: fixed;

    display: flex;

    flex-direction: column;
}


/* =========================
   LOGO
========================= */

.logo {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 12px;

    margin-bottom: 45px;
}

.logo-icon {
    display: flex;

    align-items: center;

    justify-content: center;
}

.logo-icon i {
    font-size: 28px;

    color: #E8C39E;
}

.logo-text h2 {
    font-size: 24px;

    font-weight: 700;
}

.logo-text span {
    color: #E8C39E;
}


/* =========================
   SIDEBAR MENU
========================= */

.sidebar a {
    display: flex;

    align-items: center;

    gap: 12px;

    text-decoration: none;

    color: white;

    padding: 15px 18px;

    border-radius: 14px;

    margin-bottom: 12px;

    transition: .25s;

    font-weight: 500;
}

.sidebar a i {
    width: 22px;

    text-align: center;

    font-size: 17px;

    color: #E8C39E;
}

.sidebar a:hover {
    background: #8B5E3C;

    transform: translateX(4px);
}

.sidebar a.active {
    background: #8B5E3C;

    box-shadow: 0 8px 18px rgba(0,0,0,.15);
}


/* =========================
   MAIN
========================= */

.main {
    margin-left: 260px;

    width: calc(100% - 260px);

    min-height: 100vh;
}


/* =========================
   HEADER
========================= */

.header {
    height: 82px;

    background: white;

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 0 40px;

    box-shadow: 0 5px 18px rgba(0,0,0,.06);
}

.header h2 {
    color: #5A3825;

    font-size: 27px;

    font-weight: 700;
}


/* =========================
   ADMIN PROFILE
========================= */

.admin-box {
    display: flex;

    align-items: center;

    gap: 15px;
}

.admin-info {
    text-align: right;
}

.admin-info small {
    display: block;

    font-size: 12px;

    color: #888;

    margin-bottom: 2px;
}

.admin-info strong {
    color: #6F4E37;

    font-size: 15px;
}

.admin-avatar {
    width: 46px;

    height: 46px;

    border-radius: 50%;

    background: #6F4E37;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    font-weight: 600;

    box-shadow: 0 5px 15px rgba(111,78,55,.25);
}


/* =========================
   CONTAINER
========================= */

.container {
    padding: 40px;
}


/* =========================
   TOP BAR
========================= */

.top-bar {
    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}

.back {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    text-decoration: none;

    color: #6F4E37;

    font-weight: 500;

    transition: .25s;
}

.back:hover {
    color: #8B5E3C;

    transform: translateX(-3px);
}


/* =========================
   SEARCH
========================= */

.search-card {
    background: white;

    padding: 22px;

    border-radius: 22px;

    box-shadow: 0 10px 25px rgba(0,0,0,.08);

    margin-bottom: 30px;
}

.search-box {
    display: flex;

    gap: 12px;
}

.search-box input {
    flex: 1;

    padding: 14px;

    border: 1px solid #ddd;

    border-radius: 12px;

    outline: none;

    font-size: 15px;
}

.search-box input:focus {
    border-color: #6F4E37;
}

.search-box button {
    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 8px;

    padding: 14px 25px;

    border: none;

    background: #6F4E37;

    color: white;

    border-radius: 12px;

    cursor: pointer;

    font-weight: 500;

    transition: .3s;
}

.search-box button:hover {
    background: #8B5E3C;
}


/* =========================
   TABLE
========================= */

.table-card {
    background: white;

    border-radius: 22px;

    overflow: hidden;

    box-shadow: 0 10px 25px rgba(0,0,0,.08);
}

table {
    width: 100%;

    border-collapse: collapse;
}

th {
    background: #6F4E37;

    color: white;

    padding: 16px;

    font-size: 14px;

    font-weight: 600;

    text-align: center;
}

td {
    padding: 16px;

    text-align: center;

    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #FCF8F3;
}


/* =========================
   USER AVATAR
========================= */

.avatar {
    width: 46px;

    height: 46px;

    border-radius: 50%;

    background: #F3E8D8;

    color: #6F4E37;

    display: flex;

    align-items: center;

    justify-content: center;

    font-weight: 700;

    font-size: 18px;

    margin: auto;
}


/* =========================
   USER NAME
========================= */

.user-name {
    color: #3E2C23;

    font-weight: 600;
}


/* =========================
   USERNAME
========================= */

.username {
    color: #6F4E37;

    font-weight: 500;
}


/* =========================
   ROLE BADGE
========================= */

.role {
    padding: 7px 14px;

    border-radius: 25px;

    font-size: 13px;

    font-weight: 600;

    display: inline-flex;

    align-items: center;

    gap: 6px;
}

.admin-role {
    background: #E8DCCF;

    color: #6F4E37;
}

.user-role {
    background: #F3E8D8;

    color: #8B5E3C;
}


/* =========================
   EMPTY
========================= */

.empty {
    padding: 45px;

    color: #777;
}

.empty-icon {
    font-size: 50px;

    color: #8B5E3C;

    margin-bottom: 15px;

    display: block;
}

.empty h3 {
    color: #5A3825;

    margin-bottom: 8px;
}


/* =========================
   FOOTER
========================= */

.admin-footer {
    text-align: center;

    padding: 35px 0 10px;

    color: #888;

    font-size: 14px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1200px) {

    .container {
        padding: 30px;
    }

    .table-card {
        overflow-x: auto;
    }

    table {
        min-width: 900px;
    }

}


@media (max-width: 1000px) {

    .header {
        padding: 0 30px;
    }

}


@media (max-width: 900px) {

    body {
        display: block;
    }

    .sidebar {
        width: 100%;

        height: auto;

        position: relative;

        padding: 20px;
    }

    .logo {
        margin-bottom: 25px;
    }

    .main {
        margin-left: 0;

        width: 100%;
    }

    .header {
        padding: 20px;

        height: auto;

        flex-direction: column;

        gap: 15px;

        align-items: flex-start;
    }

    .container {
        padding: 20px;
    }

}


@media (max-width: 600px) {

    .admin-info {
        text-align: left;
    }

    .admin-box {
        width: 100%;

        justify-content: space-between;
    }

    .search-box {
        flex-direction: column;
    }

    .search-box button {
        width: 100%;
    }

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">
</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="main">


    <!-- HEADER -->

    <div class="header">


        <h2>
            Manage Users
        </h2>


        <div class="admin-box">


            <div class="admin-info">

                <small>
                    Administrator
                </small>

                <strong>
                    <?= htmlspecialchars($_SESSION['fullname']); ?>
                </strong>

            </div>


            <div class="admin-avatar">

                <?= htmlspecialchars($initial); ?>

            </div>


        </div>


    </div>


    <!-- CONTENT -->

    <div class="container">


        <!-- TOP BAR -->
<!-- SEARCH -->

        <div class="search-card">


            <form
                class="search-box"
                method="GET"
            >


                <input
                    type="text"
                    name="search"
                    placeholder="Search user..."
                    value="<?= htmlspecialchars($search); ?>"
                >


                <button type="submit">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    Search

                </button>


            </form>


        </div>


        <!-- TABLE -->

        <div class="table-card">


            <table>


                <thead>

                    <tr>

                        <th>
                            No
                        </th>

                        <th>
                            Avatar
                        </th>

                        <th>
                            Full Name
                        </th>

                        <th>
                            Email
                        </th>

                        <th>
                            Username
                        </th>

                        <th>
                            Role
                        </th>

                        <th>
                            Registered
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($user = mysqli_fetch_assoc($query)) {

                ?>


                    <tr>


                        <!-- NO -->

                        <td>

                            <?= $no++; ?>

                        </td>


                        <!-- AVATAR -->

                        <td>

                            <div class="avatar">

                                <?= strtoupper(
                                    substr($user['fullname'], 0, 1)
                                ); ?>

                            </div>

                        </td>


                        <!-- FULL NAME -->

                        <td>

                            <strong class="user-name">

                                <?= htmlspecialchars(
                                    $user['fullname']
                                ); ?>

                            </strong>

                        </td>


                        <!-- EMAIL -->

                        <td>

                            <?= htmlspecialchars(
                                $user['email']
                            ); ?>

                        </td>


                        <!-- USERNAME -->

                        <td>

                            <span class="username">

                                @<?= htmlspecialchars(
                                    $user['username']
                                ); ?>

                            </span>

                        </td>


                        <!-- ROLE -->

                        <td>


                        <?php if ($user['role'] == 'admin') { ?>


                            <span class="role admin-role">

                                <i class="fa-solid fa-user-shield"></i>

                                Admin

                            </span>


                        <?php } else { ?>


                            <span class="role user-role">

                                <i class="fa-solid fa-user"></i>

                                User

                            </span>


                        <?php } ?>


                        </td>


                        <!-- REGISTERED -->

                        <td>

                            <?= date(
                                "d M Y",
                                strtotime($user['created_at'])
                            ); ?>

                        </td>


                    </tr>


                <?php

                    }

                } else {

                ?>


                    <tr>


                        <td
                            colspan="7"
                            class="empty"
                        >


                            <i
                                class="fa-solid fa-users empty-icon"
                            ></i>


                            <h3>

                                No Users Found

                            </h3>


                            <p>

                                There are no registered users.

                            </p>


                        </td>


                    </tr>


                <?php

                }

                ?>


                </tbody>


            </table>


        </div>


        <!-- FOOTER -->

        <div class="admin-footer">

            © <?= date('Y'); ?> LinglungBooks — Admin Dashboard

        </div>


    </div>


</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>