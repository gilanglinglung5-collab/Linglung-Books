<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_ADMIN');
    session_start();
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: ../user/login.php");
    exit;
}

include '../config/database.php';


// =========================
// GET MESSAGES
// =========================

$messageSearch = trim($_GET['search'] ?? '');
$messageWhere = '';
if ($messageSearch !== '') {
    $safeMessageSearch = mysqli_real_escape_string($conn, $messageSearch);
    $messageWhere = "WHERE users.fullname LIKE '%$safeMessageSearch%' OR users.email LIKE '%$safeMessageSearch%' OR messages.subject LIKE '%$safeMessageSearch%' OR messages.message LIKE '%$safeMessageSearch%'";
}
$query = mysqli_query($conn, "
    SELECT messages.*, users.fullname, users.email
    FROM messages LEFT JOIN users ON messages.user_id = users.id
    $messageWhere ORDER BY messages.id DESC
");


$initial = strtoupper(
    substr($_SESSION['fullname'], 0, 1)
);

?>

<!DOCTYPE html>

<html lang="en">

<head>
<link rel="stylesheet" href="../assets/css/admin-unified.css">

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Messages | LinglungBooks</title>


<!-- GOOGLE FONT -->

<link
    href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
    rel="stylesheet"
>


<!-- FONT AWESOME -->

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
>


<style>

/* =========================
   RESET
========================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Poppins, sans-serif;
}


/* =========================
   BODY
========================= */

body {
    background: #F8F3EC;

    display: flex;

    color: #3E2C23;
}


/* =========================
   SIDEBAR
========================= */

.sidebar {
    width: 260px;

    height: 100vh;

    background: #6F4E37;

    color: white;

    padding: 30px 20px;

    position: fixed;

    display: flex;

    flex-direction: column;
}


/* =========================
   LOGO
========================= */

.logo {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 12px;

    margin-bottom: 45px;
}

.logo-icon {
    display: flex;

    align-items: center;

    justify-content: center;
}

.logo-icon i {
    font-size: 28px;

    color: #E8C39E;
}

.logo-text h2 {
    font-size: 24px;

    font-weight: 700;
}

.logo-text span {
    color: #E8C39E;
}


/* =========================
   SIDEBAR MENU
========================= */

.sidebar a {
    display: flex;

    align-items: center;

    gap: 12px;

    text-decoration: none;

    color: white;

    padding: 15px 18px;

    border-radius: 14px;

    margin-bottom: 12px;

    transition: .25s;

    font-weight: 500;
}

.sidebar a i {
    width: 22px;

    text-align: center;

    font-size: 17px;

    color: #E8C39E;
}

.sidebar a:hover {
    background: #8B5E3C;

    transform: translateX(4px);
}

.sidebar a.active {
    background: #8B5E3C;

    box-shadow: 0 8px 18px rgba(0,0,0,.15);
}


/* =========================
   MAIN
========================= */

.main {
    margin-left: 260px;

    width: calc(100% - 260px);

    min-height: 100vh;
}


/* =========================
   HEADER
========================= */

.header {
    height: 82px;

    background: white;

    display: flex;

    justify-content: space-between;

    align-items: center;

    padding: 0 40px;

    box-shadow: 0 5px 18px rgba(0,0,0,.06);
}

.header h2 {
    color: #5A3825;

    font-size: 27px;

    font-weight: 700;
}


/* =========================
   ADMIN PROFILE
========================= */

.admin-box {
    display: flex;

    align-items: center;

    gap: 15px;
}

.admin-info {
    text-align: right;
}

.admin-info small {
    display: block;

    font-size: 12px;

    color: #888;

    margin-bottom: 2px;
}

.admin-info strong {
    color: #6F4E37;

    font-size: 15px;
}

.admin-avatar {
    width: 46px;
    height: 46px;

    border-radius: 50%;

    background: #6F4E37;

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 20px;

    font-weight: 600;

    box-shadow: 0 5px 15px rgba(111,78,55,.25);
}


/* =========================
   CONTAINER
========================= */

.container {
    padding: 40px;
}


/* =========================
   TOP BAR
========================= */

.top-bar {
    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 25px;
}

.back {
    display: inline-flex;

    align-items: center;

    gap: 8px;

    text-decoration: none;

    font-weight: 500;

    color: #6F4E37;

    transition: .25s;
}

.back:hover {
    color: #8B5E3C;

    transform: translateX(-3px);
}


/* =========================
   TABLE CARD
========================= */

.table-card {
    background: white;

    border-radius: 20px;

    overflow: hidden;

    box-shadow: 0 8px 20px rgba(0,0,0,.08);
}

table {
    width: 100%;

    border-collapse: collapse;
}

th {
    background: #6F4E37;

    color: white;

    padding: 16px;

    font-size: 14px;

    font-weight: 600;

    text-align: center;
}

td {
    padding: 15px;

    border-bottom: 1px solid #eee;

    vertical-align: top;

    font-size: 14px;
}

tr:hover {
    background: #FCF7F1;
}


/* =========================
   SUBJECT
========================= */

.subject {
    font-weight: 600;

    color: #5A3825;
}


/* =========================
   MESSAGE
========================= */

.message-box {
    max-width: 420px;

    line-height: 1.6;

    color: #666;
}


/* =========================
   ACTION
========================= */

.action-column {
    white-space: nowrap;
}

.action-buttons {
    display: flex;

    align-items: center;

    justify-content: center;

    gap: 10px;

    white-space: nowrap;
}

.action-btn,
.delete-btn {
    display: inline-flex;

    align-items: center;

    justify-content: center;

    gap: 6px;

    padding: 9px 14px;

    border-radius: 8px;

    text-decoration: none;

    font-size: 13px;

    font-weight: 500;

    transition: .25s;
}

.action-btn {
    background: #6F4E37;

    color: white;
}

.action-btn:hover {
    background: #8B5E3C;
}

.delete-btn {
    background: #B23B3B;

    color: white;
}

.delete-btn:hover {
    background: #8E2F2F;
}


/* =========================
   STATUS
========================= */

.status {
    display: inline-flex;

    align-items: center;

    gap: 6px;

    padding: 7px 12px;

    border-radius: 20px;

    font-size: 12px;

    font-weight: 600;
}

.status.replied {
    background: #D4EDDA;

    color: #155724;
}

.status.unreplied {
    background: #FFF3CD;

    color: #856404;
}


/* =========================
   EMPTY
========================= */

.empty {
    padding: 50px 35px;

    text-align: center;

    color: #777;
}

.empty i {
    font-size: 55px;

    color: #C6A27D;

    margin-bottom: 15px;
}

.empty h3 {
    margin: 12px 0;

    color: #5A3825;
}


/* =========================
   FOOTER
========================= */

.admin-footer {
    text-align: center;

    padding: 35px 0 10px;

    color: #888;

    font-size: 14px;
}


/* =========================
   RESPONSIVE
========================= */

@media (max-width: 1200px) {

    .container {
        padding: 25px;
    }

    .table-card {
        overflow-x: auto;
    }

    table {
        min-width: 1100px;
    }

}


@media (max-width: 900px) {

    body {
        display: block;
    }

    .sidebar {
        width: 100%;

        height: auto;

        position: relative;

        padding: 20px;
    }

    .logo {
        margin-bottom: 25px;
    }

    .main {
        margin-left: 0;

        width: 100%;
    }

    .header {
        padding: 20px;

        height: auto;

        flex-direction: column;

        gap: 15px;

        align-items: flex-start;
    }

    .container {
        padding: 20px;
    }

}


@media (max-width: 600px) {

    .admin-info {
        text-align: left;
    }

    .admin-box {
        width: 100%;

        justify-content: space-between;
    }

}

</style>
<link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/admin-sidebar.css">
</head>


<body>


<!-- =========================
     SIDEBAR
========================= -->

<?php include __DIR__ . '/sidebar.php'; ?>

<div class="main">


    <!-- HEADER -->

    <div class="header">


        <h2>
            Messages
        </h2>


        <div class="admin-box">


            <div class="admin-info">

                <small>
                    Administrator
                </small>

                <strong>
                    <?= htmlspecialchars(
                        $_SESSION['fullname']
                    ); ?>
                </strong>

            </div>


            <div class="admin-avatar">

                <?= htmlspecialchars($initial); ?>

            </div>


        </div>


    </div>


    <!-- CONTENT -->

    <div class="container">
        <div class="lb-panel" style="margin-bottom:20px;">
            <form method="GET" class="lb-toolbar">
                <label style="flex:1;min-width:220px;">Cari pesan, subjek, nama, atau email
                    <input type="search" name="search" value="<?= htmlspecialchars($messageSearch, ENT_QUOTES, 'UTF-8'); ?>" placeholder="Masukkan kata kunci...">
                </label>
                <button class="lb-btn" type="submit"><i class="fa-solid fa-magnifying-glass"></i> Cari</button>
                <?php if ($messageSearch !== ''): ?><a class="lb-btn" href="messages.php">Reset</a><?php endif; ?>
            </form>
        </div>

        <!-- TOP BAR -->
<!-- TABLE -->

        <div class="table-card">


            <table>


                <thead>

                    <tr>

                        <th>No</th>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Subject</th>

                        <th>Message</th>

                        <th>Admin Reply</th>

                        <th>Status</th>

                        <th>Date</th>

                        <th style="width:210px;">
                            Action
                        </th>

                    </tr>

                </thead>


                <tbody>


                <?php

                $no = 1;


                if (mysqli_num_rows($query) > 0) {

                    while ($msg = mysqli_fetch_assoc($query)) {

                ?>


                    <tr>


                        <!-- NO -->

                        <td>
                            <?= $no++; ?>
                        </td>


                        <!-- NAME -->

                        <td>

                            <?= htmlspecialchars(
                                $msg['fullname']
                            ); ?>

                        </td>


                        <!-- EMAIL -->

                        <td>

                            <?= htmlspecialchars(
                                $msg['email']
                            ); ?>

                        </td>


                        <!-- SUBJECT -->

                        <td class="subject">

                            <?= htmlspecialchars(
                                $msg['subject']
                            ); ?>

                        </td>


                        <!-- MESSAGE -->

                        <td class="message-box">

                            <?= nl2br(
                                htmlspecialchars(
                                    $msg['message']
                                )
                            ); ?>

                        </td>


                        <!-- ADMIN REPLY -->

                        <td class="message-box">


                        <?php if (!empty($msg['reply'])) { ?>


                            <?= nl2br(
                                htmlspecialchars(
                                    $msg['reply']
                                )
                            ); ?>


                            <br>


                            <?php if (!empty($msg['reply_date'])) { ?>

                                <small style="color:#888;">

                                    <?= htmlspecialchars(
                                        $msg['reply_date']
                                    ); ?>

                                </small>

                            <?php } ?>


                        <?php } else { ?>


                            <span style="color:#999;">

                                No reply yet

                            </span>


                        <?php } ?>


                        </td>


                        <!-- STATUS -->

                        <td>


                        <?php if ($msg['status'] == 'replied') { ?>


                            <span class="status replied">

                                <i class="fa-solid fa-circle-check"></i>

                                Replied

                            </span>


                        <?php } else { ?>


                            <span class="status unreplied">

                                <i class="fa-solid fa-clock"></i>

                                Unreplied

                            </span>


                        <?php } ?>


                        </td>


                        <!-- DATE -->

                        <td>

                            <?= htmlspecialchars(
                                $msg['created_at']
                            ); ?>

                        </td>


                        <!-- ACTION -->

                        <td class="action-column">


                            <div class="action-buttons">


                                <a
                                    href="reply_message.php?id=<?= $msg['id']; ?>"
                                    class="action-btn"
                                >

                                    <i class="fa-solid fa-reply"></i>

                                    Reply

                                </a>


                                <a
                                    href="delete_message.php?id=<?= $msg['id']; ?>"
                                    class="delete-btn"
                                    onclick="return confirm('Delete this message?');"
                                >

                                    <i class="fa-solid fa-trash"></i>

                                    Delete

                                </a>


                            </div>


                        </td>


                    </tr>


                <?php

                    }

                } else {

                ?>


                    <tr>

                        <td
                            colspan="9"
                            class="empty"
                        >

                            <i class="fa-solid fa-envelope"></i>


                            <h3>
                                No Messages Found
                            </h3>


                            <p>
                                There are no user messages yet.
                            </p>

                        </td>

                    </tr>


                <?php

                }

                ?>


                </tbody>


            </table>


        </div>


        <!-- FOOTER -->

        <div class="admin-footer">

            © <?= date('Y'); ?> LinglungBooks — Admin Messages

        </div>


    </div>


</div>
<script src="../assets/js/enhancements.js" defer></script>
</body>

</html>