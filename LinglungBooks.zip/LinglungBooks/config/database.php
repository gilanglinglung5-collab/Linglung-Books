<?php

$host     = "localhost";
$user     = "root";
$password = "";
$database = "linglung_books";

$conn = mysqli_connect($host, $user, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

mysqli_set_charset($conn, "utf8mb4");

// Migrasi idempoten untuk menyimpan harga modal buku dan snapshot modal tiap transaksi.
function linglungEnsureColumn($conn, $table, $column, $definition) {
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    $columnSafe = mysqli_real_escape_string($conn, $column);
    $check = mysqli_query($conn, "SHOW COLUMNS FROM `{$table}` LIKE '{$columnSafe}'");
    if ($check && mysqli_num_rows($check) === 0) {
        mysqli_query($conn, "ALTER TABLE `{$table}` ADD COLUMN `{$columnSafe}` {$definition}");
    }
}
linglungEnsureColumn($conn, 'books', 'cost_price', 'DECIMAL(12,2) NULL DEFAULT NULL');
linglungEnsureColumn($conn, 'order_details', 'cost_price', 'DECIMAL(12,2) NULL DEFAULT NULL');
linglungEnsureColumn($conn, 'orders', 'transaction_code', 'VARCHAR(32) NULL DEFAULT NULL');
// Pastikan transaksi lama juga memiliki kode yang dapat ditampilkan.
mysqli_query($conn, "UPDATE orders SET transaction_code = CONCAT('TRX', LPAD(id, 8, '0')) WHERE transaction_code IS NULL OR transaction_code = ''");

// Data akun untuk alamat dan kontak checkout.
linglungEnsureColumn($conn, 'users', 'phone', 'VARCHAR(20) NULL');
linglungEnsureColumn($conn, 'users', 'address', 'TEXT NULL');
// Alur status pesanan dan proses retur/refund.
$ordersStatus = mysqli_query($conn, "SHOW COLUMNS FROM orders LIKE 'status'");
if ($ordersStatus && ($statusCol = mysqli_fetch_assoc($ordersStatus)) && strpos($statusCol['Type'], 'Packed') === false) {
    mysqli_query($conn, "ALTER TABLE orders MODIFY status ENUM('Processing','Packed','Shipped','Received','Completed','ReturnRequested','ReturnApproved','ReturnRejected','ReturnShipped','Returned','Refunded','Cancelled') NOT NULL DEFAULT 'Processing'");
}
linglungEnsureColumn($conn, 'orders', 'return_status', "VARCHAR(30) NULL DEFAULT NULL");
linglungEnsureColumn($conn, 'orders', 'return_proof', 'VARCHAR(255) NULL');
linglungEnsureColumn($conn, 'orders', 'return_note', 'TEXT NULL');
linglungEnsureColumn($conn, 'orders', 'return_admin_note', 'TEXT NULL');
linglungEnsureColumn($conn, 'orders', 'return_requested_at', 'DATETIME NULL');
linglungEnsureColumn($conn, 'orders', 'return_received_at', 'DATETIME NULL');
linglungEnsureColumn($conn, 'orders', 'refund_status', "VARCHAR(30) NULL DEFAULT NULL");
linglungEnsureColumn($conn, 'orders', 'refund_note', 'TEXT NULL');

// Untuk transaksi lama, isi snapshot modal jika admin sudah melengkapi harga modal buku.
mysqli_query($conn, "UPDATE order_details od INNER JOIN books b ON b.id = od.book_id SET od.cost_price = b.cost_price WHERE od.cost_price IS NULL AND b.cost_price IS NOT NULL");


?>