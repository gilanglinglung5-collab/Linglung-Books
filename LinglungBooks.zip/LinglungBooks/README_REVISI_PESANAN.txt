REVISI LINGLUNBOOKS - CHECKOUT, STATUS PESANAN, RETUR

1. Backup database linglung_books dan folder project sebelum mengganti file.
2. Ekstrak folder LinglungBooks dari ZIP ini ke folder project lokal, menggantikan file versi lama.
3. Saat situs dijalankan, config/database.php menambahkan kolom akun dan retur serta memperluas enum status secara otomatis. Pastikan user MySQL yang dipakai config memiliki hak ALTER TABLE.
4. migration_revisi_pesanan.sql tersedia untuk migrasi manual SATU KALI. Jangan jalankan SQL manual jika aplikasi sudah menjalankan migrasi otomatis, karena kolom dapat menjadi duplikat.
5. Akun lama belum memiliki nomor telepon/alamat. Login sebagai user, buka Profil Saya, isi nomor telepon dan alamat, lalu simpan sebelum checkout.
6. Metode checkout baru: Virtual Account BCA, BRI, BNI, atau Mandiri; bukti pembayaran wajib diunggah. Isi nomor VA/rekening tujuan sesuai integrasi pembayaran yang benar sebelum penggunaan produksi.
7. Alur: Diproses -> (admin setujui pembayaran) Dikemas -> (admin tandai) Dikirim -> (user konfirmasi) Diterima -> Selesai atau Retur.
8. Retur: user unggah video unboxing dan alasan -> admin setujui/tolak -> jika disetujui user mengirim barang -> user konfirmasi sudah dikirim -> admin konfirmasi barang tiba di gudang -> admin melakukan refund secara manual di luar aplikasi -> admin menandai refund selesai.
9. Tombol refund hanya mencatat bahwa pengembalian uang sudah dilakukan; aplikasi tidak mengirim transfer uang otomatis.
10. Batas unggah video di aplikasi 100 MB, tetapi batas aktual juga dipengaruhi upload_max_filesize dan post_max_size pada konfigurasi PHP server.
