<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
header('Content-Type: application/json; charset=utf-8');
require_once '../config/database.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'login' => true, 'message' => 'Silakan login terlebih dahulu.']);
    exit;
}

$user_id = (int) $_SESSION['user_id'];
$book_id = isset($_POST['book_id']) ? (int) $_POST['book_id'] : 0;
if ($book_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Buku tidak valid.']);
    exit;
}

$check = mysqli_prepare($conn, 'SELECT id FROM books WHERE id = ? LIMIT 1');
mysqli_stmt_bind_param($check, 'i', $book_id);
mysqli_stmt_execute($check);
$book_result = mysqli_stmt_get_result($check);
if (!$book_result || mysqli_num_rows($book_result) === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Buku tidak ditemukan.']);
    exit;
}

$check = mysqli_prepare($conn, 'SELECT id FROM wishlist WHERE user_id = ? AND book_id = ? LIMIT 1');
mysqli_stmt_bind_param($check, 'ii', $user_id, $book_id);
mysqli_stmt_execute($check);
$existing = mysqli_stmt_get_result($check);

if ($existing && mysqli_num_rows($existing) > 0) {
    $delete = mysqli_prepare($conn, 'DELETE FROM wishlist WHERE user_id = ? AND book_id = ?');
    mysqli_stmt_bind_param($delete, 'ii', $user_id, $book_id);
    $success = mysqli_stmt_execute($delete);
    $active = false;
} else {
    $insert = mysqli_prepare($conn, 'INSERT IGNORE INTO wishlist (user_id, book_id) VALUES (?, ?)');
    mysqli_stmt_bind_param($insert, 'ii', $user_id, $book_id);
    $success = mysqli_stmt_execute($insert);
    $active = true;
}

if (!$success) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Wishlist gagal diperbarui.']);
    exit;
}

echo json_encode(['success' => true, 'active' => $active]);
