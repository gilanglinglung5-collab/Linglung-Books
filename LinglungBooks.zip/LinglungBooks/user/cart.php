<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

include '../config/database.php';


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");

    exit;
}


$user_id = (int) $_SESSION['user_id'];


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'dashboard.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   URL HALAMAN CART
========================= */

$current_url = 'cart.php';


/* =========================
   HAPUS ITEM
========================= */

if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {

    $cart_id = (int) $_GET['delete'];

    mysqli_query($conn, "
        DELETE FROM cart
        WHERE id = '$cart_id'
        AND user_id = '$user_id'
    ");

    header(
        "Location: cart.php?back=" .
        urlencode($back)
    );

    exit;
}


/* =========================
   UPDATE JUMLAH
========================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['update_cart'])
) {

    if (
        isset($_POST['quantity']) &&
        is_array($_POST['quantity'])
    ) {

        foreach (
            $_POST['quantity'] as $cart_id => $quantity
        ) {

            $cart_id = (int) $cart_id;

            $quantity = (int) $quantity;


            /* =========================
               JIKA JUMLAH 0
            ========================= */

            if ($quantity <= 0) {

                mysqli_query($conn, "
                    DELETE FROM cart
                    WHERE id = '$cart_id'
                    AND user_id = '$user_id'
                ");

                continue;
            }


            /* =========================
               AMBIL STOK
            ========================= */

            $stock_query = mysqli_query($conn, "
                SELECT
                    c.id,
                    b.stock
                FROM cart c
                INNER JOIN books b
                    ON c.book_id = b.id
                WHERE c.id = '$cart_id'
                AND c.user_id = '$user_id'
                LIMIT 1
            ");


            if (
                $stock_query &&
                mysqli_num_rows($stock_query) > 0
            ) {

                $stock_data =
                    mysqli_fetch_assoc($stock_query);

                $stock =
                    (int) $stock_data['stock'];


                /* =========================
                   BATASI JUMLAH SESUAI STOK
                ========================= */

                if ($quantity > $stock) {
                    $quantity = $stock;
                }


                if ($quantity <= 0) {

                    mysqli_query($conn, "
                        DELETE FROM cart
                        WHERE id = '$cart_id'
                        AND user_id = '$user_id'
                    ");

                } else {

                    mysqli_query($conn, "
                        UPDATE cart
                        SET quantity = '$quantity'
                        WHERE id = '$cart_id'
                        AND user_id = '$user_id'
                    ");

                }
            }
        }
    }


    header(
        "Location: cart.php?back=" .
        urlencode($back)
    );

    exit;
}


/* =========================
   AMBIL DATA CART
========================= */

$query = mysqli_query($conn, "
    SELECT
        c.id AS cart_id,
        c.quantity,
        b.id AS book_id,
        b.title,
        b.price,
        b.cover,
        b.stock
    FROM cart c
    INNER JOIN books b
        ON c.book_id = b.id
    WHERE c.user_id = '$user_id'
    ORDER BY c.id DESC
");


$cart_items = [];

$total = 0;


if ($query) {

    while ($row = mysqli_fetch_assoc($query)) {

        $cart_items[] = $row;

        $total +=
            (float) $row['price'] *
            (int) $row['quantity'];
    }
}

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Keranjang | LinglungBooks
    </title>


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >


    <!-- CSS -->

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >


    <style>

        /* =========================
           CART PAGE
        ========================= */

        .cart-page {

            max-width: 1200px;

            margin: 0 auto;

            padding: 45px 30px 80px;

        }


        /* =========================
           BACK BUTTON
        ========================= */

        .cart-back {

            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-bottom: 25px;

            padding: 10px 16px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 500;

            transition: .3s;

        }


        .cart-back:hover {

            background: #E8D6BE;

            transform: translateX(-3px);

        }


        /* =========================
           TITLE
        ========================= */

        .cart-title {

            margin: 0 0 30px;

            color: #4B3621;

            font-family: 'Cormorant Garamond', serif;

            font-size: 52px;

            line-height: 1;

        }


        /* =========================
           EMPTY CART
        ========================= */

        .empty-cart {

            padding: 70px 30px;

            text-align: center;

            background: #FFFFFF;

            border-radius: 22px;

            box-shadow:
                0 12px 35px rgba(75, 54, 33, .08);

        }


        .empty-cart-icon {

            display: flex;

            align-items: center;

            justify-content: center;

            width: 85px;

            height: 85px;

            margin: 0 auto 20px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 50%;

        }


        .empty-cart-icon i {

            font-size: 35px;

        }


        .empty-cart h2 {

            margin: 0 0 8px;

            color: #4B3621;

            font-size: 23px;

        }


        .empty-cart p {

            margin: 0 auto 25px;

            max-width: 500px;

            color: #8A7A6D;

            font-size: 14px;

            line-height: 1.7;

        }


        .browse-books-btn {

            display: inline-flex;

            align-items: center;

            gap: 9px;

            padding: 12px 20px;

            background: #6F4E37;

            color: #FFFFFF;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 600;

            transition: .3s;

        }


        .browse-books-btn:hover {

            background: #8B5E3C;

            transform: translateY(-2px);

        }


        /* =========================
           CART LAYOUT
        ========================= */

        .cart-layout {

            display: grid;

            grid-template-columns:
                minmax(0, 1fr) 330px;

            gap: 30px;

            align-items: start;

        }


        /* =========================
           CART LIST
        ========================= */

        .cart-list {

            display: flex;

            flex-direction: column;

            gap: 15px;

        }


        .cart-item {

            display: grid;

            grid-template-columns:
                100px minmax(0, 1fr) auto;

            gap: 20px;

            align-items: center;

            padding: 20px;

            background: #FFFFFF;

            border-radius: 18px;

            box-shadow:
                0 8px 25px rgba(75, 54, 33, .06);

        }


        /* =========================
           COVER
        ========================= */

        .cart-cover {

            width: 100px;

            height: 130px;

            overflow: hidden;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #F8F3EC;

            border-radius: 10px;

        }


        .cart-cover img {

            width: 100%;

            height: 100%;

            object-fit: cover;

        }


        .cart-cover-placeholder {

            color: #6F4E37;

            font-size: 28px;

        }


        /* =========================
           INFO
        ========================= */

        .cart-info {

            min-width: 0;

        }


        .cart-book-title {

            display: block;

            margin-bottom: 8px;

            color: #4B3621;

            font-size: 18px;

            font-weight: 600;

            line-height: 1.4;

            text-decoration: none;

        }


        .cart-book-title:hover {

            color: #8B5E3C;

        }


        .cart-price {

            margin-bottom: 13px;

            color: #8B5E3C;

            font-size: 15px;

            font-weight: 600;

        }


        .stock-info {

            margin-bottom: 12px;

            color: #8A7A6D;

            font-size: 12px;

        }


        /* =========================
           QUANTITY
        ========================= */

        .quantity-label {

            display: block;

            margin-bottom: 6px;

            color: #8A7A6D;

            font-size: 12px;

        }


        .quantity-input {

            width: 70px;

            padding: 8px 10px;

            border: 1px solid #E4D9CC;

            border-radius: 8px;

            background: #FFFFFF;

            color: #4B3621;

            font-family: Poppins, sans-serif;

            font-size: 13px;

            outline: none;

        }


        .quantity-input:focus {

            border-color: #8B5E3C;

        }


        /* =========================
           ITEM TOTAL
        ========================= */

        .cart-item-right {

            min-width: 130px;

            text-align: right;

        }


        .item-total {

            margin-bottom: 15px;

            color: #4B3621;

            font-size: 17px;

            font-weight: 700;

        }


        .delete-btn {

            display: inline-flex;

            align-items: center;

            gap: 6px;

            padding: 7px 10px;

            border: none;

            background: transparent;

            color: #B04A3A;

            border-radius: 7px;

            font-family: Poppins, sans-serif;

            font-size: 12px;

            cursor: pointer;

            text-decoration: none;

            transition: .3s;

        }


        .delete-btn:hover {

            background: #FBEAEA;

        }


        /* =========================
           UPDATE BUTTON
        ========================= */

        .update-cart-wrapper {

            display: flex;

            justify-content: flex-end;

            margin-top: 5px;

        }


        .update-cart-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            padding: 11px 18px;

            border: none;

            border-radius: 10px;

            background: #F3E8D8;

            color: #6F4E37;

            font-family: Poppins, sans-serif;

            font-size: 13px;

            font-weight: 600;

            cursor: pointer;

            transition: .3s;

        }


        .update-cart-btn:hover {

            background: #E8D6BE;

        }


        /* =========================
           SUMMARY
        ========================= */

        .cart-summary {

            position: sticky;

            top: 25px;

            padding: 25px;

            background: #FFFFFF;

            border-radius: 18px;

            box-shadow:
                0 10px 30px rgba(75, 54, 33, .07);

        }


        .summary-title {

            margin: 0 0 22px;

            color: #4B3621;

            font-size: 19px;

            font-weight: 600;

        }


        .summary-row {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            padding: 11px 0;

            color: #6D625B;

            font-size: 13px;

        }


        .summary-row.total {

            margin-top: 8px;

            padding-top: 18px;

            border-top: 1px solid #EDE5DC;

            color: #4B3621;

            font-size: 16px;

            font-weight: 700;

        }


        .summary-total-price {

            color: #8B5E3C;

        }


        /* =========================
           CHECKOUT BUTTON
        ========================= */

        .checkout-btn {

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 9px;

            width: 100%;

            margin-top: 20px;

            padding: 14px 18px;

            background: #6F4E37;

            color: #FFFFFF;

            border-radius: 11px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 600;

            transition: .3s;

            box-sizing: border-box;

        }


        .checkout-btn:hover {

            background: #8B5E3C;

            transform: translateY(-2px);

            box-shadow:
                0 8px 18px rgba(111, 78, 55, .18);

        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 900px) {

            .cart-layout {

                grid-template-columns: 1fr;

            }


            .cart-summary {

                position: static;

            }

        }


        @media (max-width: 650px) {

            .cart-page {

                padding: 30px 18px 60px;

            }


            .cart-title {

                font-size: 43px;

            }


            .cart-item {

                grid-template-columns: 80px minmax(0, 1fr);

                gap: 15px;

            }


            .cart-cover {

                width: 80px;

                height: 110px;

            }


            .cart-item-right {

                grid-column: 1 / -1;

                display: flex;

                align-items: center;

                justify-content: space-between;

                min-width: 0;

                padding-top: 12px;

                border-top: 1px solid #F0E9E1;

                text-align: left;

            }


            .item-total {

                margin: 0;

            }

        }


        @media (max-width: 450px) {

            .cart-title {

                font-size: 37px;

            }


            .cart-item {

                padding: 15px;

            }


            .cart-book-title {

                font-size: 15px;

            }


            .cart-price {

                font-size: 13px;

            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<?php include '../includes/navbar_user.php'; ?>


<!-- =========================
     CART PAGE
========================= -->

<main class="cart-page">


    <!-- BACK -->

    <a
        href="<?= htmlspecialchars(
            $back,
            ENT_QUOTES,
            'UTF-8'
        ); ?>"
        class="global-back-button"
    >

        <i class="fa-solid fa-arrow-left"></i>

        Kembali

    </a>


    <!-- TITLE -->

    <h1 class="cart-title">

        Keranjang

    </h1>


    <?php if (empty($cart_items)): ?>


        <!-- =========================
             EMPTY CART
        ========================= -->

        <section class="empty-cart">


            <div class="empty-cart-icon">

                <i class="fa-solid fa-cart-shopping"></i>

            </div>


            <h2>

                Keranjang masih kosong

            </h2>


            <p>

                Belum ada buku yang ditambahkan
                ke keranjang. Yuk, cari buku
                yang ingin kamu baca.

            </p>


            <a
                href="books.php?back=<?= urlencode(
                    $current_url
                ); ?>"
                class="browse-books-btn"
            >

                <i class="fa-solid fa-book"></i>

                Jelajahi Buku

            </a>


        </section>


    <?php else: ?>


        <!-- =========================
             CART CONTENT
        ========================= -->

        <form
            method="POST"
            class="cart-layout"
        >


            <!-- =========================
                 LEFT
            ========================= -->

            <div>


                <div class="cart-list">


                    <?php foreach ($cart_items as $item): ?>


                        <article class="cart-item">


                            <!-- COVER -->

                            <a
                                href="detail.php?id=<?= (int) $item['book_id']; ?>&back=<?= urlencode(
                                    $current_url
                                ); ?>"
                                class="cart-cover"
                            >


                                <?php if (!empty($item['cover'])): ?>


                                    <img
                                        src="../assets/img/<?= htmlspecialchars(
                                            $item['cover'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>"
                                        alt="<?= htmlspecialchars(
                                            $item['title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>"
                                    >


                                <?php else: ?>


                                    <div class="cart-cover-placeholder">

                                        <i class="fa-solid fa-book"></i>

                                    </div>


                                <?php endif; ?>


                            </a>


                            <!-- INFO -->

                            <div class="cart-info">


                                <a
                                    href="detail.php?id=<?= (int) $item['book_id']; ?>&back=<?= urlencode(
                                        $current_url
                                    ); ?>"
                                    class="cart-book-title"
                                >

                                    <?= htmlspecialchars(
                                        $item['title'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                </a>


                                <div class="cart-price">

                                    Rp<?= number_format(
                                        $item['price'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </div>


                                <div class="stock-info">

                                    Stok tersedia:

                                    <?= (int) $item['stock']; ?>

                                </div>


                                <label class="quantity-label">

                                    Jumlah

                                </label>


                                <input
                                    type="number"
                                    name="quantity[<?= (int) $item['cart_id']; ?>]"
                                    value="<?= (int) $item['quantity']; ?>"
                                    min="1"
                                    max="<?= (int) $item['stock']; ?>"
                                    class="quantity-input"
                                >


                            </div>


                            <!-- ITEM TOTAL -->

                            <div class="cart-item-right">


                                <div class="item-total">

                                    Rp<?= number_format(
                                        $item['price'] *
                                        $item['quantity'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </div>


                                <a
                                    href="cart.php?delete=<?= (int) $item['cart_id']; ?>&back=<?= urlencode(
                                        $back
                                    ); ?>"
                                    class="delete-btn"
                                    onclick="return confirm('Hapus buku ini dari keranjang?');"
                                >

                                    <i class="fa-solid fa-trash"></i>

                                    Hapus

                                </a>


                            </div>


                        </article>


                    <?php endforeach; ?>


                </div>


                <!-- UPDATE -->

                <div class="update-cart-wrapper">

                    <button
                        type="submit"
                        name="update_cart"
                        class="update-cart-btn"
                    >

                        <i class="fa-solid fa-rotate"></i>

                        Perbarui Keranjang

                    </button>

                </div>


            </div>


            <!-- =========================
                 SUMMARY
            ========================= -->

            <aside class="cart-summary">


                <h2 class="summary-title">

                    Ringkasan Pesanan

                </h2>


                <div class="summary-row">

                    <span>

                        Jumlah Buku

                    </span>

                    <span>

                        <?= count($cart_items); ?>

                    </span>

                </div>


                <div class="summary-row">

                    <span>

                        Total Item

                    </span>

                    <span>

                        <?php

                        $total_quantity = 0;

                        foreach ($cart_items as $item) {

                            $total_quantity +=
                                (int) $item['quantity'];
                        }

                        echo $total_quantity;

                        ?>

                    </span>

                </div>


                <div class="summary-row total">

                    <span>

                        Total

                    </span>

                    <span class="summary-total-price">

                        Rp<?= number_format(
                            $total,
                            0,
                            ",",
                            "."
                        ); ?>

                    </span>

                </div>


                <a
                    href="checkout.php?back=<?= urlencode(
                        $current_url
                    ); ?>"
                    class="checkout-btn"
                >

                    Lanjut ke Checkout

                    <i class="fa-solid fa-arrow-right"></i>

                </a>


            </aside>


        </form>


    <?php endif; ?>


</main>


<!-- =========================
     FOOTER
========================= -->

<?php include '../includes/footer_user.php'; ?>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>