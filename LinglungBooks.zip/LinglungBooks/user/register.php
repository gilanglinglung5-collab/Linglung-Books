<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
require_once '../config/database.php';

$message = "";
$message_type = "";

/* =========================================
   TENTUKAN HALAMAN KEMBALI
========================================= */

$default_back = '../index.php';
$back = $_GET['back'] ?? $default_back;

if ($back === '') {
    $back = $default_back;
}

if ($back === 'index.php') {
    $back = '../index.php';
}

$allowed_back_pages = [
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'wishlist.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

/* =========================================
   VALIDASI URL KEMBALI
========================================= */

function validateBack($back, $default_back, $allowed_back_pages) {

    $back_path = parse_url($back, PHP_URL_PATH);

    $is_safe_back =
        $back === '../index.php' ||
        (
            strpos($back, '://') === false &&
            strpos($back, '//') !== 0 &&
            strpos($back, '..') === false &&
            in_array(
                basename($back_path ?: ''),
                $allowed_back_pages,
                true
            )
        );

    return $is_safe_back ? $back : $default_back;
}

$back = validateBack($back, $default_back, $allowed_back_pages);

/* =========================================
   PROSES REGISTER
========================================= */

if (isset($_POST['register'])) {

    $back = validateBack(
        $_POST['back'] ?? $back,
        $default_back,
        $allowed_back_pages
    );

    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $plain_password = $_POST['password'] ?? '';

    /* =====================================
       VALIDASI INPUT
    ===================================== */

    if ($fullname === '') {

        $message = "Nama lengkap wajib diisi.";
        $message_type = "error";

    } elseif (strlen($fullname) > 100) {

        $message = "Nama lengkap maksimal 100 karakter.";
        $message_type = "error";

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $message = "Format email tidak valid.";
        $message_type = "error";

    } elseif (strlen($email) > 100) {

        $message = "Email maksimal 100 karakter.";
        $message_type = "error";

    } elseif (!preg_match('/^[A-Za-z0-9_]{3,50}$/', $username)) {

        $message = "Username harus 3-50 karakter dan hanya boleh menggunakan huruf, angka, atau underscore.";
        $message_type = "error";

    } elseif ($phone === '' || strlen($phone) > 20) {

        $message = "Nomor telepon wajib diisi (maksimal 20 karakter).";
        $message_type = "error";

    } elseif ($address === '' || mb_strlen($address) > 2000) {

        $message = "Alamat wajib diisi dan maksimal 2000 karakter.";
        $message_type = "error";

    } elseif (strlen($plain_password) < 6) {

        $message = "Password minimal 6 karakter.";
        $message_type = "error";

    } elseif (strlen($plain_password) > 255) {

        $message = "Password terlalu panjang.";
        $message_type = "error";

    } else {

        /* =================================
           CEK USERNAME DAN EMAIL
        ================================= */

        $stmt = mysqli_prepare(
            $conn,
            "SELECT id FROM users
             WHERE username = ? OR email = ?
             LIMIT 1"
        );

        if (!$stmt) {

            $message = "Terjadi kesalahan sistem. Silakan coba lagi.";
            $message_type = "error";

        } else {

            mysqli_stmt_bind_param(
                $stmt,
                "ss",
                $username,
                $email
            );

            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);

            if ($result && mysqli_num_rows($result) > 0) {

                $message = "Username atau email sudah digunakan.";
                $message_type = "error";

                mysqli_stmt_close($stmt);

            } else {

                mysqli_stmt_close($stmt);

                /* =============================
                   HASH PASSWORD
                ============================= */

                $password = password_hash(
                    $plain_password,
                    PASSWORD_DEFAULT
                );

                /* =============================
                   SIMPAN AKUN USER
                ============================= */

                $insert = mysqli_prepare(
                    $conn,
                    "INSERT INTO users
                    (fullname, email, username, password, phone, address, role)
                    VALUES (?, ?, ?, ?, ?, ?, 'user')"
                );

                if (!$insert) {

                    $message = "Terjadi kesalahan sistem. Silakan coba lagi.";
                    $message_type = "error";

                } else {

                    mysqli_stmt_bind_param(
                        $insert,
                        "ssssss",
                        $fullname,
                        $email,
                        $username,
                        $password,
                        $phone,
                        $address
                    );

                    if (mysqli_stmt_execute($insert)) {

                        $message = "Registrasi berhasil! Silakan login.";
                        $message_type = "success";

                    } else {

                        $message = "Registrasi gagal. Silakan coba lagi.";
                        $message_type = "error";
                    }

                    mysqli_stmt_close($insert);
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Daftar | Linglung Books</title>

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/enhancements.css"
    >

    <style>

        .register-box {
            width: 420px;
            max-width: calc(100% - 40px);
            background: white;
            margin: 70px auto;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0,0,0,.08);
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .register-box h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #4B3621;
        }

        .input-group {
            margin-bottom: 18px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #4B3621;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
            font-family: 'Poppins', sans-serif;
            box-sizing: border-box;
        }

        .input-group input:focus {
            border-color: #8B5E3C;
        }

        .btn-register {
            width: 100%;
            padding: 14px;
            border: none;
            background: #6F4E37;
            color: white;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            transition: .3s;
        }

        .btn-register:hover {
            background: #8B5E3C;
        }

        .message {
            text-align: center;
            margin-bottom: 20px;
            padding: 10px 14px;
            border-radius: 8px;
            font-weight: 500;
        }

        .message.error {
            color: #8B5E3C;
            background: #F3E8D8;
        }

        .message.success {
            color: #4B3621;
            background: #E8D6BE;
        }

        .login-link {
            text-align: center;
            margin-top: 20px;
            color: #555;
        }

        .login-link a {
            color: #6F4E37;
            text-decoration: none;
            font-weight: 600;
        }

        .login-link a:hover {
            color: #8B5E3C;
            text-decoration: underline;
        }

        /* =================================
           TOMBOL KEMBALI BERUPA TULISAN
        ================================= */

        .register-back {
            display: block;
            width: fit-content;
            margin: 18px auto 0;
            padding: 0;
            background: none;
            border: none;
            color: #6F4E37;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: .2s;
        }

        .register-back:hover {
            color: #8B5E3C;
            text-decoration: underline;
        }

        @media (max-width: 500px) {

            .register-box {
                margin: 40px auto;
                padding: 30px 25px;
            }

        }

    </style>

    <link rel="stylesheet" href="../assets/css/back-button.css">
</head>

<body>

    <div class="register-box">

        <h2>Create Account</h2>

        <?php if (!empty($message)): ?>

            <div class="message <?= htmlspecialchars($message_type, ENT_QUOTES, 'UTF-8') ?>">

                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>

            </div>

        <?php endif; ?>

        <form method="POST" autocomplete="off">

            <!-- Menyimpan halaman asal -->

            <input
                type="hidden"
                name="back"
                value="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8') ?>"
            >

            <div class="input-group">

                <label for="fullname">Nama Lengkap</label>

                <input
                    type="text"
                    id="fullname"
                    name="fullname"
                    maxlength="100"
                    autocomplete="name"
                    required
                >

            </div>

            <div class="input-group">

                <label for="email">Email</label>

                <input
                    type="email"
                    id="email"
                    name="email"
                    maxlength="100"
                    autocomplete="email"
                    required
                >

            </div>

            <div class="input-group">
                <label for="phone">Nomor Telepon</label>
                <input type="tel" id="phone" name="phone" maxlength="20" autocomplete="tel" required>
            </div>

            <div class="input-group">
                <label for="address">Alamat Lengkap</label>
                <textarea id="address" name="address" rows="3" maxlength="2000" required style="width:100%;padding:12px;border:1px solid #ddd;border-radius:10px;font:15px 'Poppins',sans-serif;box-sizing:border-box;resize:vertical;"></textarea>
            </div>

            <div class="input-group">

                <label for="username">Username</label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    maxlength="50"
                    pattern="[A-Za-z0-9_]{3,50}"
                    autocomplete="username"
                    required
                >

            </div>

            <div class="input-group">

                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    minlength="6"
                    maxlength="255"
                    autocomplete="new-password"
                    required
                >

            </div>

            <button
                type="submit"
                name="register"
                class="btn-register"
            >
                Register
            </button>

        </form>

        <div class="login-link">

            Sudah punya akun?

            <a href="login.php?back=<?= urlencode($back) ?>">
                Login
            </a>

        </div>

        <!-- TOMBOL KEMBALI -->

        <a
            href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8') ?>"
            class="global-back-button"
        >
            Kembali
        </a>

    </div>

    <script src="../assets/js/enhancements.js" defer></script>

</body>

</html>