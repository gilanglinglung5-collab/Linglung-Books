<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

include '../config/database.php';


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$is_logged_in = isset($_SESSION['user_id']);

$default_back = $is_logged_in
    ? 'dashboard.php'
    : '../index.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'wishlist.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   VALIDASI ID
========================= */

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {

    header(
        "Location: books.php?back=" .
        urlencode($back)
    );

    exit;
}


$id = (int) $_GET['id'];


/* =========================
   AMBIL DATA BUKU
========================= */

$query = mysqli_query($conn, "
    SELECT
        books.*,
        categories.category_name
    FROM books
    LEFT JOIN categories
        ON books.category_id = categories.id
    WHERE books.id = '$id'
    LIMIT 1
");


if (
    !$query ||
    mysqli_num_rows($query) == 0
) {

    header(
        "Location: books.php?back=" .
        urlencode($back)
    );

    exit;
}


$book = mysqli_fetch_assoc($query);

/* =========================
   STATUS WISHLIST BUKU
========================= */
$book_is_wishlisted = false;
if ($is_logged_in) {
    $wishlist_check = mysqli_prepare($conn, 'SELECT id FROM wishlist WHERE user_id = ? AND book_id = ? LIMIT 1');
    $wishlist_user_id = (int) $_SESSION['user_id'];
    mysqli_stmt_bind_param($wishlist_check, 'ii', $wishlist_user_id, $id);
    mysqli_stmt_execute($wishlist_check);
    $wishlist_result = mysqli_stmt_get_result($wishlist_check);
    $book_is_wishlisted = $wishlist_result && mysqli_num_rows($wishlist_result) > 0;
}



/* =========================
   ADD TO CART
========================= */

if (isset($_POST['add_cart'])) {


    /* =========================
       HARUS LOGIN
    ========================= */

    if (!isset($_SESSION['user_id'])) {

        /*
         * Setelah login, tetap bisa kembali
         * ke halaman detail buku ini.
         */

        $detail_url =
            'detail.php?id=' .
            $id .
            '&back=' .
            urlencode($back);

        header(
            "Location: login.php?back=" .
            urlencode($detail_url)
        );

        exit;
    }


    $user_id = (int) $_SESSION['user_id'];

    $stock = (int) $book['stock'];


    /* =========================
       CEK STOK
    ========================= */

    if ($stock <= 0) {

        $_SESSION['cart_message'] =
            "Stok buku ini sedang habis.";

        header(
            "Location: detail.php?id=" .
            $id .
            "&back=" .
            urlencode($back)
        );

        exit;
    }


    /* =========================
       CEK CART
    ========================= */

    $check = mysqli_query($conn, "
        SELECT
            id,
            quantity
        FROM cart
        WHERE user_id = '$user_id'
        AND book_id = '$id'
        LIMIT 1
    ");


    if (
        $check &&
        mysqli_num_rows($check) > 0
    ) {

        $cart = mysqli_fetch_assoc($check);

        $current_quantity =
            (int) $cart['quantity'];


        /* =========================
           BATASI SESUAI STOK
        ========================= */

        if ($current_quantity >= $stock) {

            $_SESSION['cart_message'] =
                "Jumlah buku di keranjang sudah mencapai stok yang tersedia.";

            header(
                "Location: detail.php?id=" .
                $id .
                "&back=" .
                urlencode($back)
            );

            exit;
        }


        $new_quantity =
            $current_quantity + 1;


        mysqli_query($conn, "
            UPDATE cart
            SET quantity = '$new_quantity'
            WHERE id = '" . (int) $cart['id'] . "'
            AND user_id = '$user_id'
        ");


    } else {


        /* =========================
           INSERT CART
        ========================= */

        mysqli_query($conn, "
            INSERT INTO cart (
                user_id,
                book_id,
                quantity
            )
            VALUES (
                '$user_id',
                '$id',
                1
            )
        ");
    }


    /* =========================
       SETELAH TAMBAH CART
    ========================= */

    $detail_url =
        'detail.php?id=' .
        $id .
        '&back=' .
        urlencode($back);

    header(
        "Location: cart.php?back=" .
        urlencode($detail_url)
    );

    exit;
}

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?= htmlspecialchars(
            $book['title'],
            ENT_QUOTES,
            'UTF-8'
        ); ?>
        | LinglungBooks
    </title>


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >


    <!-- CSS UTAMA -->

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >


    <style>

        /* =========================
           DETAIL PAGE
        ========================= */

        .detail-page {

            max-width: 1250px;

            margin: 0 auto;

            padding: 45px 30px 80px;

        }


        /* =========================
           BACK BUTTON
        ========================= */

        .detail-back {

            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-bottom: 25px;

            padding: 10px 16px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 500;

            transition: .3s;

        }


        .detail-back:hover {

            background: #E8D6BE;

            transform: translateX(-3px);

        }


        /* =========================
           ALERT
        ========================= */

        .detail-alert {

            display: flex;

            align-items: center;

            gap: 10px;

            margin-bottom: 25px;

            padding: 14px 18px;

            background: #FFF3CD;

            color: #856404;

            border: 1px solid #F0D98C;

            border-radius: 12px;

            font-size: 14px;

        }


        .detail-alert i {

            font-size: 17px;

        }


        /* =========================
           DETAIL CARD
        ========================= */

        .book-detail {

            display: grid;

            grid-template-columns: 420px 1fr;

            gap: 60px;

            background: #FFFFFF;

            padding: 45px;

            border-radius: 24px;

            box-shadow:
                0 12px 35px rgba(75, 54, 33, .08);

        }


        /* =========================
           COVER AREA
        ========================= */

        .detail-cover {

            display: flex;

            align-items: flex-start;

            justify-content: center;

        }


        .detail-cover-wrapper {

            position: relative;

            width: 100%;

            max-width: 380px;

            min-height: 520px;

            padding: 18px 30px;

            box-sizing: border-box;

            background: #F8F3EC;

            border-radius: 20px;

            display: flex;

            align-items: center;

            justify-content: center;

            overflow: hidden;

            box-shadow:
                inset 0 0 0 1px rgba(111, 78, 55, .08);

        }


        /* =========================
           COVER IMAGE
        ========================= */

        .detail-cover img {

            display: block;

            width: 100%;

            height: auto;

            max-width: 100%;

            max-height: 484px;

            object-fit: contain;

            border-radius: 10px;

            background: transparent;

        }


        /* =========================
           PLACEHOLDER
        ========================= */

        .cover-placeholder {

            width: 100%;

            height: 484px;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #6F4E37;

            background: transparent;

        }


        .cover-placeholder i {

            font-size: 70px;

        }


        /* =========================
           BOOK INFO
        ========================= */

        .detail-info {

            display: flex;

            flex-direction: column;

        }


        /* =========================
           CATEGORY
        ========================= */

        .category-badge {

            display: inline-flex;

            align-items: center;

            gap: 7px;

            width: fit-content;

            padding: 7px 14px;

            margin-bottom: 18px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 20px;

            font-size: 13px;

            font-weight: 600;

        }


        /* =========================
           TITLE
        ========================= */

        .detail-title {

            margin: 0 0 20px;

            font-family: 'Cormorant Garamond', serif;

            font-size: 52px;

            line-height: 1.05;

            color: #4B3621;

        }


        /* =========================
           BOOK META
        ========================= */

        .book-meta {

            display: grid;

            grid-template-columns:
                repeat(2, minmax(0, 1fr));

            gap: 12px;

            margin-bottom: 25px;

        }


        .meta-item {

            padding: 14px 16px;

            background: #FAF7F2;

            border-radius: 12px;

        }


        .meta-label {

            display: block;

            margin-bottom: 4px;

            color: #8A7A6D;

            font-size: 12px;

        }


        .meta-value {

            color: #4B3621;

            font-size: 14px;

            font-weight: 600;

        }


        /* =========================
           PRICE
        ========================= */

        .detail-price {

            margin: 5px 0 12px;

            color: #8B5E3C;

            font-size: 31px;

            font-weight: 700;

        }


        /* =========================
           STOCK
        ========================= */

        .detail-stock {

            display: flex;

            align-items: center;

            gap: 8px;

            width: fit-content;

            margin-bottom: 22px;

            padding: 8px 13px;

            border-radius: 9px;

            font-size: 13px;

            font-weight: 600;

        }


        .detail-stock.available {

            background: #EEF5E8;

            color: #567A32;

        }


        .detail-stock.empty {

            background: #FBEAEA;

            color: #C0392B;

        }


        /* =========================
           DESCRIPTION
        ========================= */

        .description-title {

            margin-bottom: 8px;

            color: #4B3621;

            font-size: 16px;

            font-weight: 600;

        }


        .description {

            margin-bottom: 25px;

            color: #6D625B;

            font-size: 14px;

            line-height: 1.85;

        }


        /* =========================
           ADD CART
        ========================= */

.cart-form {

            margin-top: auto;

        }


        .add-cart-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 10px;

            width: 100%;

            padding: 15px 25px;

            border: none;

            border-radius: 12px;

            background: #6F4E37;

            color: #FFFFFF;

            font-family: Poppins, sans-serif;

            font-size: 15px;

            font-weight: 600;

            cursor: pointer;

            transition: .3s;

        }


        .add-cart-btn:hover {

            background: #8B5E3C;

            transform: translateY(-2px);

            box-shadow:
                0 8px 18px rgba(111, 78, 55, .18);

        }


        .add-cart-btn:active {

            transform: translateY(0);

        }


        .add-cart-btn.disabled {

            background: #B8B0AA;

            cursor: not-allowed;

            box-shadow: none;

        }


        .add-cart-btn.disabled:hover {

            transform: none;

        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 1000px) {

            .book-detail {

                grid-template-columns: 350px 1fr;

                gap: 35px;

                padding: 35px;

            }


            .detail-title {

                font-size: 45px;

            }


            .detail-cover-wrapper {

                min-height: 470px;

            }


            .detail-cover img {

                max-height: 434px;

            }


            .cover-placeholder {

                height: 434px;

            }

        }


        @media (max-width: 768px) {

            .detail-page {

                padding: 30px 20px 60px;

            }


            .book-detail {

                grid-template-columns: 1fr;

                gap: 35px;

                padding: 25px;

                border-radius: 20px;

            }


            .detail-cover-wrapper {

                max-width: 360px;

                min-height: 500px;

                padding: 18px 30px;

            }


            .detail-cover img {

                max-height: 464px;

            }


            .cover-placeholder {

                height: 464px;

            }


            .detail-info {

                display: block;

            }


            .detail-title {

                font-size: 42px;

            }


            .book-meta {

                grid-template-columns: 1fr;

            }


            .cart-form {

                margin-top: 25px;

            }

        }


        @media (max-width: 480px) {

            .detail-page {

                padding: 25px 15px 50px;

            }


            .book-detail {

                padding: 20px;

            }


            .detail-cover-wrapper {

                min-height: 430px;

                padding: 12px 20px;

            }


            .detail-cover img {

                max-height: 406px;

            }


            .cover-placeholder {

                height: 406px;

            }


            .detail-title {

                font-size: 36px;

            }


            .detail-price {

                font-size: 27px;

            }


            .detail-back {

                font-size: 13px;

            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<?php include '../includes/navbar_user.php'; ?>


<!-- =========================
     DETAIL PAGE
========================= -->

<main class="detail-page">


    <!-- BACK -->

    <a
        href="<?= htmlspecialchars(
            $back,
            ENT_QUOTES,
            'UTF-8'
        ); ?>"
        class="global-back-button"
    >

        <i class="fa-solid fa-arrow-left"></i>

        Kembali

    </a>


    <!-- =========================
         ALERT
    ========================= -->

    <?php if (isset($_SESSION['cart_message'])): ?>


        <div class="detail-alert">

            <i class="fa-solid fa-circle-info"></i>

            <span>

                <?= htmlspecialchars(
                    $_SESSION['cart_message'],
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>

            </span>

        </div>


        <?php

        unset($_SESSION['cart_message']);

        ?>


    <?php endif; ?>


    <!-- =========================
         BOOK DETAIL
    ========================= -->

    <section class="book-detail">


        <!-- =========================
             COVER
        ========================= -->

        <div class="detail-cover">

            <div class="detail-cover-wrapper">


                <?php if (!empty($book['cover'])): ?>


                    <img
                        src="../assets/img/<?= htmlspecialchars(
                            $book['cover'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                        alt="<?= htmlspecialchars(
                            $book['title'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                    >


                <?php else: ?>


                    <div class="cover-placeholder">

                        <i class="fa-solid fa-book"></i>

                    </div>


                <?php endif; ?>


            </div>

        </div>


        <!-- =========================
             INFORMATION
        ========================= -->

        <div class="detail-info">


            <!-- CATEGORY -->

            <div class="category-badge">

                <i class="fa-solid fa-tag"></i>

                <?= htmlspecialchars(
                    $book['category_name']
                    ?? 'Tanpa Kategori',
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>

            </div>


            <!-- TITLE -->

            <h1 class="detail-title">

                <?= htmlspecialchars(
                    $book['title'],
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>

            </h1>


            <!-- META -->

            <div class="book-meta">


                <div class="meta-item">

                    <span class="meta-label">
                        Penulis
                    </span>

                    <span class="meta-value">

                        <?= htmlspecialchars(
                            $book['author'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>

                    </span>

                </div>


                <div class="meta-item">

                    <span class="meta-label">
                        Penerbit
                    </span>

                    <span class="meta-value">

                        <?= htmlspecialchars(
                            $book['publisher'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>

                    </span>

                </div>


            </div>


            <!-- PRICE -->

            <div class="detail-price">

                Rp<?= number_format(
                    $book['price'],
                    0,
                    ",",
                    "."
                ); ?>

            </div>


            <!-- STOCK -->

            <?php if ((int) $book['stock'] > 0): ?>


                <div class="detail-stock available">

                    <i class="fa-solid fa-box"></i>

                    Stok tersedia:

                    <?= (int) $book['stock']; ?>

                </div>


            <?php else: ?>


                <div class="detail-stock empty">

                    <i class="fa-solid fa-box-open"></i>

                    Stok habis

                </div>


            <?php endif; ?>


            <!-- DESCRIPTION -->

            <div class="description-title">
                Tentang Buku
            </div>

            <p class="description">
                <?php if (!empty(trim((string) ($book['description'] ?? '')))): ?>
                    <?= nl2br(
                        htmlspecialchars(
                            $book['description'],
                            ENT_QUOTES,
                            'UTF-8'
                        )
                    ); ?>
                <?php else: ?>
                    Deskripsi buku belum tersedia.
                <?php endif; ?>
            </p>


            <!-- ADD CART -->

            <form
                method="POST"
                class="cart-form"
            >


                <?php if ((int) $book['stock'] > 0): ?>


                    <button
                        type="submit"
                        name="add_cart"
                        class="add-cart-btn"
                    >

                        <i class="fa-solid fa-cart-shopping"></i>

                        Tambah ke Keranjang

                    </button>


                <?php else: ?>


                    <button
                        type="button"
                        class="add-cart-btn disabled"
                        disabled
                    >

                        <i class="fa-solid fa-box-open"></i>

                        Stok Habis

                    </button>


                <?php endif; ?>


            </form>


        </div>


    </section>


</main>


<!-- =========================
     FOOTER
========================= -->

<?php include '../includes/footer_user.php'; ?>




<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>