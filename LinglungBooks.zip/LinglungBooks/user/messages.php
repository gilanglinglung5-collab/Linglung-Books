<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'dashboard.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   NORMALISASI INDEX
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {

    header(
        "Location: login.php?back=" .
        urlencode($back)
    );

    exit;
}


include '../config/database.php';


$user_id = (int) $_SESSION['user_id'];


/* =========================
   AMBIL PESAN
========================= */

$query = "
    SELECT *
    FROM messages
    WHERE user_id = '$user_id'
    ORDER BY id DESC
";

$result = mysqli_query($conn, $query);

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Pesan Saya - LinglungBooks
    </title>


    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >


    <link
        rel="preconnect"
        href="https://fonts.googleapis.com"
    >


    <link
        rel="preconnect"
        href="https://fonts.gstatic.com"
        crossorigin
    >


    <link
        href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Poppins:wght@300;400;500;600;700&display=swap"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        .messages-page {
            max-width: 1100px;
            margin: 0 auto;
            padding: 60px 30px 80px;
            min-height: 65vh;
        }


        /* =========================
           BACK BUTTON
        ========================= */

        .messages-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            margin-bottom: 25px;

            padding: 10px 16px;

            background: #F3E8D8;
            color: #6F4E37;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;
            font-weight: 500;

            transition: .3s;
        }


        .messages-back:hover {
            background: #E8D6BE;
            transform: translateX(-2px);
        }


        .messages-header {
            text-align: center;
            margin-bottom: 45px;
        }


        .messages-header h1 {
            font-family: "Cormorant Garamond", serif;
            font-size: 48px;
            color: #4B3621;
            margin-bottom: 10px;
        }


        .messages-header p {
            color: #6F4E37;
            font-size: 15px;
        }


        .message-list {
            display: flex;
            flex-direction: column;
            gap: 25px;
        }


        .message-card {
            background: #ffffff;
            border-radius: 18px;
            padding: 28px 30px;
            box-shadow: 0 5px 20px rgba(75, 54, 33, 0.08);
            border: 1px solid #E8DCCB;
        }


        .message-top {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 20px;
            margin-bottom: 20px;
        }


        .message-subject {
            margin: 0;
            font-size: 19px;
            font-weight: 600;
            color: #4B3621;
        }


        .message-date {
            font-size: 12px;
            color: #8B5E3C;
            white-space: nowrap;
        }


        .message-status {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 13px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 18px;
        }


        .status-waiting {
            background: #F3E8D8;
            color: #6F4E37;
        }


        .status-replied {
            background: #E8EFE5;
            color: #4D6845;
        }


        .message-label {
            font-size: 12px;
            font-weight: 600;
            color: #8B5E3C;
            margin-bottom: 7px;
        }


        .message-content {
            background: #F8F3EC;
            border-radius: 12px;
            padding: 16px 18px;
            color: #4B3621;
            font-size: 14px;
            line-height: 1.7;
            margin-bottom: 20px;
        }


        .admin-reply {
            background: #F3E8D8;
            border-left: 4px solid #6F4E37;
            border-radius: 0 12px 12px 0;
            padding: 18px 20px;
            color: #4B3621;
            font-size: 14px;
            line-height: 1.7;
        }


        .reply-header {
            display: flex;
            align-items: center;
            gap: 8px;
            color: #6F4E37;
            font-weight: 600;
            font-size: 13px;
            margin-bottom: 8px;
        }


        .reply-date {
            display: block;
            margin-top: 10px;
            font-size: 11px;
            color: #8B5E3C;
        }


        .empty-message {
            text-align: center;
            background: #ffffff;
            border-radius: 20px;
            padding: 70px 30px;
            box-shadow: 0 5px 20px rgba(75, 54, 33, 0.08);
            border: 1px solid #E8DCCB;
        }


        .empty-message i {
            font-size: 55px;
            color: #8B5E3C;
            margin-bottom: 20px;
        }


        .empty-message h2 {
            font-family: "Cormorant Garamond", serif;
            font-size: 30px;
            color: #4B3621;
            margin-bottom: 10px;
        }


        .empty-message p {
            color: #8B5E3C;
            font-size: 14px;
        }


        @media (max-width: 700px) {

            .messages-page {
                padding: 40px 18px 60px;
            }


            .messages-header h1 {
                font-size: 38px;
            }


            .message-card {
                padding: 22px;
            }


            .message-top {
                flex-direction: column;
                gap: 8px;
            }


            .message-date {
                white-space: normal;
            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


    <?php include '../includes/navbar_user.php'; ?>


    <main class="messages-page">


        <!-- BACK -->

        <a
            href="<?= htmlspecialchars(
                $back,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
            class="global-back-button"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>


        <!-- HEADER -->

        <div class="messages-header">

            <h1>
                Pesan Saya
            </h1>


            <p>
                Lihat pesan dan tanggapan dari admin LinglungBooks.
            </p>

        </div>


        <?php if ($result && mysqli_num_rows($result) > 0): ?>


            <div class="message-list">


                <?php while ($msg = mysqli_fetch_assoc($result)): ?>


                    <div class="message-card">


                        <div class="message-top">

                            <h2 class="message-subject">

                                <?= htmlspecialchars(
                                    $msg['subject']
                                ); ?>

                            </h2>


                            <span class="message-date">

                                <?= date(
                                    'd M Y, H:i',
                                    strtotime($msg['created_at'])
                                ); ?>

                            </span>

                        </div>


                        <?php if ($msg['status'] === 'replied'): ?>


                            <div class="message-status status-replied">

                                <i class="fa-solid fa-circle-check"></i>

                                Sudah Dibalas

                            </div>


                        <?php else: ?>


                            <div class="message-status status-waiting">

                                <i class="fa-solid fa-clock"></i>

                                Menunggu Balasan

                            </div>


                        <?php endif; ?>


                        <div class="message-label">

                            Pesan Kamu

                        </div>


                        <div class="message-content">

                            <?= nl2br(
                                htmlspecialchars(
                                    $msg['message']
                                )
                            ); ?>

                        </div>


                        <?php

                        /*
                         * Mendukung kolom admin_reply maupun reply.
                         * Jika database menggunakan admin_reply,
                         * kolom tersebut akan diprioritaskan.
                         */

                        $admin_reply = '';

                        if (isset($msg['admin_reply'])) {

                            $admin_reply =
                                $msg['admin_reply'];

                        } elseif (isset($msg['reply'])) {

                            $admin_reply =
                                $msg['reply'];

                        }

                        ?>


                        <?php if (
                            $msg['status'] === 'replied'
                            && !empty($admin_reply)
                        ): ?>


                            <div class="message-label">

                                Balasan Admin

                            </div>


                            <div class="admin-reply">


                                <div class="reply-header">

                                    <i class="fa-solid fa-reply"></i>

                                    Admin LinglungBooks

                                </div>


                                <?= nl2br(
                                    htmlspecialchars(
                                        $admin_reply
                                    )
                                ); ?>


                                <?php if (
                                    isset($msg['reply_date'])
                                    && !empty($msg['reply_date'])
                                ): ?>


                                    <span class="reply-date">

                                        Dibalas pada

                                        <?= date(
                                            'd M Y, H:i',
                                            strtotime(
                                                $msg['reply_date']
                                            )
                                        ); ?>

                                    </span>


                                <?php endif; ?>


                            </div>


                        <?php endif; ?>


                    </div>


                <?php endwhile; ?>


            </div>


        <?php else: ?>


            <div class="empty-message">

                <i class="fa-regular fa-envelope"></i>


                <h2>
                    Belum Ada Pesan
                </h2>


                <p>
                    Kamu belum mengirim pesan kepada admin LinglungBooks.
                </p>

            </div>


        <?php endif; ?>


    </main>


    <?php include '../includes/footer_user.php'; ?>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>