<?php

if (session_status() === PHP_SESSION_NONE) {
    if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
}


/* =========================================================
   HALAMAN SEBELUMNYA
========================================================= */

$is_logged_in = isset($_SESSION['user_id']);

$back = $_GET['back'] ?? ($is_logged_in ? 'dashboard.php' : '../index.php');

if ($back === '') {
    $back = $is_logged_in ? 'dashboard.php' : '../index.php';
}


/* =========================================================
   NORMALISASI BACK KE ROOT INDEX
========================================================= */

$back_path = parse_url($back, PHP_URL_PATH);

if ($back_path !== null) {

    $normalized_path = str_replace('\\', '/', $back_path);

    if (basename($normalized_path) === 'index.php') {

        $back_query = parse_url($back, PHP_URL_QUERY);

        $back = '../index.php';

        if ($back_query) {
            $back .= '?' . $back_query;
        }
    }
}


/* =========================================================
   VALIDASI BACK
========================================================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_root_index = ($back_path === '../index.php');

$is_safe_back =
    $is_root_index ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename(str_replace('\\', '/', $back_path ?? '')),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $is_logged_in ? 'dashboard.php' : '../index.php';
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tentang Kami | LinglungBooks</title>

    <link rel="stylesheet" href="../assets/css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <style>

        .about-section {
            max-width: 1100px;
            margin: 60px auto 80px;
            padding: 0 30px;
        }

        .about-card {
            background: #FFFFFF;
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .08);
        }

        .about-card h1 {
            font-size: 48px;
            margin-bottom: 20px;
            font-family: 'Cormorant Garamond', serif;
            color: #6F4E37;
        }

        .about-card h2 {
            margin-top: 35px;
            margin-bottom: 15px;
            color: #6F4E37;
            font-size: 25px;
        }

        .about-card p {
            line-height: 32px;
            color: #555;
            font-size: 15px;
        }

        .about-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;

            margin-top: 40px;
            padding: 11px 17px;

            background: #F3E8D8;
            color: #6F4E37;

            text-decoration: none;
            border-radius: 10px;

            font-size: 14px;
            font-weight: 500;

            transition: .3s;
        }

        .about-back:hover {
            background: #E8D6BE;
            transform: translateX(-2px);
        }

        @media (max-width: 768px) {

            .about-section {
                margin: 40px auto 60px;
                padding: 0 20px;
            }

            .about-card {
                padding: 30px 25px;
            }

            .about-card h1 {
                font-size: 38px;
            }

            .about-card h2 {
                font-size: 22px;
            }

            .about-card p {
                line-height: 28px;
                font-size: 14px;
            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<?php include '../includes/navbar_user.php'; ?>


<section class="about-section">

    <div class="about-card">

        <h1>
            Tentang LinglungBooks
        </h1>


        <p>
            LinglungBooks adalah toko buku online yang dibuat untuk memudahkan
            para pembaca dalam menemukan dan membeli buku dari berbagai kategori.
            Kami hadir untuk menyediakan platform yang sederhana, elegan, dan
            mudah digunakan, sehingga setiap orang dapat menikmati kegiatan
            membaca sekaligus menemukan berbagai pengetahuan dan cerita baru.
        </p>


        <h2>
            Visi Kami
        </h2>


        <p>
            Menjadi toko buku online yang terpercaya dan dapat menginspirasi
            masyarakat untuk membaca, belajar, serta berkembang melalui
            buku-buku berkualitas.
        </p>


        <h2>
            Misi Kami
        </h2>


        <p>
            • Menyediakan buku berkualitas dengan harga yang terjangkau.<br>

            • Memberikan pengalaman berbelanja yang sederhana dan menyenangkan.<br>

            • Mendorong kebiasaan membaca untuk berbagai kalangan.<br>

            • Terus meningkatkan pelayanan dan koleksi buku yang tersedia.
        </p>


        <a
            href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8'); ?>"
            class="global-back-button"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>

    </div>

</section>


<?php include '../includes/footer_user.php'; ?>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>