<?php

if (session_status() === PHP_SESSION_NONE) {
    if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
}

include '../config/database.php';


/* =========================================================
   STATUS LOGIN
========================================================= */

$is_logged_in = isset($_SESSION['user_id']);

if (!$is_logged_in) {

    $back = $_GET['back'] ?? '../index.php';

    header(
        "Location: login.php?back=" .
        urlencode($back)
    );

    exit;
}


/* =========================================================
   HALAMAN SEBELUMNYA
========================================================= */

$back = $_GET['back'] ?? 'dashboard.php';

if ($back === '') {
    $back = 'dashboard.php';
}


/* =========================================================
   KIRIM PESAN
========================================================= */

$message = "";

if (isset($_POST['send'])) {

    $user_id = (int) $_SESSION['user_id'];

    $subject = mysqli_real_escape_string(
        $conn,
        $_POST['subject']
    );

    $text = mysqli_real_escape_string(
        $conn,
        $_POST['message']
    );

    mysqli_query($conn, "
        INSERT INTO messages(user_id, subject, message, status)
        VALUES('$user_id', '$subject', '$text', 'unreplied')
    ");

    $message = "Pesan berhasil dikirim kepada admin.";

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Hubungi Kami | LinglungBooks</title>

    <link rel="stylesheet" href="../assets/css/style.css">

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <style>

        .contact-section {

            max-width: 900px;

            margin: 60px auto 80px;

            padding: 0 30px;

        }


        .contact-card {

            background: #FFFFFF;

            padding: 45px;

            border-radius: 20px;

            box-shadow: 0 10px 25px rgba(0, 0, 0, .08);

        }


        .contact-header {

            text-align: center;

            margin-bottom: 35px;

        }


        .contact-header h1 {

            margin: 0 0 10px;

            font-family: 'Cormorant Garamond', serif;

            font-size: 48px;

            color: #6F4E37;

        }


        .contact-header p {

            margin: 0;

            color: #777;

            font-size: 14px;

            line-height: 25px;

        }


        .success {

            background: #F3E8D8;

            color: #6F4E37;

            padding: 15px 18px;

            border-radius: 10px;

            margin-bottom: 25px;

            text-align: center;

            font-size: 14px;

        }


        .input-group {

            margin-bottom: 22px;

        }


        .input-group label {

            display: block;

            margin-bottom: 8px;

            color: #4B3621;

            font-size: 14px;

            font-weight: 600;

        }


        .input-group input,

        .input-group textarea {

            width: 100%;

            box-sizing: border-box;

            padding: 14px 16px;

            border: 1px solid #D8C8B8;

            border-radius: 10px;

            outline: none;

            background: #FFFDF9;

            color: #4B3621;

            font-family: 'Poppins', sans-serif;

            font-size: 14px;

            transition: .3s;

        }


        .input-group input:focus,

        .input-group textarea:focus {

            border-color: #8B5E3C;

            box-shadow: 0 0 0 3px rgba(139, 94, 60, .10);

        }


        .input-group textarea {

            height: 180px;

            resize: vertical;

            min-height: 140px;

            max-height: 350px;

        }


        .send-button {

            width: 100%;

            padding: 14px 20px;

            border: none;

            background: #6F4E37;

            color: white;

            font-family: 'Poppins', sans-serif;

            font-size: 15px;

            font-weight: 500;

            border-radius: 10px;

            cursor: pointer;

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 9px;

            transition: .3s;

        }


        .send-button:hover {

            background: #8B5E3C;

            transform: translateY(-1px);

        }


        .contact-back {

            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-top: 25px;

            padding: 11px 17px;

            background: #F3E8D8;

            color: #6F4E37;

            text-decoration: none;

            border-radius: 10px;

            font-size: 14px;

            font-weight: 500;

            transition: .3s;

        }


        .contact-back:hover {

            background: #E8D6BE;

            transform: translateX(-2px);

        }


        .contact-note {

            margin-top: 20px;

            padding: 15px;

            background: #F8F3EC;

            border-radius: 10px;

            color: #777;

            font-size: 13px;

            line-height: 23px;

        }


        .contact-note i {

            color: #6F4E37;

            margin-right: 6px;

        }


        @media (max-width: 768px) {

            .contact-section {

                margin: 40px auto 60px;

                padding: 0 20px;

            }


            .contact-card {

                padding: 30px 25px;

            }


            .contact-header h1 {

                font-size: 38px;

            }


            .contact-header p {

                font-size: 13px;

            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<?php include '../includes/navbar_user.php'; ?>


<section class="contact-section">

    <div class="contact-card">


        <div class="contact-header">

            <h1>Hubungi Kami</h1>

            <p>
                Punya pertanyaan, saran, atau membutuhkan bantuan?
                Kirimkan pesan kepada admin LinglungBooks melalui formulir di bawah ini.
            </p>

        </div>


        <?php if ($message != "") { ?>

            <div class="success">

                <i class="fa-solid fa-circle-check"></i>

                <?= htmlspecialchars($message); ?>

            </div>

        <?php } ?>


        <form method="POST">


            <div class="input-group">

                <label for="subject">
                    Subjek
                </label>

                <input
                    type="text"
                    id="subject"
                    name="subject"
                    placeholder="Masukkan subjek pesan"
                    required
                >

            </div>


            <div class="input-group">

                <label for="message">
                    Pesan
                </label>

                <textarea
                    id="message"
                    name="message"
                    placeholder="Tuliskan pesan kamu kepada admin..."
                    required
                ></textarea>

            </div>


            <button
                type="submit"
                name="send"
                class="send-button"
            >

                <i class="fa-solid fa-paper-plane"></i>

                Kirim Pesan

            </button>


        </form>


        <div class="contact-note">

            <i class="fa-solid fa-circle-info"></i>

            Pesan yang kamu kirim dapat dilihat dan dibalas oleh admin
            melalui halaman pesan akunmu.

        </div>


        <a
            href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8'); ?>"
            class="global-back-button"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>


    </div>

</section>


<?php include '../includes/footer_user.php'; ?>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>