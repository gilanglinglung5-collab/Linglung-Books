<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

include '../config/database.php';

/* =========================================================
   HARUS LOGIN
========================================================= */

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
    header("Location: login.php?back=dashboard.php");
    exit;
}

/* Ambil wishlist hanya setelah sesi user tervalidasi. */
$wishlist_ids = [];
$wishlist_user_id = (int) $_SESSION['user_id'];
$wishlist_result = mysqli_query($conn, "SELECT book_id FROM wishlist WHERE user_id = '$wishlist_user_id'");
if ($wishlist_result) {
    while ($wishlist_row = mysqli_fetch_assoc($wishlist_result)) {
        $wishlist_ids[] = (int) $wishlist_row['book_id'];
    }
}


/* =========================================================
   FILTER
========================================================= */

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$category_id = isset($_GET['category'])
    ? (int) $_GET['category']
    : 0;

$search_safe = mysqli_real_escape_string(
    $conn,
    $search
);


/* =========================================================
   CURRENT URL
========================================================= */

$current_url = 'dashboard.php';

$current_params = [];

if ($search !== '') {
    $current_params['search'] = $search;
}

if ($category_id > 0) {
    $current_params['category'] = $category_id;
}

if (!empty($current_params)) {
    $current_url .= '?' . http_build_query($current_params);
}


/* =========================================================
   ADD TO CART
========================================================= */

if (isset($_POST['add_to_cart'])) {

    $user_id = (int) $_SESSION['user_id'];

    $book_id = isset($_POST['book_id'])
        ? (int) $_POST['book_id']
        : 0;


    /* =====================================================
       VALIDASI BOOK ID
    ===================================================== */

    if ($book_id <= 0) {

        header(
            "Location: dashboard.php"
            . (!empty($current_params)
                ? '?' . http_build_query($current_params)
                : '')
        );

        exit;
    }


    /* =====================================================
       CEK BUKU
    ===================================================== */

    $book_query = mysqli_query(
        $conn,
        "
        SELECT
            id,
            stock
        FROM books
        WHERE id = '$book_id'
        LIMIT 1
        "
    );


    if (
        !$book_query ||
        mysqli_num_rows($book_query) === 0
    ) {

        header(
            "Location: dashboard.php"
            . (!empty($current_params)
                ? '?' . http_build_query($current_params)
                : '')
        );

        exit;
    }


    $book = mysqli_fetch_assoc($book_query);

    $stock = (int) $book['stock'];


    /* =====================================================
       CEK STOCK
    ===================================================== */

    if ($stock <= 0) {

        header(
            "Location: dashboard.php"
            . (!empty($current_params)
                ? '?' . http_build_query($current_params)
                : '')
        );

        exit;
    }


    /* =====================================================
       CEK CART
    ===================================================== */

    $cart_query = mysqli_query(
        $conn,
        "
        SELECT
            id,
            quantity
        FROM cart
        WHERE user_id = '$user_id'
        AND book_id = '$book_id'
        LIMIT 1
        "
    );


    if (
        $cart_query &&
        mysqli_num_rows($cart_query) > 0
    ) {

        /* =================================================
           BARANG SUDAH ADA DI CART
        ================================================= */

        $cart = mysqli_fetch_assoc($cart_query);

        $current_quantity =
            (int) $cart['quantity'];

        $new_quantity =
            $current_quantity + 1;


        /* =================================================
           BATASI SESUAI STOK
        ================================================= */

        if ($new_quantity > $stock) {

            $new_quantity = $stock;
        }


        mysqli_query(
            $conn,
            "
            UPDATE cart
            SET quantity = '$new_quantity'
            WHERE id = '" . (int) $cart['id'] . "'
            AND user_id = '$user_id'
            "
        );


    } else {

        /* =================================================
           BARANG BELUM ADA DI CART
        ================================================= */

        mysqli_query(
            $conn,
            "
            INSERT INTO cart
            (
                user_id,
                book_id,
                quantity
            )
            VALUES
            (
                '$user_id',
                '$book_id',
                1
            )
            "
        );
    }


    /* =====================================================
       LANGSUNG KE CART
    ===================================================== */

    header(
        "Location: cart.php?back="
        . urlencode($current_url)
    );

    exit;
}


/* =========================================================
   QUERY 8 BEST SELLER
========================================================= */

$sql = "
    SELECT
        books.id,
        books.title,
        books.author,
        books.publisher,
        books.price,
        books.stock,
        books.cover,
        books.category_id,

        categories.category_name,

        COALESCE(
            (
                SELECT SUM(order_details.quantity)
                FROM order_details

                INNER JOIN orders
                    ON order_details.order_id = orders.id

                WHERE order_details.book_id = books.id
                AND orders.status != 'Cancelled'
            ),
            0
        ) AS total_sold

    FROM books

    LEFT JOIN categories
        ON books.category_id = categories.id

    WHERE 1 = 1
";


/* =========================================================
   SEARCH
========================================================= */

if ($search !== '') {

    $sql .= "
        AND (
            books.title LIKE '%$search_safe%'
            OR books.author LIKE '%$search_safe%'
            OR books.publisher LIKE '%$search_safe%'
            OR categories.category_name LIKE '%$search_safe%'
        )
    ";
}


/* =========================================================
   CATEGORY
========================================================= */

if ($category_id > 0) {

    $sql .= "
        AND books.category_id = $category_id
    ";
}


/* =========================================================
   BEST SELLER
========================================================= */

$sql .= "
    ORDER BY total_sold DESC, books.id DESC
    LIMIT 8
";


$query = mysqli_query(
    $conn,
    $sql
);


/* =========================================================
   QUERY KATEGORI
========================================================= */

$categories = mysqli_query(
    $conn,
    "
    SELECT
        id,
        category_name,
        icon
    FROM categories
    ORDER BY category_name ASC
    "
);

?>


<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>LinglungBooks</title>


    <!-- CSS USER -->

    <link
        rel="stylesheet"
        href="../assets/css/user.css"
    >


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        /* =====================================================
           BOOK GRID
        ===================================================== */

        .featured .book-container {

            display: grid;

            grid-template-columns: repeat(4, 1fr);

            gap: 24px;

            align-items: stretch;
        }


        /* =====================================================
           CARD
        ===================================================== */

        .featured .book-card {

            position: relative;

            background: #FFFFFF;

            border-radius: 18px;

            overflow: hidden;

            border: 1px solid rgba(111, 78, 55, .07);

            box-shadow:
                0 7px 25px rgba(75, 54, 33, .06);

            display: flex;

            flex-direction: column;

            min-height: 610px;

            transition:
                transform .3s ease,
                box-shadow .3s ease;
        }


        .featured .book-card:hover {

            transform: translateY(-6px);

            box-shadow:
                0 15px 35px rgba(75, 54, 33, .12);
        }


        /* =====================================================
           COVER
        ===================================================== */

        .featured .book-cover-wrapper {

            position: relative;

            width: 100%;

            height: 300px;

            background: #F3E8D8;

            overflow: hidden;

            display: flex;

            align-items: center;

            justify-content: center;
        }


        .featured .book-cover {

            width: 100%;

            height: 100%;

            object-fit: contain;

            display: block;

            transition: transform .45s ease;
        }


        .featured .book-card:hover .book-cover {

            transform: scale(1.035);
        }


        /* =====================================================
           PLACEHOLDER
        ===================================================== */

        .featured .book-cover-placeholder {

            width: 100%;

            height: 100%;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #6F4E37;

            font-size: 45px;
        }


        /* =====================================================
           INFO
        ===================================================== */

        .featured .book-info {

            padding: 18px;

            display: flex;

            flex-direction: column;

            flex: 1;
        }


        /* =====================================================
           CATEGORY
        ===================================================== */

        .featured .book-category {

            display: inline-block;

            width: fit-content;

            max-width: 100%;

            padding: 5px 9px;

            background: #F3E8D8;

            color: #8B5E3C;

            border-radius: 6px;

            font-size: 10px;

            font-weight: 600;

            margin-bottom: 10px;
        }


        /* =====================================================
           TITLE
        ===================================================== */

        .featured .book-title {

            color: #4B3621;

            font-size: 17px;

            line-height: 1.4;

            font-weight: 600;

            margin-bottom: 7px;

            min-height: 48px;

            display: -webkit-box;

            -webkit-line-clamp: 2;

            -webkit-box-orient: vertical;

            overflow: hidden;
        }


        /* =====================================================
           AUTHOR
        ===================================================== */

        .featured .book-author {

            color: #888;

            font-size: 12px;

            line-height: 1.5;

            margin-bottom: 14px;

            min-height: 18px;

            white-space: nowrap;

            overflow: hidden;

            text-overflow: ellipsis;
        }


        /* =====================================================
           PRICE
        ===================================================== */

        .featured .book-price {

            color: #6F4E37;

            font-size: 17px;

            font-weight: 700;

            margin-top: auto;

            margin-bottom: 9px;
        }


        /* =====================================================
           STOCK
        ===================================================== */

        .featured .stock {

            font-size: 11px;

            margin-bottom: 14px;

            min-height: 17px;
        }


        .featured .stock.available {

            color: #567A32;
        }


        .featured .stock.empty {

            color: #B23A2B;

            font-weight: 600;
        }


        /* =====================================================
           ACTIONS
        ===================================================== */

        .featured .book-actions {

            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 8px;

            margin-top: 0;
        }


        .featured .detail-button,
        .featured .cart-button {

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 6px;

            min-height: 40px;

            padding: 10px 8px;

            border-radius: 10px;

            font-family: 'Poppins', sans-serif;

            font-size: 11px;

            font-weight: 500;

            transition: .3s;

            box-sizing: border-box;
        }


        /* =====================================================
           DETAIL
        ===================================================== */

        .featured .detail-button {

            background: #F3E8D8;

            color: #6F4E37;

            text-decoration: none;

            border: 1px solid #E8D6BE;
        }


        .featured .detail-button:hover {

            background: #E8D6BE;
        }


        /* =====================================================
           CART
        ===================================================== */

        .featured .cart-form {

            margin: 0;

            padding: 0;
        }


        .featured .cart-button {

            width: 100%;

            border: none;

            background: #6F4E37;

            color: #FFFFFF;

            cursor: pointer;
        }


        .featured .cart-button:hover {

            background: #8B5E3C;

            transform: translateY(-1px);
        }


        .featured .cart-button.disabled {

            background: #D5D0CA;

            color: #888;

            cursor: not-allowed;

            transform: none;
        }


        /* =====================================================
           LIHAT SEMUA
        ===================================================== */

        .see-all-container {

            text-align: center;

            margin-top: 40px;
        }


        .see-all-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 10px;

            padding: 13px 28px;

            background: #6F4E37;

            color: #FFFFFF;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 500;

            transition: .3s;
        }


        .see-all-btn:hover {

            background: #8B5E3C;

            transform: translateY(-2px);
        }


        /* =====================================================
           EMPTY
        ===================================================== */

        .empty-book {

            width: 100%;

            text-align: center;

            padding: 50px 20px;
        }


        .empty-book i {

            font-size: 42px;

            margin-bottom: 15px;
        }


        .empty-book h3 {

            margin-bottom: 8px;
        }


        .empty-book p {

            margin: 0;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1150px) {

            .featured .book-container {

                grid-template-columns: repeat(3, 1fr);
            }
        }


        @media (max-width: 900px) {

            .featured .book-container {

                grid-template-columns: repeat(2, 1fr);
            }
        }


        @media (max-width: 650px) {

            .featured .book-container {

                grid-template-columns: 1fr;

                gap: 18px;
            }


            .featured .book-card {

                min-height: 0;
            }


            .featured .book-cover-wrapper {

                height: 340px;
            }


            .featured .book-actions {

                grid-template-columns: 1fr 1fr;
            }


            .see-all-container {

                margin-top: 30px;
            }


            .see-all-btn {

                width: 100%;

                max-width: 300px;
            }
        }

    </style>
    <link rel="stylesheet" href="../assets/css/book-cards-shared.css?v=3">

    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<?php include '../includes/navbar_user.php'; ?>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">

    <div class="hero-text">

        <h1>
            Temukan Cerita yang Selalu Berkesan.
        </h1>

        <p>
            Selamat datang di LinglungBooks, toko buku online
            elegan tempat setiap halaman membuka petualangan baru.
        </p>

        <a
            href="#categories"
            class="explore"
        >
            Jelajahi Kategori
        </a>

    </div>

</section>


<!-- =========================================================
     KATEGORI
========================================================= -->

<section
    class="categories"
    id="categories"
>

    <h2>
        Jelajahi Berdasarkan Kategori
    </h2>

    <p class="subtitle">
        Pilih kategori buku favoritmu.
    </p>


    <div class="category-container">

        <?php if (
            $categories &&
            mysqli_num_rows($categories) > 0
        ): ?>

            <?php while (
                $category = mysqli_fetch_assoc($categories)
            ): ?>

                <?php

                $icon = !empty($category['icon'])
                    ? $category['icon']
                    : 'fa-tags';

                ?>

                <a
                    href="dashboard.php?category=<?= (int) $category['id']; ?>#books"
                    class="category-card"
                >

                    <i
                        class="fa-solid <?= htmlspecialchars(
                            $icon,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                    ></i>


                    <h3>

                        <?= htmlspecialchars(
                            $category['category_name'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>

                    </h3>

                </a>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-book">

                <i class="fa-solid fa-tags"></i>

                <h3>
                    Belum Ada Kategori
                </h3>

                <p>
                    Kategori buku belum tersedia.
                </p>

            </div>

        <?php endif; ?>

    </div>

</section>


<!-- =========================================================
     BEST SELLER
========================================================= -->

<section
    class="featured"
    id="books"
>

    <h2>
        Buku Best Seller
    </h2>

    <p class="subtitle">
        Temukan buku yang paling banyak dipilih oleh pembaca.
    </p>


    <!-- SEARCH -->

    <form
        method="GET"
        class="search-form"
    >

        <input
            type="text"
            name="search"
            placeholder="Cari buku atau penulis..."
            value="<?= htmlspecialchars(
                $search,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
        >


        <?php if ($category_id > 0): ?>

            <input
                type="hidden"
                name="category"
                value="<?= $category_id; ?>"
            >

        <?php endif; ?>


        <button type="submit">
            Cari
        </button>

    </form>


    <!-- BOOK GRID -->

    <div class="book-container">

        <?php if (
            $query &&
            mysqli_num_rows($query) > 0
        ): ?>

            <?php while (
                $book = mysqli_fetch_assoc($query)
            ): ?>

                <article class="book-card">


                    <!-- COVER -->

                    <div class="book-cover-wrapper">
<?php if (
                            !empty($book['cover'])
                        ): ?>

                            <img
                                src="../assets/img/<?= htmlspecialchars(
                                    $book['cover'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                alt="<?= htmlspecialchars(
                                    $book['title'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                class="book-cover"
                                loading="lazy"
                            >

                        <?php else: ?>

                            <div class="book-cover-placeholder">

                                <i class="fa-solid fa-book"></i>

                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- INFO -->

                    <div class="book-info">


                        <!-- CATEGORY -->

                        <div class="book-category">

                            <?= htmlspecialchars(
                                $book['category_name'] ??
                                'Tanpa Kategori',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- TITLE -->

                        <div class="book-title">

                            <?= htmlspecialchars(
                                $book['title'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- AUTHOR -->

                        <div class="book-author">

                            Oleh

                            <?= htmlspecialchars(
                                $book['author'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- PRICE -->

                        <div class="book-price">

                            Rp

                            <?= number_format(
                                $book['price'],
                                0,
                                ',',
                                '.'
                            ); ?>

                        </div>


                        <!-- STOCK -->

                        <?php if (
                            (int) $book['stock'] > 0
                        ): ?>

                            <div class="stock available">

                                Stok tersedia:

                                <?= (int) $book['stock']; ?>

                            </div>

                        <?php else: ?>

                            <div class="stock empty">

                                Stok habis

                            </div>

                        <?php endif; ?>


                        <!-- ACTIONS -->

                        <div class="book-actions">

                            <!-- WISHLIST -->
                            <button
                                type="button"
                                class="wishlist-card-btn <?= in_array((int) $book['id'], $wishlist_ids, true) ? 'active' : ''; ?>"
                                data-book-id="<?= (int) $book['id']; ?>"
                                aria-label="<?= in_array((int) $book['id'], $wishlist_ids, true) ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist'; ?>"
                            >
                                <i class="fa-<?= in_array((int) $book['id'], $wishlist_ids, true) ? 'solid' : 'regular'; ?> fa-heart"></i>
                                <span><?= in_array((int) $book['id'], $wishlist_ids, true) ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist'; ?></span>
                            </button>

                            <!-- DETAIL -->

                            <a
                                href="detail.php?id=<?= (int) $book['id']; ?>&back=<?= urlencode($current_url); ?>"
                                class="detail-button"
                            >

                                <i class="fa-solid fa-eye"></i>

                                Detail

                            </a>


                            <!-- CART -->

                            <?php if (
                                (int) $book['stock'] > 0
                            ): ?>

                                <form
                                    method="POST"
                                    action="<?= htmlspecialchars(
                                        $current_url,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>"
                                    class="cart-form"
                                >

                                    <input
                                        type="hidden"
                                        name="book_id"
                                        value="<?= (int) $book['id']; ?>"
                                    >


                                    <button
                                        type="submit"
                                        name="add_to_cart"
                                        class="cart-button"
                                    >

                                        <i class="fa-solid fa-cart-plus"></i>

                                        Keranjang

                                    </button>

                                </form>

                            <?php else: ?>

                                <button
                                    type="button"
                                    class="cart-button disabled"
                                    disabled
                                >

                                    <i class="fa-solid fa-ban"></i>

                                    Habis

                                </button>

                            <?php endif; ?>

                        </div>

                    </div>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-book">

                <i class="fa-solid fa-book-open"></i>

                <h3>
                    Buku Tidak Ditemukan
                </h3>

                <p>
                    Coba gunakan kata kunci pencarian
                    atau kategori yang berbeda.
                </p>

            </div>

        <?php endif; ?>

    </div>


    <!-- LIHAT SEMUA -->

    <div class="see-all-container">

        <a
            href="books.php?back=<?= urlencode($current_url); ?>"
            class="see-all-btn"
        >

            Lihat Semua Buku

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>

</section>


<?php include '../includes/footer_user.php'; ?>


<script>
document.querySelectorAll('.wishlist-card-btn').forEach(button => {
    button.addEventListener('click', async () => {
        const body = new URLSearchParams({ book_id: button.dataset.bookId });
        try {
            const response = await fetch('wishlist_toggle.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body
            });
            const result = await response.json();
            if (result.login) {
                window.location.href = 'login.php?back=' + encodeURIComponent('dashboard.php');
                return;
            }
            if (!result.success) {
                alert(result.message || 'Wishlist gagal diperbarui.');
                return;
            }
            button.classList.toggle('active', !!result.active);
            button.querySelector('i').className = (result.active ? 'fa-solid' : 'fa-regular') + ' fa-heart';
            button.querySelector('span').textContent = result.active ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist';
            button.setAttribute('aria-label', result.active ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist');
        } catch (error) {
            alert('Tidak dapat menghubungi server. Coba lagi.');
        }
    });
});
</script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>