<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'dashboard.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   NORMALISASI INDEX
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {

    header(
        "Location: login.php?back=" .
        urlencode($back)
    );

    exit;
}


include '../config/database.php';


$user_id = (int) $_SESSION['user_id'];


/* =========================
   AMBIL PESANAN
========================= */

$query = mysqli_query($conn, "
    SELECT *
    FROM orders
    WHERE user_id = '$user_id'
    ORDER BY id DESC
");

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Pesanan Saya | LinglungBooks
    </title>


    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        * {
            box-sizing: border-box;
        }


        body {
            margin: 0;

            background: #F8F3EC;

            color: #4B3621;

            font-family: Poppins, sans-serif;
        }


        .orders-page {
            width: 90%;

            max-width: 1200px;

            margin: 55px auto 80px;
        }


        .orders-title {
            font-family: 'Cormorant Garamond', serif;

            font-size: 48px;

            color: #4B3621;

            margin-bottom: 12px;
        }


        /* =========================
           BACK BUTTON
        ========================= */

        .back-button {
            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-bottom: 30px;

            color: #6F4E37;

            text-decoration: none;

            font-size: 13px;

            font-weight: 500;

            transition: .3s;
        }


        .back-button:hover {
            color: #8B5E3C;

            transform: translateX(-2px);
        }


        /* =========================
           ORDER BOX
        ========================= */

        .order-box {
            background: #FFFFFF;

            border-radius: 20px;

            padding: 30px;

            box-shadow:
                0 10px 25px rgba(0, 0, 0, .08);
        }


        .table-wrapper {
            width: 100%;

            overflow-x: auto;
        }


        table {
            width: 100%;

            min-width: 950px;

            border-collapse: collapse;
        }


        th {
            background: #6F4E37;

            color: #FFFFFF;

            padding: 15px;

            font-size: 14px;

            font-weight: 500;
        }


        td {
            padding: 17px;

            text-align: center;

            border-bottom: 1px solid #EEEEEE;

            color: #4B3621;

            font-size: 14px;
        }


        tr:hover {
            background: #FAF6F0;
        }


        tr:last-child td {
            border-bottom: none;
        }


        /* =========================
           ORDER ID
        ========================= */

        .order-id {
            font-weight: 600;

            color: #6F4E37;
        }


        /* =========================
           STATUS
        ========================= */

        .status.shipped { background:#e2efff; color:#245a91; }
        .status {
            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 6px;

            padding: 6px 13px;

            border-radius: 20px;

            font-size: 12px;

            font-weight: 600;
        }


        .pending {
            background: #F3E8D8;

            color: #856404;
        }


        .paid {
            background: #E8E1D8;

            color: #6F4E37;
        }


        .cancelled {
            background: #EAD8D5;

            color: #8B3A32;
        }


        /* =========================
           ACTION BUTTONS
        ========================= */

        .action-buttons {
            display: flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            flex-wrap: wrap;
        }


        .detail,
        .receipt {
            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 7px;

            color: #FFFFFF;

            padding: 9px 13px;

            border-radius: 8px;

            text-decoration: none;

            font-size: 12px;

            transition: .3s;
        }


        .detail {
            background: #6F4E37;
        }


        .detail:hover {
            background: #8B5E3C;

            transform: translateY(-1px);
        }


        .receipt {
            background: #8B5E3C;
        }


        .receipt:hover {
            background: #6F4E37;

            transform: translateY(-1px);
        }


        /* =========================
           EMPTY
        ========================= */

        .empty {
            text-align: center;

            padding: 55px 20px !important;

            color: #777;
        }


        .empty-icon {
            width: 70px;

            height: 70px;

            margin: 0 auto 18px;

            display: flex;

            align-items: center;

            justify-content: center;

            color: #6F4E37;

            background: #F3E8D8;

            border-radius: 50%;

            font-size: 30px;
        }


        .empty-icon i {
            color: #6F4E37;
        }


        .empty-text {
            font-size: 15px;

            color: #6F4E37;

            font-weight: 500;
        }


        /* =========================
           SHOP BUTTON
        ========================= */

        .shop-button {
            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            margin-top: 18px;

            background: #6F4E37;

            color: #FFFFFF;

            padding: 11px 22px;

            border-radius: 25px;

            text-decoration: none;

            font-size: 13px;

            transition: .3s;
        }


        .shop-button:hover {
            background: #8B5E3C;

            transform: translateY(-1px);
        }


        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 768px) {

            .orders-page {
                width: 94%;

                margin: 40px auto 60px;
            }


            .orders-title {
                font-size: 40px;
            }


            .order-box {
                padding: 15px;

                border-radius: 15px;
            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<?php include '../includes/navbar_user.php'; ?>


<main class="orders-page">


    <h1 class="orders-title">

        Pesanan Saya

    </h1>


    <a
        href="<?= htmlspecialchars(
            $back,
            ENT_QUOTES,
            'UTF-8'
        ); ?>"
        class="global-back-button"
    >

        <i class="fa-solid fa-arrow-left"></i>

        Kembali

    </a>


    <div class="order-box">


        <div class="table-wrapper">


            <table>


                <thead>

                    <tr>

                        <th>No</th>

                        <th>ID Pesanan</th>

                        <th>Penerima</th>

                        <th>Total</th>

                        <th>Pembayaran</th>

                        <th>Status</th>

                        <th>Tanggal</th>

                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>


                <?php

                $no = 1;

                if (
                    $query &&
                    mysqli_num_rows($query) > 0
                ) {

                    while (
                        $order =
                        mysqli_fetch_assoc($query)
                    ) {

                        $status =
                            strtolower(
                                $order['status']
                            );

                ?>


                    <tr>


                        <td>

                            <?= $no++; ?>

                        </td>


                        <!-- KODE TRANSAKSI: kode yang mudah dibaca pelanggan pada daftar pesanan. -->
<td class="order-id">

                            #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order['id'], ENT_QUOTES, 'UTF-8'); ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $order['recipient_name']
                            ); ?>

                        </td>


                        <td>

                            Rp<?= number_format(
                                $order['total_price'],
                                0,
                                ",",
                                "."
                            ); ?>

                        </td>


                        <td>

                            <?= htmlspecialchars(
                                $order['payment_method']
                            ); ?>

                        </td>


                        <td>


                            <?php

                            $statusLabels = [
                                'processing' => 'Diproses', 'packed' => 'Dikemas', 'shipped' => 'Dikirim',
                                'received' => 'Diterima', 'completed' => 'Selesai', 'returnrequested' => 'Retur Menunggu',
                                'returnapproved' => 'Retur Disetujui', 'returnrejected' => 'Retur Ditolak',
                                'returnshipped' => 'Retur Dikirim', 'returned' => 'Retur Tiba di Gudang', 'refunded' => 'Dana Dikembalikan', 'cancelled' => 'Dibatalkan'
                            ];
                            $statusKey = strtolower(str_replace('_', '', $order['status'] ?? 'processing'));
                            $statusLabel = $statusLabels[$statusKey] ?? 'Diproses';
                            $statusClass = in_array($statusKey, ['completed','refunded'], true) ? 'completed' : (in_array($statusKey, ['shipped','returnshipped'], true) ? 'shipped' : 'pending');
                            echo '<span class="status ' . $statusClass . '">' . htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8') . '</span>';

                            ?>


                        </td>


                        <td>

                            <?= date(
                                'd M Y, H:i',
                                strtotime(
                                    $order['created_at']
                                )
                            ); ?>

                        </td>


                        <td>


                            <div class="action-buttons">


                                <!-- LIHAT DETAIL -->

                                <a
                                    class="detail"
                                    href="order_detail.php?id=<?= (int) $order['id']; ?>&back=<?= urlencode('orders.php'); ?>"
                                >

                                    <i class="fa-solid fa-eye"></i>

                                    Detail

                                </a>


                                <!-- LIHAT STRUK -->

                                <a
                                    class="receipt"
                                    href="receipt.php?id=<?= (int) $order['id']; ?>&back=<?= urlencode('orders.php'); ?>"
                                >

                                    <i class="fa-solid fa-receipt"></i>

                                    Struk

                                </a>


                            </div>


                        </td>


                    </tr>


                <?php

                    }

                } else {

                ?>


                    <tr>

                        <td
                            colspan="8"
                            class="empty"
                        >


                            <div class="empty-icon">

                                <i class="fa-solid fa-book-open"></i>

                            </div>


                            <div class="empty-text">

                                Kamu belum memiliki pesanan.

                            </div>


                            <a
                                href="books.php?back=<?= urlencode('orders.php'); ?>"
                                class="shop-button"
                            >

                                <i class="fa-solid fa-book"></i>

                                Mulai Belanja

                            </a>


                        </td>

                    </tr>


                <?php } ?>


                </tbody>


            </table>


        </div>


    </div>


</main>


<?php include '../includes/footer_user.php'; ?>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>