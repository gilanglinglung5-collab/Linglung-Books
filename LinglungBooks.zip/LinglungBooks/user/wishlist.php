<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
require_once '../config/database.php';

// =========================================================
// CEK LOGIN
// =========================================================

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?back=' . urlencode('wishlist.php'));
    exit;
}

$user_id = (int) $_SESSION['user_id'];


// =========================================================
// TENTUKAN HALAMAN SEBELUMNYA
// =========================================================

$default_back = 'dashboard.php';
$back = $_GET['back'] ?? $default_back;

if ($back === 'index.php') {
    $back = '../index.php';
}

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'wishlist.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


// =========================================================
// URL HALAMAN WISHLIST
// =========================================================

$current_url = 'wishlist.php';


// =========================================================
// AMBIL DATA WISHLIST
// =========================================================

$sql = "
    SELECT
        b.id,
        b.title,
        b.author,
        b.price,
        b.stock,
        b.cover
    FROM wishlist w
    INNER JOIN books b
        ON w.book_id = b.id
    WHERE w.user_id = ?
    ORDER BY w.created_at DESC
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$books = [];

while ($row = mysqli_fetch_assoc($result)) {
    $books[] = $row;
}

mysqli_stmt_close($stmt);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Wishlist | LinglungBooks</title>


    <!-- GOOGLE FONTS -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >


    <!-- CSS -->

    <link rel="stylesheet" href="../assets/css/style.css">

    <link rel="stylesheet" href="../assets/css/back-button.css">

    <link rel="stylesheet" href="../assets/css/enhancements.css">


    <style>

        /* =====================================================
           WISHLIST PAGE
        ===================================================== */

        .wishlist-page {
            max-width: 1200px;
            margin: 0 auto;
            padding: 45px 30px 80px;
            min-height: 55vh;
        }


        /* =====================================================
           BACK BUTTON
        ===================================================== */

        .wishlist-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 25px;
            padding: 10px 16px;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 10px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: .3s;
        }

        .wishlist-back:hover {
            background: #E8D6BE;
            transform: translateX(-3px);
        }


        /* =====================================================
           TITLE
        ===================================================== */

        .wishlist-title {
            margin: 0 0 30px;
            color: #4B3621;
            font-family: 'Cormorant Garamond', serif;
            font-size: 52px;
            line-height: 1;
        }


        /* =====================================================
           EMPTY WISHLIST
        ===================================================== */

        .empty-wishlist {
            padding: 70px 30px;
            text-align: center;
            background: #FFFFFF;
            border-radius: 22px;
            box-shadow: 0 12px 35px rgba(75, 54, 33, .08);
        }

        .empty-wishlist-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 85px;
            height: 85px;
            margin: 0 auto 20px;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 50%;
        }

        .empty-wishlist-icon i {
            font-size: 35px;
        }

        .empty-wishlist h2 {
            margin: 0 0 8px;
            color: #4B3621;
            font-size: 23px;
        }

        .empty-wishlist p {
            margin: 0 auto 25px;
            max-width: 500px;
            color: #8A7A6D;
            font-size: 14px;
            line-height: 1.7;
        }


        /* =====================================================
           JELAJAHI BUKU BUTTON
           MENGIKUTI CART.PHP
        ===================================================== */

        .browse-books-btn {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            padding: 12px 20px;
            background: #6F4E37;
            color: #FFFFFF !important;
            border-radius: 10px;
            text-decoration: none !important;
            font-size: 14px;
            font-weight: 600;
            transition: .3s;
        }

        .browse-books-btn:hover {
            background: #8B5E3C;
            color: #FFFFFF !important;
            transform: translateY(-2px);
        }


        /* =====================================================
           WISHLIST GRID
        ===================================================== */

        .wishlist-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 22px;
        }


        /* =====================================================
           WISHLIST CARD
        ===================================================== */

        .wishlist-card {
            display: flex;
            flex-direction: column;
            min-width: 0;
            padding: 18px;
            background: #FFFFFF;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(75, 54, 33, .06);
            transition: .3s;
        }

        .wishlist-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 30px rgba(75, 54, 33, .10);
        }


        /* =====================================================
           COVER
        ===================================================== */

        .wishlist-cover {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 245px;
            margin-bottom: 16px;
            overflow: hidden;
            background: #F8F3EC;
            border-radius: 10px;
        }

        .wishlist-cover img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .wishlist-cover-placeholder {
            color: #6F4E37;
            font-size: 35px;
        }


        /* =====================================================
           BOOK INFORMATION
        ===================================================== */

        .wishlist-info {
            display: flex;
            flex-direction: column;
            flex: 1;
        }

        .wishlist-book-title {
            display: block;
            margin-bottom: 7px;
            color: #4B3621;
            font-size: 17px;
            font-weight: 600;
            line-height: 1.4;
            text-decoration: none;
        }

        .wishlist-book-title:hover {
            color: #8B5E3C;
        }

        .wishlist-author {
            margin: 0 0 10px;
            color: #8A7A6D;
            font-size: 12px;
        }

        .wishlist-price {
            margin-bottom: 12px;
            color: #8B5E3C;
            font-size: 15px;
            font-weight: 600;
        }

        .wishlist-stock {
            margin-bottom: 15px;
            color: #8A7A6D;
            font-size: 12px;
        }


        /* =====================================================
           ACTION BUTTONS
        ===================================================== */

        .wishlist-actions {
            display: flex;
            gap: 8px;
            margin-top: auto;
        }

        .wishlist-detail,
        .wishlist-remove {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            flex: 1;
            min-width: 0;
            padding: 10px 8px;
            border: none;
            border-radius: 9px;
            font-family: 'Poppins', sans-serif;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: .3s;
        }

        .wishlist-detail {
            background: #6F4E37;
            color: #FFFFFF !important;
        }

        .wishlist-detail:hover {
            background: #8B5E3C;
            color: #FFFFFF !important;
        }

        .wishlist-remove {
            background: #F3E8D8;
            color: #8B5E3C;
        }

        .wishlist-remove:hover {
            background: #FBEAEA;
            color: #B04A3A;
        }

        .wishlist-remove:disabled {
            opacity: .5;
            cursor: not-allowed;
        }


        /* =====================================================
           RESPONSIVE
        ===================================================== */

        @media (max-width: 1000px) {

            .wishlist-grid {
                grid-template-columns: repeat(3, minmax(0, 1fr));
            }

        }


        @media (max-width: 750px) {

            .wishlist-grid {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 15px;
            }

            .wishlist-cover {
                height: 210px;
            }

        }


        @media (max-width: 650px) {

            .wishlist-page {
                padding: 30px 18px 60px;
            }

            .wishlist-title {
                font-size: 43px;
            }

            .wishlist-card {
                padding: 13px;
            }

            .wishlist-cover {
                height: 190px;
            }

            .wishlist-book-title {
                font-size: 15px;
            }

            .wishlist-actions {
                flex-direction: column;
            }

        }


        @media (max-width: 450px) {

            .wishlist-title {
                font-size: 37px;
            }

            .wishlist-grid {
                gap: 12px;
            }

            .wishlist-cover {
                height: 165px;
            }

            .wishlist-detail,
            .wishlist-remove {
                font-size: 11px;
            }

        }

    </style>

</head>


<body>


<!-- =========================================================
     NAVBAR
========================================================= -->

<?php include '../includes/navbar_user.php'; ?>


<!-- =========================================================
     WISHLIST PAGE
========================================================= -->

<main class="wishlist-page">


    <!-- BACK BUTTON -->

    <a
        href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8'); ?>"
        class="global-back-button"
    >

        <i class="fa-solid fa-arrow-left"></i>

        Kembali

    </a>


    <!-- TITLE -->

    <h1 class="wishlist-title">
        Wishlist
    </h1>


    <?php if (empty($books)): ?>


        <!-- =================================================
             EMPTY WISHLIST
        ================================================== -->

        <section class="empty-wishlist">

            <div class="empty-wishlist-icon">

                <i class="fa-solid fa-heart"></i>

            </div>


            <h2>
                Wishlist masih kosong
            </h2>


            <p>
                Belum ada buku yang ditambahkan ke wishlist.
                Yuk, temukan buku favoritmu dan simpan di sini.
            </p>


            <a
                href="books.php?back=<?= urlencode($current_url); ?>"
                class="browse-books-btn"
            >

                <i class="fa-solid fa-book"></i>

                Jelajahi Buku

            </a>

        </section>


    <?php else: ?>


        <!-- =================================================
             WISHLIST CONTENT
        ================================================== -->

        <div class="wishlist-grid">


            <?php foreach ($books as $book): ?>


                <article
                    class="wishlist-card"
                    data-book-id="<?= (int) $book['id']; ?>"
                >


                    <!-- COVER -->

                    <a
                        href="detail.php?id=<?= (int) $book['id']; ?>&back=<?= urlencode($current_url); ?>"
                        class="wishlist-cover"
                    >

                        <?php if (!empty($book['cover'])): ?>

                            <img
                                src="../assets/img/<?= htmlspecialchars(
                                    $book['cover'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                alt="<?= htmlspecialchars(
                                    $book['title'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                            >

                        <?php else: ?>

                            <div class="wishlist-cover-placeholder">

                                <i class="fa-solid fa-book"></i>

                            </div>

                        <?php endif; ?>

                    </a>


                    <!-- BOOK INFORMATION -->

                    <div class="wishlist-info">


                        <a
                            href="detail.php?id=<?= (int) $book['id']; ?>&back=<?= urlencode($current_url); ?>"
                            class="wishlist-book-title"
                        >

                            <?= htmlspecialchars(
                                $book['title'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </a>


                        <p class="wishlist-author">

                            <?= htmlspecialchars(
                                $book['author'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </p>


                        <div class="wishlist-price">

                            Rp<?= number_format(
                                (float) $book['price'],
                                0,
                                ',',
                                '.'
                            ); ?>

                        </div>


                        <div class="wishlist-stock">

                            Stok tersedia: <?= (int) $book['stock']; ?>

                        </div>


                        <!-- ACTION BUTTONS -->

                        <div class="wishlist-actions">


                            <a
                                href="detail.php?id=<?= (int) $book['id']; ?>&back=<?= urlencode($current_url); ?>"
                                class="wishlist-detail"
                            >

                                <i class="fa-solid fa-eye"></i>

                                Lihat Buku

                            </a>


                            <button
                                class="wishlist-remove"
                                type="button"
                            >

                                <i class="fa-solid fa-trash"></i>

                                Hapus

                            </button>


                        </div>


                    </div>


                </article>


            <?php endforeach; ?>


        </div>


    <?php endif; ?>


</main>


<!-- =========================================================
     FOOTER
========================================================= -->

<?php include '../includes/footer_user.php'; ?>


<!-- =========================================================
     JAVASCRIPT HAPUS WISHLIST
========================================================= -->

<script>

document.querySelectorAll('.wishlist-remove').forEach(button => {

    button.addEventListener('click', async () => {

        const card = button.closest('.wishlist-card');

        const body = new URLSearchParams({
            book_id: card.dataset.bookId
        });

        button.disabled = true;

        try {

            const response = await fetch('wishlist_toggle.php', {

                method: 'POST',

                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },

                body: body

            });

            const data = await response.json();

            if (!response.ok || !data.success) {

                throw new Error(
                    data.message || 'Gagal menghapus wishlist.'
                );

            }

            card.remove();

            // Jika wishlist kosong, muat ulang halaman

            if (!document.querySelector('.wishlist-card')) {

                location.reload();

            }

        } catch (error) {

            alert(error.message);

            button.disabled = false;

        }

    });

});

</script>


<!-- JAVASCRIPT -->

<script src="../assets/js/back-button.js"></script>

<script src="../assets/js/enhancements.js" defer></script>


</body>
</html>