<?php
require_once '../config/database.php';

// Pisahkan sesi admin dan user agar login keduanya bisa aktif bersamaan.
$login_role = 'user';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role_lookup_username = trim($_POST['username'] ?? '');
    if ($role_lookup_username !== '') {
        $role_lookup = mysqli_prepare($conn, 'SELECT role FROM users WHERE username = ? LIMIT 1');
        if ($role_lookup) {
            mysqli_stmt_bind_param($role_lookup, 's', $role_lookup_username);
            mysqli_stmt_execute($role_lookup);
            $role_result = mysqli_stmt_get_result($role_lookup);
            $role_row = $role_result ? mysqli_fetch_assoc($role_result) : null;
            if ($role_row && strtolower(trim($role_row['role'] ?? 'user')) === 'admin') {
                $login_role = 'admin';
            }
            mysqli_stmt_close($role_lookup);
        }
    }
}
session_name($login_role === 'admin' ? 'LINGLUNG_ADMIN' : 'LINGLUNG_USER');
session_start();

$message = '';

/* =========================================
   HALAMAN KEMBALI
========================================= */

$default_back = '../index.php';
$back = $_GET['back'] ?? $default_back;

if ($back === 'index.php') {
    $back = '../index.php';
}

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'dashboard.php', 'books.php', 'about.php',
    'contact.php', 'messages.php', 'cart.php',
    'checkout.php', 'orders.php', 'order_detail.php',
    'wishlist.php', 'detail.php', 'profile.php',
    'login.php', 'register.php'
];

$is_safe_back = $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}

/* =========================================
   PROSES LOGIN USER DAN ADMIN
========================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $message = 'Username dan password wajib diisi.';

    } elseif (strlen($username) > 100) {
        $message = 'Username tidak valid.';

    } else {

        $stmt = mysqli_prepare(
            $conn,
            "SELECT id, fullname, username, password, role
             FROM users
             WHERE username = ?
             LIMIT 1"
        );

        if (!$stmt) {
            $message = 'Terjadi kesalahan sistem. Silakan coba lagi.';

        } else {

            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);

            $result = mysqli_stmt_get_result($stmt);
            $user = $result ? mysqli_fetch_assoc($result) : null;

            if ($user && password_verify($password, $user['password'])) {

                $role = strtolower(trim($user['role'] ?? 'user'));

                if (!in_array($role, ['admin', 'user'], true)) {

                    $message = 'Role akun tidak valid.';

                } else {

                    session_regenerate_id(true);

                    $_SESSION['user_id'] = (int) $user['id'];
                    $_SESSION['fullname'] = $user['fullname'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $role;

                    if ($role === 'admin') {
                        header('Location: ../admin/dashboard.php');
                    } else {
                        header('Location: dashboard.php');
                    }

                    exit;
                }

            } else {
                $message = 'Username atau password salah.';
            }

            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Linglung Books</title>

    <link rel="stylesheet" href="../assets/css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <link rel="stylesheet" href="../assets/css/enhancements.css">

    <style>
        .login-box {
            width: 420px;
            max-width: calc(100% - 40px);
            background: #fff;
            margin: 70px auto;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, .08);
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .login-box h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #4B3621;
        }

        .input-group {
            margin-bottom: 18px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #4B3621;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 10px;
            outline: none;
            font-size: 15px;
            font-family: inherit;
            box-sizing: border-box;
        }

        .input-group input:focus {
            border-color: #8B5E3C;
        }

        .btn-login {
            width: 100%;
            padding: 14px;
            background: #6F4E37;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-size: 16px;
            font-family: inherit;
            transition: .2s;
        }

        .btn-login:hover {
            background: #8B5E3C;
        }

        .message {
            text-align: center;
            color: #8B5E3C;
            background: #F3E8D8;
            padding: 10px 14px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .register-link {
            text-align: center;
            margin-top: 20px;
            color: #555;
        }

        .register-link a {
            color: #6F4E37;
            text-decoration: none;
            font-weight: 600;
        }

        .register-link a:hover {
            color: #8B5E3C;
            text-decoration: underline;
        }

        /* TOMBOL KEMBALI BERUPA TULISAN */

        .login-back {
            display: block;
            width: fit-content;
            margin: 18px auto 0;
            padding: 0;
            background: none;
            border: none;
            color: #6F4E37;
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: .2s;
        }

        .login-back:hover {
            color: #8B5E3C;
            text-decoration: underline;
        }

        @media (max-width: 500px) {
            .login-box {
                margin: 40px auto;
                padding: 30px 25px;
            }
        }
    </style>

    <link rel="stylesheet" href="../assets/css/back-button.css">
</head>

<body>

    <div class="login-box">

        <h2>Login</h2>

        <?php if ($message !== ''): ?>
            <div class="message">
                <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form method="POST" autocomplete="on">

            <div class="input-group">
                <label for="username">Username</label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    maxlength="100"
                    autocomplete="username"
                    required
                >
            </div>

            <div class="input-group">
                <label for="password">Password</label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    autocomplete="current-password"
                    required
                >
            </div>

            <button type="submit" class="btn-login">
                Login
            </button>

        </form>

        <div class="register-link">
            Belum punya akun?

            <a href="register.php?back=<?= urlencode($back) ?>">
                Daftar
            </a>
        </div>

        <a
            href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8') ?>"
            class="global-back-button"
        >
            Kembali
        </a>

    </div>

    <script src="../assets/js/enhancements.js" defer></script>

</body>
</html>