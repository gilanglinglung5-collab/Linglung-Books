<?php

// Gunakan zona waktu Indonesia agar tanggal pada ID transaksi sesuai WIB.
date_default_timezone_set('Asia/Jakarta');

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

include '../config/database.php';


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = (int) $_SESSION['user_id'];
$accountQuery = mysqli_prepare($conn, "SELECT fullname, phone, address FROM users WHERE id = ? AND role = 'user' LIMIT 1");
mysqli_stmt_bind_param($accountQuery, 'i', $user_id);
mysqli_stmt_execute($accountQuery);
$accountResult = mysqli_stmt_get_result($accountQuery);
$account = $accountResult ? mysqli_fetch_assoc($accountResult) : null;
mysqli_stmt_close($accountQuery);
if (!$account) { header('Location: login.php'); exit; }

/* =========================================================
   SIAPKAN TABEL NOMOR URUT TRANSAKSI
   Tabel ini menyimpan urutan terakhir untuk setiap tanggal.
   Dibuat di luar transaksi checkout karena CREATE TABLE dapat
   menyebabkan MySQL melakukan implicit commit.
========================================================= */
$counter_table_ready = mysqli_query($conn, "
    CREATE TABLE IF NOT EXISTS order_daily_sequences (
        transaction_date DATE NOT NULL PRIMARY KEY,
        last_number INT UNSIGNED NOT NULL DEFAULT 0
    ) ENGINE=InnoDB
");


/* =========================
   DATA REKENING
========================= */

$bank_name = 'BCA';
$bank_account = '1234567890';
$bank_holder = 'LinglungBooks';

// Isi nomor tujuan dan nama penerima sebelum website digunakan.
$dana_number = '0812-0000-0001';
$dana_holder = 'LinglungBooks';
$gopay_number = '0812-0000-0002';
$gopay_holder = 'LinglungBooks';
$qris_image = '../assets/img/qris.jpeg';


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'cart.php';
$back = $_GET['back'] ?? $default_back;


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php' ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   URL HALAMAN CHECKOUT
========================= */

$current_url = 'checkout.php';


/* =========================
   URL KEMBALI KE CART
========================= */

$cart_url =
    'cart.php?back=' .
    urlencode($current_url);


/* =========================
   URL KE BUKU
========================= */

$books_url =
    'books.php?back=' .
    urlencode($current_url);


/* =========================
   SUCCESS ORDER
========================= */

$success = isset($_GET['success'])
    && $_GET['success'] == '1';

$order_id = isset($_GET['order_id'])
    && is_numeric($_GET['order_id'])
    ? (int) $_GET['order_id']
    : 0;


/* =========================
   DATA STRUK
========================= */

$receipt_order = null;
$receipt_items = [];
$receipt_total = 0;


/* =========================
   AMBIL DATA ORDER UNTUK STRUK
========================= */

if ($success && $order_id > 0) {

    $safe_order_id = (int) $order_id;

    $receipt_order_query = mysqli_query($conn, "
        SELECT
            id,
            transaction_code,
            user_id,
            recipient_name,
            phone,
            address,
            total_price,
            status,
            payment_method,
            payment_proof,
            va_bank,
            va_number,
            payment_reference,
            payment_verification,
            created_at
        FROM orders
        WHERE id = '$safe_order_id'
        AND user_id = '$user_id'
        LIMIT 1
    ");

    if ($receipt_order_query) {

        $receipt_order =
            mysqli_fetch_assoc(
                $receipt_order_query
            );
    }


    if ($receipt_order) {

        $receipt_items_query = mysqli_query($conn, "
            SELECT
                od.id,
                od.order_id,
                od.book_id,
                od.quantity,
                od.price,
                b.title,
                b.cover
            FROM order_details od
            INNER JOIN books b
                ON od.book_id = b.id
            WHERE od.order_id = '$safe_order_id'
            ORDER BY od.id ASC
        ");


        if ($receipt_items_query) {

            while (
                $row =
                mysqli_fetch_assoc(
                    $receipt_items_query
                )
            ) {

                $receipt_items[] = $row;

                $receipt_total +=
                    (float) $row['price'] *
                    (int) $row['quantity'];
            }
        }
    }
}


/* =========================
   PROSES CHECKOUT
========================= */

$error = '';

$uploaded_file_path = '';


if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['place_order'])
) {

    /* =========================
       DATA FORM
    ========================= */

    $name = trim($account['fullname'] ?? '');
    $phone = trim($account['phone'] ?? '');
    $address = trim($account['address'] ?? '');

    $payment_method = trim(
        $_POST['payment_method'] ?? ''
    );


    /* =========================
       VALIDASI DATA
    ========================= */

    if (
        $name === '' ||
        $phone === '' ||
        $address === '' ||
        $payment_method === ''
    ) {

        $error =
            'Semua data checkout wajib diisi.';

    } elseif (
        !in_array(
            $payment_method,
            ['VA_BCA', 'VA_BRI', 'VA_BNI', 'VA_MANDIRI'],
            true
        )
    ) {

        $error =
            'Metode pembayaran tidak valid.';

    } else {

        /* =========================
           VALIDASI BUKTI TRANSFER
        ========================= */

        if (true) {

            if (
                !isset($_FILES['payment_proof']) ||
                $_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK
            ) {

                $error =
                    'Bukti pembayaran wajib diupload untuk metode pembayaran yang dipilih.';

            } else {

                $file = $_FILES['payment_proof'];

                $max_size = 5 * 1024 * 1024;

                $allowed_extensions = [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp'
                ];

                $extension = strtolower(
                    pathinfo(
                        $file['name'],
                        PATHINFO_EXTENSION
                    )
                );


                if ($file['size'] > $max_size) {

                    $error =
                        'Ukuran bukti pembayaran maksimal 5 MB.';

                } elseif (
                    !in_array(
                        $extension,
                        $allowed_extensions,
                        true
                    )
                ) {

                    $error =
                        'Format bukti pembayaran harus JPG, JPEG, PNG, atau WEBP.';
                } else {
                    $mime = '';
                    if (function_exists('finfo_open')) {
                        $finfo = finfo_open(FILEINFO_MIME_TYPE);
                        $mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : '';
                        if ($finfo) finfo_close($finfo);
                    }
                    $allowed_mimes = ['image/jpeg', 'image/png', 'image/webp'];
                    if ($mime !== '' && !in_array($mime, $allowed_mimes, true)) {
                        $error = 'File bukti harus benar-benar berupa gambar JPG, PNG, atau WEBP.';
                    }
                }
            }
        }


        /* =========================
           AMBIL CART
        ========================= */

        if ($error === '') {

            $cart_query = mysqli_query($conn, "
                SELECT
                    c.id AS cart_id,
                    c.book_id,
                    c.quantity,
                    b.title,
                    b.price,
                    b.stock
                FROM cart c
                INNER JOIN books b
                    ON c.book_id = b.id
                WHERE c.user_id = '$user_id'
            ");

            $cart_items = [];

            $total = 0;


            if ($cart_query) {

                while (
                    $row =
                    mysqli_fetch_assoc($cart_query)
                ) {

                    $cart_items[] = $row;

                    $total +=
                        (float) $row['price'] *
                        (int) $row['quantity'];
                }
            }


            /* =========================
               CART KOSONG
            ========================= */

            if (empty($cart_items)) {

                $error =
                    'Keranjang kamu masih kosong.';

            } else {

                /* =========================
                   CEK STOK
                ========================= */

                foreach ($cart_items as $item) {

                    if (
                        (int) $item['quantity'] >
                        (int) $item['stock']
                    ) {

                        $error =
                            'Stok buku "' .
                            $item['title'] .
                            '" tidak mencukupi.';

                        break;
                    }
                }


                /* =========================
                   SIMPAN PESANAN
                ========================= */

                if ($error === '') {

                    mysqli_begin_transaction($conn);

                    $uploaded_file_path = '';

                    try {

                        /* =========================
                           UPLOAD BUKTI PEMBAYARAN
                        ========================= */

                        $payment_proof = null;

                        if (true) {

                            $upload_dir =
                                '../assets/payment_proofs/';


                            if (!is_dir($upload_dir)) {

                                if (
                                    !mkdir(
                                        $upload_dir,
                                        0755,
                                        true
                                    )
                                ) {

                                    throw new Exception(
                                        'Folder penyimpanan bukti pembayaran tidak dapat dibuat.'
                                    );
                                }
                            }


                            $extension = strtolower(
                                pathinfo(
                                    $_FILES['payment_proof']['name'],
                                    PATHINFO_EXTENSION
                                )
                            );


                            $random_name =
                                bin2hex(
                                    random_bytes(8)
                                );


                            $file_name =
                                'payment_' .
                                $user_id .
                                '_' .
                                time() .
                                '_' .
                                $random_name .
                                '.' .
                                $extension;


                            $uploaded_file_path =
                                $upload_dir .
                                $file_name;


                            if (
                                !move_uploaded_file(
                                    $_FILES['payment_proof']['tmp_name'],
                                    $uploaded_file_path
                                )
                            ) {

                                throw new Exception(
                                    'Gagal mengupload bukti pembayaran.'
                                );
                            }


                            $payment_proof =
                                $file_name;
                        }


                        /* =========================
                           DATA AMAN
                        ========================= */

                        $safe_name =
                            mysqli_real_escape_string(
                                $conn,
                                $name
                            );

                        $safe_phone =
                            mysqli_real_escape_string(
                                $conn,
                                $phone
                            );

                        $safe_address =
                            mysqli_real_escape_string(
                                $conn,
                                $address
                            );

                        $safe_payment_method =
                            mysqli_real_escape_string(
                                $conn,
                                $payment_method
                            );


                        $va_bank_value = null;
                        $va_number = null;
                        $payment_reference = null;
                        if (str_starts_with($payment_method, 'VA_')) {
                            $va_bank_value = substr($payment_method, 3);
                            $prefixes = ['BCA' => '8808', 'BRI' => '8877', 'BNI' => '8899', 'MANDIRI' => '8870'];
                            $va_number = $prefixes[$va_bank_value] .
                                str_pad((string) random_int(0, 999999999999), 12, '0', STR_PAD_LEFT);
                            $payment_reference = 'SIM-' . strtoupper(bin2hex(random_bytes(5)));
                        }
                        $safe_va_bank = $va_bank_value !== null ? "'" . mysqli_real_escape_string($conn, $va_bank_value) . "'" : "NULL";
                        $safe_va_number = $va_number !== null ? "'" . mysqli_real_escape_string($conn, $va_number) . "'" : "NULL";
                        $safe_payment_reference = $payment_reference !== null ? "'" . mysqli_real_escape_string($conn, $payment_reference) . "'" : "NULL";

                        $safe_payment_proof =
                            $payment_proof !== null
                                ? "'" .
                                    mysqli_real_escape_string(
                                        $conn,
                                        $payment_proof
                                    ) .
                                    "'"
                                : "NULL";


                        /* =====================================================
                           BUAT ID TRANSAKSI HARIAN
                           Format: DDMMYY + nomor urut 3 digit (contoh 110409001).
                           Tabel counter menjaga nomor tetap unik meskipun ada
                           dua checkout yang berlangsung hampir bersamaan.
                        ===================================================== */

                        $transaction_date = date('Y-m-d');
                        $date_prefix = date('dmy');

                        // Nomor pertama pada tanggal baru dimulai dari 001.
                        if (!$counter_table_ready) {
                            throw new Exception('Tabel nomor transaksi belum siap. Jalankan file migrasi database terlebih dahulu.');
                        }

                        // Tambah nomor secara atomik agar tidak bentrok antar-checkout.
                        $counter_stmt = mysqli_prepare($conn, "
                            INSERT INTO order_daily_sequences (transaction_date, last_number)
                            VALUES (?, 1)
                            ON DUPLICATE KEY UPDATE last_number = LAST_INSERT_ID(last_number + 1)
                        ");
                        if (!$counter_stmt) {
                            throw new Exception('Gagal menyiapkan nomor transaksi harian.');
                        }
                        mysqli_stmt_bind_param($counter_stmt, 's', $transaction_date);
                        if (!mysqli_stmt_execute($counter_stmt)) {
                            mysqli_stmt_close($counter_stmt);
                            throw new Exception('Gagal mengambil nomor transaksi harian.');
                        }
                        mysqli_stmt_close($counter_stmt);

                        $counter_result = mysqli_query($conn, "
                            SELECT last_number
                            FROM order_daily_sequences
                            WHERE transaction_date = '$transaction_date'
                            LIMIT 1
                        ");
                        $counter_data = $counter_result ? mysqli_fetch_assoc($counter_result) : null;
                        $daily_number = (int) ($counter_data['last_number'] ?? 0);

                        if ($daily_number < 1 || $daily_number > 999) {
                            throw new Exception('Nomor transaksi hari ini sudah mencapai batas 999.');
                        }

                        // Contoh hasil: tanggal 11-04-2009 dan pembeli pertama = 110409001.
                        $transaction_code = $date_prefix . str_pad((string) $daily_number, 3, '0', STR_PAD_LEFT);

                        /* =========================
                           INSERT ORDER
                           Simpan ID transaksi yang dapat dibaca pelanggan.
                        ========================= */

                        $safe_transaction_code = mysqli_real_escape_string($conn, $transaction_code);

                        $insert_order = mysqli_query($conn, "
                            INSERT INTO orders (
                                transaction_code,
                                user_id,
                                recipient_name,
                                phone,
                                address,
                                payment_method,
                                total_price,
                                status,
                                payment_proof,
                                va_bank,
                                va_number,
                                payment_reference,
                                payment_verification
                            )
                            VALUES (
                                '$safe_transaction_code',
                                '$user_id',
                                '$safe_name',
                                '$safe_phone',
                                '$safe_address',
                                '$safe_payment_method',
                                '$total',
                                'Processing',
                                $safe_payment_proof,
                                $safe_va_bank,
                                $safe_va_number,
                                $safe_payment_reference,
                                'pending'
                            )
                        ");


                        if (!$insert_order) {

                            throw new Exception(
                                'Gagal membuat pesanan: ' .
                                mysqli_error($conn)
                            );
                        }


                        // ID numerik internal tetap dipakai untuk relasi tabel dan URL.
                        $new_order_id = mysqli_insert_id($conn);


                        /* =========================
                           INSERT ORDER DETAILS
                        ========================= */

                        foreach ($cart_items as $item) {

                            $book_id =
                                (int) $item['book_id'];

                            $quantity =
                                (int) $item['quantity'];

                            $price =
                                (float) $item['price'];

                            $cost_query = mysqli_query($conn, "SELECT cost_price FROM books WHERE id = '$book_id' LIMIT 1");
                            $cost_row = $cost_query ? mysqli_fetch_assoc($cost_query) : null;
                            $cost_price_sql = ($cost_row && $cost_row['cost_price'] !== null && $cost_row['cost_price'] !== '') ? (string)(float)$cost_row['cost_price'] : 'NULL';


                            $insert_item = mysqli_query(
                                $conn,
                                "
                                INSERT INTO order_details (
                                    order_id,
                                    book_id,
                                    quantity,
                                    price,
                                    cost_price
                                )
                                VALUES (
                                    '$new_order_id',
                                    '$book_id',
                                    '$quantity',
                                    '$price',
                                    $cost_price_sql
                                )
                                "
                            );


                            if (!$insert_item) {

                                throw new Exception(
                                    'Gagal menyimpan detail pesanan: ' .
                                    mysqli_error($conn)
                                );
                            }


                            /* =========================
                               KURANGI STOK
                            ========================= */

                            $update_stock = mysqli_query(
                                $conn,
                                "
                                UPDATE books
                                SET stock = stock - $quantity
                                WHERE id = '$book_id'
                                AND stock >= $quantity
                                "
                            );


                            if (
                                !$update_stock ||
                                mysqli_affected_rows($conn) === 0
                            ) {

                                throw new Exception(
                                    'Stok buku tidak mencukupi.'
                                );
                            }
                        }


                        /* =========================
                           KOSONGKAN CART
                        ========================= */

                        $clear_cart = mysqli_query(
                            $conn,
                            "
                            DELETE FROM cart
                            WHERE user_id = '$user_id'
                            "
                        );


                        if (!$clear_cart) {

                            throw new Exception(
                                'Gagal mengosongkan keranjang.'
                            );
                        }


                        /* =========================
                           COMMIT
                        ========================= */

                        mysqli_commit($conn);


                        /* =========================
                           REDIRECT KE STRUK
                        ========================= */

                        header(
                            "Location: checkout.php?success=1" .
                            "&order_id=" .
                            $new_order_id .
                            "&back=" .
                            urlencode($back)
                        );

                        exit;


                    } catch (Exception $e) {

                        mysqli_rollback($conn);


                        /* =========================
                           HAPUS FILE JIKA GAGAL
                        ========================= */

                        if (
                            $uploaded_file_path !== '' &&
                            file_exists($uploaded_file_path)
                        ) {

                            unlink(
                                $uploaded_file_path
                            );
                        }


                        $error =
                            $e->getMessage();
                    }
                }
            }
        }
    }
}


/* =========================
   AMBIL CART UNTUK TAMPILAN
========================= */

$cart_query = mysqli_query($conn, "
    SELECT
        c.id AS cart_id,
        c.quantity,
        b.id AS book_id,
        b.title,
        b.price,
        b.cover,
        b.stock
    FROM cart c
    INNER JOIN books b
        ON c.book_id = b.id
    WHERE c.user_id = '$user_id'
    ORDER BY c.id DESC
");


$cart_items = [];

$total = 0;


if ($cart_query) {

    while (
        $row =
        mysqli_fetch_assoc($cart_query)
    ) {

        $cart_items[] = $row;

        $total +=
            (float) $row['price'] *
            (int) $row['quantity'];
    }
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Checkout | LinglungBooks
    </title>


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css"
    >


    <!-- CSS -->

    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >


    <style>

        /* =========================
           CHECKOUT PAGE
        ========================= */

        .checkout-page {

            max-width: 1200px;

            margin: 0 auto;

            padding: 45px 30px 80px;

        }


        /* =========================
           BACK
        ========================= */

        .checkout-back {

            display: inline-flex;

            align-items: center;

            gap: 8px;

            margin-bottom: 25px;

            padding: 10px 16px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 10px;

            text-decoration: none;

            font-size: 14px;

            font-weight: 500;

            transition: .3s;

        }


        .checkout-back:hover {

            background: #E8D6BE;

            transform: translateX(-3px);

        }


        /* =========================
           TITLE
        ========================= */

        .checkout-title {

            margin: 0 0 30px;

            color: #4B3621;

            font-family: 'Cormorant Garamond', serif;

            font-size: 52px;

            line-height: 1;

        }


        /* =========================
           ERROR
        ========================= */

        .checkout-error {

            display: flex;

            align-items: center;

            gap: 10px;

            margin-bottom: 20px;

            padding: 14px 18px;

            background: #FBEAEA;

            color: #B04A3A;

            border: 1px solid #F1C8C2;

            border-radius: 11px;

            font-size: 13px;

        }


        /* =========================
           STRUK
        ========================= */

        .receipt-wrapper {

            max-width: 700px;

            margin: 0 auto;

        }


        .receipt {

            position: relative;

            background: #FFFFFF;

            padding: 35px 38px;

            border-radius: 4px;

            box-shadow:
                0 15px 40px rgba(75, 54, 33, .10);

        }


        .receipt::before {

            content: "";

            position: absolute;

            top: -8px;

            left: 0;

            width: 100%;

            height: 10px;

            background:
                linear-gradient(
                    135deg,
                    transparent 6px,
                    #FFFFFF 6px
                ) 0 0 / 12px 10px repeat-x;

        }


        .receipt-header {

            text-align: center;

            padding-bottom: 25px;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-brand {

            margin: 0;

            color: #4B3621;

            font-family:
                'Cormorant Garamond',
                serif;

            font-size: 38px;

            font-weight: 700;

        }


        .receipt-subtitle {

            margin: 3px 0 0;

            color: #8A7A6D;

            font-size: 12px;

            letter-spacing: 2px;

            text-transform: uppercase;

        }


        .receipt-thankyou {

            margin-top: 15px;

            color: #6F4E37;

            font-size: 13px;

        }


        /* =========================
           ORDER META
        ========================= */

        .receipt-meta {

            padding: 20px 0;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-meta-row {

            display: flex;

            justify-content: space-between;

            gap: 20px;

            margin-bottom: 8px;

            color: #6D625B;

            font-size: 12px;

        }


        .receipt-meta-row:last-child {

            margin-bottom: 0;

        }


        .receipt-meta-row strong {

            color: #4B3621;

            text-align: right;

            font-weight: 600;

        }


        /* =========================
           CUSTOMER
        ========================= */

        .receipt-customer {

            padding: 20px 0;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-section-title {

            margin: 0 0 13px;

            color: #4B3621;

            font-size: 13px;

            font-weight: 700;

            text-transform: uppercase;

            letter-spacing: .5px;

        }


        .receipt-customer-row {

            display: flex;

            gap: 15px;

            margin-bottom: 7px;

            color: #6D625B;

            font-size: 12px;

            line-height: 1.6;

        }


        .receipt-customer-row:last-child {

            margin-bottom: 0;

        }


        .receipt-customer-label {

            flex: 0 0 90px;

            color: #8A7A6D;

        }


        .receipt-customer-value {

            flex: 1;

            color: #4B3621;

            word-break: break-word;

        }


        /* =========================
           ITEMS
        ========================= */

        .receipt-items {

            padding: 20px 0;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-item {

            display: flex;

            justify-content: space-between;

            gap: 20px;

            padding: 10px 0;

        }


        .receipt-item:first-child {

            padding-top: 0;

        }


        .receipt-item:last-child {

            padding-bottom: 0;

        }


        .receipt-item-info {

            flex: 1;

            min-width: 0;

        }


        .receipt-item-name {

            color: #4B3621;

            font-size: 13px;

            font-weight: 600;

            line-height: 1.5;

        }


        .receipt-item-qty {

            margin-top: 3px;

            color: #8A7A6D;

            font-size: 11px;

        }


        .receipt-item-price {

            flex-shrink: 0;

            color: #6F4E37;

            font-size: 13px;

            font-weight: 600;

            text-align: right;

        }


        /* =========================
           TOTAL
        ========================= */

        .receipt-total {

            display: flex;

            justify-content: space-between;

            align-items: center;

            gap: 20px;

            padding: 20px 0;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-total-label {

            color: #4B3621;

            font-size: 16px;

            font-weight: 700;

        }


        .receipt-total-value {

            color: #6F4E37;

            font-size: 21px;

            font-weight: 700;

        }


        /* =========================
           PAYMENT
        ========================= */

        .receipt-payment {

            padding: 20px 0;

            border-bottom: 1px dashed #CFC2B5;

        }


        .receipt-payment-row {

            display: flex;

            justify-content: space-between;

            gap: 20px;

            margin-bottom: 8px;

            color: #6D625B;

            font-size: 12px;

        }


        .receipt-payment-row:last-child {

            margin-bottom: 0;

        }


        .receipt-payment-row strong {

            color: #4B3621;

            text-align: right;

        }


        .status-pending {

            color: #A66B18 !important;

        }


        .status-paid {

            color: #567A32 !important;

        }


        /* =========================
           TRANSFER INFO
        ========================= */

        .receipt-transfer {

            margin-top: 15px;

            padding: 14px;

            background: #F8F0E7;

            border-radius: 10px;

        }


        .receipt-transfer-title {

            margin-bottom: 8px;

            color: #4B3621;

            font-size: 12px;

            font-weight: 700;

        }


        .receipt-transfer p {

            margin: 3px 0;

            color: #6D625B;

            font-size: 11px;

            line-height: 1.6;

        }


        .receipt-transfer strong {

            color: #4B3621;

        }


        /* =========================
           FOOTER
        ========================= */

        .receipt-footer {

            padding-top: 22px;

            text-align: center;

        }


        .receipt-footer p {

            margin: 4px 0;

            color: #8A7A6D;

            font-size: 11px;

            line-height: 1.6;

        }


        .receipt-footer strong {

            color: #6F4E37;

        }


        /* =========================
           RECEIPT ACTIONS
        ========================= */

        .receipt-actions {

            display: flex;

            justify-content: center;

            gap: 12px;

            flex-wrap: wrap;

            margin-top: 25px;

        }


        .receipt-btn {

            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            padding: 12px 20px;

            border-radius: 10px;

            text-decoration: none;

            font-family: Poppins, sans-serif;

            font-size: 13px;

            font-weight: 600;

            transition: .3s;

        }


        .receipt-btn-primary {

            background: #6F4E37;

            color: #FFFFFF;

        }


        .receipt-btn-primary:hover {

            background: #8B5E3C;

            transform: translateY(-2px);

        }


        .receipt-btn-secondary {

            background: #F3E8D8;

            color: #6F4E37;

        }


        .receipt-btn-secondary:hover {

            background: #E8D6BE;

        }


        /* =========================
           CHECKOUT LAYOUT
        ========================= */

        .checkout-layout {

            display: grid;

            grid-template-columns:
                minmax(0, 1fr) 350px;

            gap: 30px;

            align-items: start;

        }


        /* =========================
           FORM CARD
        ========================= */

        .checkout-form-card {

            padding: 30px;

            background: #FFFFFF;

            border-radius: 20px;

            box-shadow:
                0 10px 30px rgba(75, 54, 33, .07);

        }


        .form-title {

            margin: 0 0 25px;

            color: #4B3621;

            font-size: 21px;

            font-weight: 600;

        }


        .form-group {

            margin-bottom: 18px;

        }


        .form-label {

            display: block;

            margin-bottom: 7px;

            color: #4B3621;

            font-size: 13px;

            font-weight: 500;

        }


        .form-control {

            width: 100%;

            padding: 12px 14px;

            border: 1px solid #E4D9CC;

            border-radius: 10px;

            background: #FFFFFF;

            color: #4B3621;

            font-family: Poppins, sans-serif;

            font-size: 13px;

            outline: none;

            box-sizing: border-box;

            transition: .2s;

        }


        .form-control:focus {

            border-color: #8B5E3C;

            box-shadow:
                0 0 0 3px rgba(139, 94, 60, .08);

        }


        textarea.form-control {

            min-height: 120px;

            resize: vertical;

        }


        /* =========================
           PAYMENT
        ========================= */

        .payment-options {

            display: flex;

            flex-direction: column;

            gap: 10px;

        }


        .payment-option {

            position: relative;

        }


        .payment-option input {

            position: absolute;

            opacity: 0;

            pointer-events: none;

        }


        .payment-label {

            display: flex;

            align-items: center;

            gap: 12px;

            padding: 14px 15px;

            border: 1px solid #E4D9CC;

            border-radius: 11px;

            color: #4B3621;

            cursor: pointer;

            transition: .2s;

        }


        .payment-label:hover {

            background: #FAF7F2;

        }


        .payment-option input:checked
        + .payment-label {

            border-color: #8B5E3C;

            background: #F8F0E7;

        }


        .payment-icon {

            display: flex;

            align-items: center;

            justify-content: center;

            width: 36px;

            height: 36px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 9px;

        }


        .payment-text {

            font-size: 13px;

            font-weight: 500;

        }


        /* =========================
           TRANSFER INFO
        ========================= */

        .transfer-info {

            display: none;

            margin-top: 15px;

            padding: 18px;

            background: #F8F0E7;

            border: 1px solid #E4D9CC;

            border-radius: 12px;

        }


        .transfer-info-title {

            margin-bottom: 12px;

            color: #4B3621;

            font-size: 14px;

            font-weight: 600;

        }


        .transfer-info-text {

            color: #6D625B;

            font-size: 12px;

            line-height: 1.8;

        }


        .bank-detail {

            margin-top: 12px;

            padding: 14px;

            background: #FFFFFF;

            border-radius: 10px;

        }


        .bank-detail-label {

            color: #8A7A6D;

            font-size: 11px;

        }


        .bank-detail-value {

            color: #4B3621;

            font-size: 14px;

            font-weight: 600;

        }


        .bank-detail-number {

            color: #6F4E37;

            font-size: 18px;

            font-weight: 700;

            letter-spacing: 1px;

        }


        .transfer-instruction {

            margin-top: 13px;

            color: #6D625B;

            font-size: 12px;

            line-height: 1.7;

        }


        .transfer-instruction ol {

            margin: 7px 0 0 18px;

            padding: 0;

        }


        .upload-proof {

            margin-top: 18px;

        }


        .upload-note {

            display: block;

            margin-top: 7px;

            color: #8A7A6D;

            font-size: 11px;

            line-height: 1.5;

        }


        /* =========================
           PLACE ORDER
        ========================= */

        .place-order-btn {

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 9px;

            width: 100%;

            margin-top: 25px;

            padding: 14px 20px;

            border: none;

            border-radius: 11px;

            background: #6F4E37;

            color: #FFFFFF;

            font-family: Poppins, sans-serif;

            font-size: 14px;

            font-weight: 600;

            cursor: pointer;

            transition: .3s;

        }


        .place-order-btn:hover {

            background: #8B5E3C;

            transform: translateY(-2px);

            box-shadow:
                0 8px 18px rgba(111, 78, 55, .18);

        }


        /* =========================
           ORDER SUMMARY
        ========================= */

        .order-summary {

            position: sticky;

            top: 25px;

            padding: 25px;

            background: #FFFFFF;

            border-radius: 18px;

            box-shadow:
                0 10px 30px rgba(75, 54, 33, .07);

        }


        .summary-title {

            margin: 0 0 20px;

            color: #4B3621;

            font-size: 19px;

            font-weight: 600;

        }


        .summary-items {

            display: flex;

            flex-direction: column;

            gap: 13px;

            margin-bottom: 18px;

        }


        .summary-item {

            display: flex;

            justify-content: space-between;

            gap: 15px;

            color: #6D625B;

            font-size: 12px;

            line-height: 1.5;

        }


        .summary-item-name {

            min-width: 0;

        }


        .summary-item-price {

            flex-shrink: 0;

            color: #4B3621;

            font-weight: 600;

        }


        .summary-total {

            display: flex;

            align-items: center;

            justify-content: space-between;

            gap: 15px;

            padding-top: 18px;

            border-top: 1px solid #EDE5DC;

            color: #4B3621;

            font-size: 16px;

            font-weight: 700;

        }


        .summary-total span:last-child {

            color: #8B5E3C;

        }


        /* =========================
           BACK TO CART
        ========================= */

        .back-cart-btn {

            display: flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            width: 100%;

            margin-top: 12px;

            padding: 12px 18px;

            background: #F3E8D8;

            color: #6F4E37;

            border-radius: 10px;

            text-decoration: none;

            box-sizing: border-box;

            font-size: 13px;

            font-weight: 600;

            transition: .3s;

        }


        .back-cart-btn:hover {

            background: #E8D6BE;

        }


        /* =========================
           RESPONSIVE
        ========================= */

        @media (max-width: 900px) {

            .checkout-layout {

                grid-template-columns: 1fr;

            }


            .order-summary {

                position: static;

            }

        }


        @media (max-width: 600px) {

            .checkout-page {

                padding: 30px 18px 60px;

            }


            .checkout-title {

                font-size: 43px;

            }


            .checkout-form-card,

            .order-summary {

                padding: 22px;

            }


            .receipt {

                padding: 28px 20px;

            }


            .receipt-brand {

                font-size: 32px;

            }


            .receipt-meta-row,

            .receipt-payment-row {

                flex-direction: column;

                gap: 2px;

            }


            .receipt-meta-row strong,

            .receipt-payment-row strong {

                text-align: left;

            }

        }


        @media (max-width: 450px) {

            .checkout-title {

                font-size: 37px;

            }


            .receipt-actions {

                flex-direction: column;

            }


            .receipt-btn {

                width: 100%;

                box-sizing: border-box;

            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<main class="checkout-page">


    <?php if ($success && $receipt_order): ?>


        <!-- =========================
             STRUK PEMBELIAN
        ========================= -->

        <div class="receipt-wrapper">


            <div class="receipt">


                <!-- HEADER -->

                <div class="receipt-header">

                    <h1 class="receipt-brand">

                        LinglungBooks

                    </h1>


                    <div class="receipt-subtitle">

                        Struk Pembelian

                    </div>


                    <div class="receipt-thankyou">

                        Terima kasih telah berbelanja
                        bersama kami.

                    </div>

                </div>


                <!-- INFO PESANAN -->

                <div class="receipt-meta">


                    <div class="receipt-meta-row">

                        <span>

                            No. Pesanan

                        </span>


                        <strong>

                            #<?= htmlspecialchars($receipt_order['transaction_code'] ?? (string) $receipt_order['id'], ENT_QUOTES, 'UTF-8'); ?>

                        </strong>

                    </div>


                    <div class="receipt-meta-row">

                        <span>

                            Tanggal

                        </span>


                        <strong>

                            <?= date(
                                'd/m/Y H:i',
                                strtotime(
                                    $receipt_order['created_at']
                                )
                            ); ?>

                        </strong>

                    </div>


                </div>


                <!-- DATA PEMBELI -->

                <div class="receipt-customer">


                    <h3 class="receipt-section-title">

                        Data Pengiriman

                    </h3>


                    <div class="receipt-customer-row">

                        <span class="receipt-customer-label">

                            Nama

                        </span>


                        <span class="receipt-customer-value">

                            <?= htmlspecialchars(
                                $receipt_order['recipient_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </span>

                    </div>


                    <div class="receipt-customer-row">

                        <span class="receipt-customer-label">

                            Telepon

                        </span>


                        <span class="receipt-customer-value">

                            <?= htmlspecialchars(
                                $receipt_order['phone'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </span>

                    </div>


                    <div class="receipt-customer-row">

                        <span class="receipt-customer-label">

                            Alamat

                        </span>


                        <span class="receipt-customer-value">

                            <?= nl2br(
                                htmlspecialchars(
                                    $receipt_order['address'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                )
                            ); ?>

                        </span>

                    </div>


                </div>


                <!-- DAFTAR BUKU -->

                <div class="receipt-items">


                    <h3 class="receipt-section-title">

                        Detail Pembelian

                    </h3>


                    <?php foreach (
                        $receipt_items
                        as $item
                    ): ?>


                        <div class="receipt-item">


                            <div class="receipt-item-info">


                                <div class="receipt-item-name">

                                    <?= htmlspecialchars(
                                        $item['title'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                </div>


                                <div class="receipt-item-qty">

                                    <?= (int) $item['quantity']; ?>

                                    ×

                                    Rp<?= number_format(
                                        $item['price'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </div>


                            </div>


                            <div class="receipt-item-price">

                                Rp<?= number_format(
                                    $item['price'] *
                                    $item['quantity'],
                                    0,
                                    ",",
                                    "."
                                ); ?>

                            </div>


                        </div>


                    <?php endforeach; ?>


                </div>


                <!-- TOTAL -->

                <div class="receipt-total">


                    <span class="receipt-total-label">

                        TOTAL

                    </span>


                    <span class="receipt-total-value">

                        Rp<?= number_format(
                            $receipt_order['total_price'],
                            0,
                            ",",
                            "."
                        ); ?>

                    </span>


                </div>


                <!-- PEMBAYARAN -->

                <div class="receipt-payment">


                    <h3 class="receipt-section-title">

                        Pembayaran

                    </h3>


                    <div class="receipt-payment-row">

                        <span>

                            Metode Pembayaran

                        </span>


                        <strong>

                            <?= htmlspecialchars(match ($receipt_order['payment_method']) {
                                'DANA' => 'DANA',
                                'GoPay' => 'GoPay',
                                'QRIS' => 'QRIS',
                                default => 'COD'
                            }, ENT_QUOTES, 'UTF-8') ?>

                        </strong>

                    </div>


                    <div class="receipt-payment-row">

                        <span>

                            Status

                        </span>


                        <strong
                            class="<?=
                                $receipt_order['status'] === 'Paid'
                                    ? 'status-paid'
                                    : 'status-pending'
                            ?>"
                        >

                            <?= htmlspecialchars(
                                $receipt_order['status'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </strong>

                    </div>


                    <?php if (
                        $receipt_order['payment_method'] !== 'COD'
                    ): ?>


                        <div class="receipt-transfer">


                            <div class="receipt-transfer-title">

                                <i class="fa-solid fa-building-columns"></i>

                                Informasi Pembayaran

                            </div>


                            <?php if ($receipt_order['payment_method'] === 'Transfer'): ?>
                                <p>Bank: <strong><?= htmlspecialchars($bank_name, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>No. Rekening: <strong><?= htmlspecialchars($bank_account, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>Atas Nama: <strong><?= htmlspecialchars($bank_holder, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <?php elseif ($receipt_order['payment_method'] === 'DANA'): ?>
                                <p>DANA: <strong><?= htmlspecialchars($dana_number, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>Atas Nama: <strong><?= htmlspecialchars($dana_holder, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <?php elseif ($receipt_order['payment_method'] === 'GoPay'): ?>
                                <p>GoPay: <strong><?= htmlspecialchars($gopay_number, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>Atas Nama: <strong><?= htmlspecialchars($gopay_holder, ENT_QUOTES, 'UTF-8'); ?></strong></p>
                            <?php elseif ($receipt_order['payment_method'] === 'QRIS'): ?>
                                <p>Silakan scan QRIS yang ditampilkan pada halaman checkout untuk menyelesaikan pembayaran.</p>
                            <?php elseif (str_starts_with($receipt_order['payment_method'], 'VA_')): ?>
                                <p>Bank: <strong><?= htmlspecialchars($receipt_order['va_bank'] ?? substr($receipt_order['payment_method'], 3), ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>Nomor Virtual Account: <strong><?= htmlspecialchars($receipt_order['va_number'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p>Referensi pembayaran: <strong><?= htmlspecialchars($receipt_order['payment_reference'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></strong></p>
                                <p><em>Pembayaran VA akan diproses setelah bukti pembayaran diverifikasi oleh admin LinglungBooks.</em></p>
                            <?php endif; ?>


                            <p style="margin-top:10px;">

                                <?php if (
                                    !empty(
                                        $receipt_order['payment_proof']
                                    )
                                ): ?>

                                    <i class="fa-solid fa-circle-check"></i>

                                    Bukti pembayaran sudah diupload.

                                <?php else: ?>

                                    Bukti pembayaran belum diupload.

                                <?php endif; ?>

                            </p>


                        </div>


                    <?php endif; ?>


                </div>


                <!-- FOOTER -->

                <div class="receipt-footer">

                    <p>

                        Simpan struk ini sebagai bukti
                        pembelian kamu.

                    </p>


                    <p>

                        <strong>
                            LinglungBooks
                        </strong>

                        — Temukan buku favoritmu.

                    </p>

                </div>


            </div>


            <!-- ACTION -->

            <div class="receipt-actions">


                <a
                    href="order_detail.php?id=<?= (int) $receipt_order['id']; ?>&back=<?= urlencode('dashboard.php'); ?>"
                    class="receipt-btn receipt-btn-primary"
                >

                    <i class="fa-solid fa-receipt"></i>

                    Lihat Detail Pesanan

                </a>


            </div>


        </div>


    <?php else: ?>


        <!-- =========================
             CHECKOUT NORMAL
        ========================= -->


        <a
            href="<?= htmlspecialchars(
                $back,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
            class="global-back-button"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>


        <h1 class="checkout-title">

            Checkout

        </h1>


        <?php if ($error !== ''): ?>


            <div class="checkout-error">

                <i class="fa-solid fa-circle-exclamation"></i>

                <span>

                    <?= htmlspecialchars(
                        $error,
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>

                </span>

            </div>


        <?php endif; ?>


        <?php if (empty($cart_items)): ?>


            <div class="receipt-wrapper">


                <div class="receipt" style="text-align:center;">


                    <div class="receipt-header">

                        <h1 class="receipt-brand">

                            LinglungBooks

                        </h1>


                        <div class="receipt-subtitle">

                            Checkout

                        </div>

                    </div>


                    <div
                        style="
                            padding:45px 10px;
                            color:#8A7A6D;
                        "
                    >

                        <i
                            class="fa-solid fa-cart-shopping"
                            style="
                                font-size:45px;
                                color:#6F4E37;
                                margin-bottom:18px;
                            "
                        ></i>


                        <h2
                            style="
                                color:#4B3621;
                                font-size:21px;
                                margin:0 0 8px;
                            "
                        >

                            Keranjang masih kosong

                        </h2>


                        <p
                            style="
                                font-size:13px;
                                margin:0 0 20px;
                            "
                        >

                            Tambahkan buku ke keranjang
                            terlebih dahulu sebelum checkout.

                        </p>


                        <a
                            href="<?= htmlspecialchars(
                                $books_url,
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                            class="receipt-btn receipt-btn-primary"
                        >

                            <i class="fa-solid fa-book"></i>

                            Jelajahi Buku

                        </a>

                    </div>


                </div>


            </div>


        <?php else: ?>


            <!-- =========================
                 FORM CHECKOUT
            ========================= -->

            <form
                method="POST"
                class="checkout-layout"
                enctype="multipart/form-data"
            >


                <!-- FORM -->

                <section class="checkout-form-card">


                    <h2 class="form-title">

                        Data Pemesan

                    </h2>


                    <!-- NAMA -->

                    <div class="form-group">

                        <label
                            for="name"
                            class="form-label"
                        >

                            Nama Lengkap

                        </label>


                        <input
                            type="text"
                            id="name"
                            name="name"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $account['fullname'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                            readonly
                            required
                        >

                    </div>


                    <!-- TELEPON -->

                    <div class="form-group">

                        <label
                            for="phone"
                            class="form-label"
                        >

                            Nomor Telepon

                        </label>


                        <input
                            type="text"
                            id="phone"
                            name="phone"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $account['phone'] ?? '',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                            readonly
                            required
                        >

                    </div>


                    <!-- ALAMAT -->

                    <div class="form-group">

                        <label
                            for="address"
                            class="form-label"
                        >

                            Alamat Pengiriman

                        </label>


                        <textarea
                            id="address"
                            name="address"
                            class="form-control"
                            readonly
                            required
                        ><?= htmlspecialchars(
                            $account['address'] ?? '',
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?></textarea>

                    </div>


                    <!-- PEMBAYARAN -->
                    <div class="form-group">
                        <label class="form-label">Metode Pembayaran</label>
                        <div class="payment-options">
                            <?php
                            $payment_options = [
                                ['value' => 'VA_BCA', 'label' => 'VA BCA', 'icon' => 'fa-building-columns'],
                                ['value' => 'VA_BRI', 'label' => 'VA BRI', 'icon' => 'fa-building-columns'],
                                ['value' => 'VA_BNI', 'label' => 'VA BNI', 'icon' => 'fa-building-columns'],
                                ['value' => 'VA_MANDIRI', 'label' => 'VA Mandiri', 'icon' => 'fa-building-columns']
                            ];
                            foreach ($payment_options as $option):
                                $option_id = 'payment_' . strtolower($option['value']);
                            ?>
                                <div class="payment-option">
                                    <input type="radio" id="<?= htmlspecialchars($option_id); ?>" name="payment_method" value="<?= htmlspecialchars($option['value']); ?>" <?= (($_POST['payment_method'] ?? '') === $option['value']) ? 'checked' : ''; ?> <?= $option['value'] === 'VA_BCA' ? 'required' : ''; ?>>
                                    <label for="<?= htmlspecialchars($option_id); ?>" class="payment-label">
                                        <span class="payment-icon"><i class="fa-solid <?= htmlspecialchars($option['icon']); ?>"></i></span>
                                        <span class="payment-text"><?= htmlspecialchars($option['label']); ?></span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div style="margin-top:12px;padding:13px 15px;background:#F8F0E7;border:1px solid #E8D8C7;border-radius:12px;color:#6F4E37;font-size:12px;line-height:1.7;">
                            <strong><i class="fa-solid fa-shield-halved"></i> Virtual Account</strong><br>
                            Pilih VA BCA, BRI, BNI, atau Mandiri. Nomor VA dan kode referensi pembayaran akan ditampilkan setelah pesanan dibuat. Unggah bukti pembayaran agar dapat diverifikasi oleh admin LinglungBooks.
                        </div>

                        <div id="digital-payment-info" class="transfer-info" style="display:none;">
                            <div class="transfer-info-title"><i class="fa-solid fa-wallet"></i> Informasi Pembayaran</div>
                            <div class="transfer-info-text" id="payment-instruction">Silakan lakukan pembayaran sesuai total pesanan.</div>

                            <div class="bank-detail" id="payment-destination">
                                <div id="bank-fields">
                                    <div class="bank-detail-label">Bank tujuan</div>
                                    <div class="bank-detail-value">Virtual Account sesuai bank pilihan</div>
                                    <div class="bank-detail-label" style="margin-top:8px;">Atas Nama</div>
                                    <div class="bank-detail-value"><?= htmlspecialchars($bank_holder, ENT_QUOTES, 'UTF-8'); ?></div>
                                </div>
                            </div>

                            <div class="transfer-instruction">
                                <strong>Setelah melakukan pembayaran:</strong>
                                <ol>
                                    <li>Pastikan nominal pembayaran sesuai total pesanan.</li>
                                    <li>Simpan bukti pembayaran.</li>
                                    <li>Upload bukti pembayaran pada kolom di bawah.</li>
                                </ol>
                            </div>

                            <div class="upload-proof">
                                <label for="payment_proof" class="form-label">Bukti Pembayaran <span style="color:#B04A3A;">*</span></label>
                                <input type="file" id="payment_proof" name="payment_proof" class="form-control" accept=".jpg,.jpeg,.png,.webp">
                                <small class="upload-note">Format JPG, JPEG, PNG, atau WEBP. Maksimal 5 MB.</small>
                            </div>
                        </div>
                    </div>

                    <!-- SUBMIT -->

                    <button
                        type="submit"
                        name="place_order"
                        class="place-order-btn"
                    >

                        <i class="fa-solid fa-check"></i>

                        Buat Pesanan

                    </button>


                </section>


                <!-- =========================
                     SUMMARY
                ========================= -->

                <aside class="order-summary">


                    <h2 class="summary-title">

                        Ringkasan Pesanan

                    </h2>


                    <div class="summary-items">


                        <?php foreach (
                            $cart_items
                            as $item
                        ): ?>


                            <div class="summary-item">


                                <span class="summary-item-name">

                                    <?= htmlspecialchars(
                                        $item['title'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                    ×

                                    <?= (int) $item['quantity']; ?>

                                </span>


                                <span class="summary-item-price">

                                    Rp<?= number_format(
                                        $item['price'] *
                                        $item['quantity'],
                                        0,
                                        ",",
                                        "."
                                    ); ?>

                                </span>


                            </div>


                        <?php endforeach; ?>


                    </div>


                    <div class="summary-total">

                        <span>

                            Total

                        </span>


                        <span>

                            Rp<?= number_format(
                                $total,
                                0,
                                ",",
                                "."
                            ); ?>

                        </span>

                    </div>


                    <a
                        href="<?= htmlspecialchars(
                            $cart_url,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                        class="back-cart-btn"
                    >

                        <i class="fa-solid fa-cart-shopping"></i>

                        Kembali ke Keranjang

                    </a>


                </aside>


            </form>


        <?php endif; ?>


    <?php endif; ?>


</main>


<script>

/* =========================
   PAYMENT METHOD
========================= */
const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
const digitalInfo = document.getElementById('digital-payment-info');
const paymentProof = document.getElementById('payment_proof');
const bankFields = document.getElementById('bank-fields');
const paymentInstruction = document.getElementById('payment-instruction');
function updatePaymentDisplay() {
    const selected = document.querySelector('input[name="payment_method"]:checked');
    const isDigital = !!selected;
    if (digitalInfo) digitalInfo.style.display = isDigital ? 'block' : 'none';
    if (bankFields) bankFields.style.display = isDigital ? 'block' : 'none';
    if (paymentProof) {
        paymentProof.required = isDigital;
        if (!isDigital) paymentProof.value = '';
    }
    if (paymentInstruction) paymentInstruction.textContent = 'Lakukan pembayaran melalui Virtual Account bank pilihan, lalu unggah bukti pembayaran untuk diverifikasi admin.';
}
paymentRadios.forEach(radio => radio.addEventListener('change', updatePaymentDisplay));
updatePaymentDisplay();
</script>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>