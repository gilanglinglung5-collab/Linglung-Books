<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'dashboard.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   NORMALISASI INDEX
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_root_index = ($back === '../index.php');

$is_safe_back =
    $is_root_index ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {

    header(
        "Location: login.php?back=" .
        urlencode($back)
    );

    exit;
}


include '../config/database.php';


/* =========================
   VALIDASI ORDER ID
========================= */

if (
    !isset($_GET['id']) ||
    !is_numeric($_GET['id'])
) {

    header(
        "Location: orders.php?back=" .
        urlencode($back)
    );

    exit;
}


$order_id = (int) $_GET['id'];

$user_id = (int) $_SESSION['user_id'];

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/* =========================
   KONFIRMASI PENERIMAAN / SELESAI / RETUR
========================= */
$confirmation_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_order_received'], $_POST['csrf_token'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $confirmation_message = 'Sesi keamanan tidak valid. Muat ulang halaman.';
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE orders SET status='Received', user_confirmed_at=NOW() WHERE id=? AND user_id=? AND status='Shipped' AND payment_verification='approved'");
        mysqli_stmt_bind_param($stmt, 'ii', $order_id, $user_id); mysqli_stmt_execute($stmt);
        $ok = mysqli_stmt_affected_rows($stmt) > 0; mysqli_stmt_close($stmt);
        $confirmation_message = $ok ? 'Penerimaan barang tercatat. Silakan pilih Selesai atau Retur.' : 'Pesanan belum dapat dikonfirmasi diterima.';
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finish_order'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) $confirmation_message = 'Sesi keamanan tidak valid.';
    else {
        $stmt=mysqli_prepare($conn,"UPDATE orders SET status='Completed' WHERE id=? AND user_id=? AND status='Received'"); mysqli_stmt_bind_param($stmt,'ii',$order_id,$user_id); mysqli_stmt_execute($stmt); $ok=mysqli_stmt_affected_rows($stmt)>0; mysqli_stmt_close($stmt);
        $confirmation_message=$ok?'Pesanan berhasil diselesaikan. Terima kasih!':'Pesanan tidak dapat diselesaikan pada tahap ini.';
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_return'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) $confirmation_message='Sesi keamanan tidak valid.';
    elseif (!isset($_FILES['return_proof']) || $_FILES['return_proof']['error'] !== UPLOAD_ERR_OK) $confirmation_message='Video bukti unboxing wajib diunggah.';
    else {
        $f=$_FILES['return_proof']; $ext=strtolower(pathinfo($f['name'],PATHINFO_EXTENSION)); $allowed=['mp4','mov','webm']; $mime='';
        if (function_exists('finfo_open')) { $fi=finfo_open(FILEINFO_MIME_TYPE); $mime=$fi?finfo_file($fi,$f['tmp_name']):''; if($fi)finfo_close($fi); }
        $allowedMime=['video/mp4','video/quicktime','video/webm','application/octet-stream'];
        if ($f['size']>100*1024*1024 || !in_array($ext,$allowed,true) || ($mime!==''&&!in_array($mime,$allowedMime,true))) $confirmation_message='Bukti harus berupa video MP4, MOV, atau WEBM maksimal 100 MB.';
        else {
            $dir='../assets/return_proofs/'; if(!is_dir($dir))mkdir($dir,0755,true); $filename='return_'.$user_id.'_'.$order_id.'_'.bin2hex(random_bytes(6)).'.'.$ext;
            if(move_uploaded_file($f['tmp_name'],$dir.$filename)) {
                $note=trim($_POST['return_note']??''); $stmt=mysqli_prepare($conn,"UPDATE orders SET status='ReturnRequested', return_status='requested', return_proof=?, return_note=?, return_requested_at=NOW() WHERE id=? AND user_id=? AND status='Received'"); mysqli_stmt_bind_param($stmt,'ssii',$filename,$note,$order_id,$user_id); mysqli_stmt_execute($stmt); $ok=mysqli_stmt_affected_rows($stmt)>0; mysqli_stmt_close($stmt);
                if($ok)$confirmation_message='Pengajuan retur terkirim dan menunggu pemeriksaan admin.'; else {@unlink($dir.$filename);$confirmation_message='Retur hanya bisa diajukan setelah pesanan diterima.';}
            } else $confirmation_message='Video gagal disimpan.';
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['return_sent'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) $confirmation_message='Sesi keamanan tidak valid.';
    else { $stmt=mysqli_prepare($conn,"UPDATE orders SET status='ReturnShipped', return_status='shipped' WHERE id=? AND user_id=? AND status='ReturnApproved'"); mysqli_stmt_bind_param($stmt,'ii',$order_id,$user_id); mysqli_stmt_execute($stmt); $ok=mysqli_stmt_affected_rows($stmt)>0; mysqli_stmt_close($stmt); $confirmation_message=$ok?'Konfirmasi pengiriman retur tersimpan. Admin akan memeriksa barang saat tiba di gudang.':'Retur belum disetujui atau tidak dapat diperbarui.'; }
}

/* =========================
   KIRIM ULANG BUKTI PEMBAYARAN
========================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['resubmit_payment_proof'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'], $csrf)) {
        $confirmation_message = 'Sesi keamanan tidak valid. Muat ulang halaman.';
    } elseif (!isset($_FILES['replacement_proof']) || $_FILES['replacement_proof']['error'] !== UPLOAD_ERR_OK) {
        $confirmation_message = 'Pilih file bukti pembayaran terlebih dahulu.';
    } else {
        $file = $_FILES['replacement_proof'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'webp'];
        $mime = '';
        if (function_exists('finfo_open')) {
            $fi = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $fi ? finfo_file($fi, $file['tmp_name']) : '';
            if ($fi) finfo_close($fi);
        }
        $allowed_mime = ['image/jpeg', 'image/png', 'image/webp'];
        if ($file['size'] > 5 * 1024 * 1024 || !in_array($ext, $allowed_ext, true) || ($mime !== '' && !in_array($mime, $allowed_mime, true))) {
            $confirmation_message = 'Bukti harus berupa JPG, PNG, atau WEBP maksimal 5 MB.';
        } else {
            $dir = '../assets/payment_proofs/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $new_name = 'payment_' . $user_id . '_' . $order_id . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $dir . $new_name)) {
                $stmt = mysqli_prepare($conn, "
                    UPDATE orders
                    SET payment_proof = ?,
                        payment_verification = 'pending',
                        verification_note = NULL,
                        verified_at = NULL
                    WHERE id = ?
                      AND user_id = ?
                      AND payment_verification = 'rejected'
                      AND status NOT IN ('Completed', 'Cancelled')
                ");
                mysqli_stmt_bind_param($stmt, 'sii', $new_name, $order_id, $user_id);
                mysqli_stmt_execute($stmt);
                $updated = mysqli_stmt_affected_rows($stmt);
                mysqli_stmt_close($stmt);
                if ($updated > 0) {
                    $confirmation_message = 'Bukti baru berhasil dikirim dan menunggu verifikasi admin.';
                } else {
                    @unlink($dir . $new_name);
                    $confirmation_message = 'Bukti tidak dapat diperbarui untuk pesanan ini.';
                }
            } else {
                $confirmation_message = 'Gagal menyimpan file bukti pembayaran.';
            }
        }
    }
}

/* =========================
   AMBIL DATA ORDER
========================= */

$orderQuery = mysqli_query(
    $conn,
    "
    SELECT *
    FROM orders
    WHERE id = '$order_id'
    AND user_id = '$user_id'
    LIMIT 1
    "
);


$order = $orderQuery
    ? mysqli_fetch_assoc($orderQuery)
    : null;


if (!$order) {

    header(
        "Location: orders.php?back=" .
        urlencode($back)
    );

    exit;
}


/* =========================
   AMBIL DETAIL BUKU
========================= */

$detailQuery = mysqli_query(
    $conn,
    "
    SELECT
        order_details.*,
        books.title,
        books.cover
    FROM order_details
    JOIN books
        ON order_details.book_id = books.id
    WHERE order_details.order_id = '$order_id'
    "
);


/* =========================
   URL LIHAT STRUK
========================= */

$receipt_url =
    'receipt.php?id=' .
    $order_id .
    '&back=' .
    urlencode($back);

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Detail Pesanan - LinglungBooks
    </title>


    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&family=Cormorant+Garamond:wght@600&display=swap"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Poppins, sans-serif;
        }


        body {
            background: #F8F3EC;
            color: #3E2C23;
        }


        /* =========================
           NAVBAR
        ========================= */

        .navbar {
            background: #F3E8D8;

            padding: 20px 70px;

            display: flex;

            justify-content: center;

            align-items: center;

            box-shadow:
                0 5px 15px rgba(0,0,0,.08);
        }


        .logo {
            font-family: 'Cormorant Garamond', serif;

            font-size: 38px;

            font-weight: bold;
        }


        .logo span {
            color: #8B5E3C;
        }


        /* =========================
           CONTAINER
        ========================= */

        .container {
            width: 90%;

            max-width: 1000px;

            margin: 50px auto 80px;
        }


        h1 {
            font-family: 'Cormorant Garamond', serif;

            font-size: 45px;

            color: #4B3621;

            margin-bottom: 25px;
        }


        /* =========================
           INFO PESANAN
        ========================= */

        .info {
            background: white;

            padding: 25px;

            border-radius: 20px;

            box-shadow:
                0 10px 25px rgba(0,0,0,.08);

            margin-bottom: 25px;
        }


        .info p {
            margin-bottom: 12px;

            line-height: 1.6;
        }


        .info p:last-child {
            margin-bottom: 0;
        }


        .info strong {
            color: #4B3621;
        }


        .status {
            display: inline-block;

            background: #F3E8D8;

            padding: 8px 18px;

            border-radius: 20px;

            color: #6F4E37;

            margin-top: 5px;
        }


        /* =========================
           ALAMAT
        ========================= */

        .shipping-title {
            font-size: 20px;

            font-weight: 600;

            color: #4B3621;

            margin-bottom: 15px;
        }


        .shipping {
            background: #FFF9F3;

            padding: 18px;

            border-radius: 15px;

            border: 1px solid #E8D8C7;
        }


        .shipping p {
            margin-bottom: 8px;
        }


        .shipping p:last-child {
            margin-bottom: 0;
        }


        .address {
            white-space: pre-line;
        }


        /* =========================
           TABLE
        ========================= */

        .table-wrapper {
            width: 100%;

            overflow-x: auto;

            border-radius: 20px;
        }


        table {
            width: 100%;

            min-width: 700px;

            background: white;

            border-collapse: collapse;

            border-radius: 20px;

            overflow: hidden;

            box-shadow:
                0 10px 25px rgba(0,0,0,.08);
        }


        th {
            background: #6F4E37;

            color: white;

            padding: 15px;
        }


        td {
            padding: 15px;

            text-align: center;

            border-bottom: 1px solid #eee;
        }


        .cover {
            width: 80px;

            height: 100px;

            object-fit: contain;
        }


        /* =========================
           TOTAL
        ========================= */

        .total {
            margin-top: 25px;

            text-align: right;

            font-size: 23px;

            font-weight: 600;

            color: #8B5E3C;
        }


        /* =========================
           ACTIONS
        ========================= */

        .actions {
            display: flex;

            flex-wrap: wrap;

            gap: 12px;

            margin-top: 25px;
        }


        .back,
        .receipt-button {
            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            color: white;

            padding: 12px 25px;

            border-radius: 30px;

            text-decoration: none;

            transition: .3s;
        }


        .back {
            background: #6F4E37;
        }


        .back:hover {
            background: #8B5E3C;

            transform: translateX(-2px);
        }


        .receipt-button {
            background: #8B5E3C;
        }


        .receipt-button:hover {
            background: #6F4E37;

            transform: translateY(-2px);
        }


        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 768px) {

            .navbar {
                padding: 18px 25px;
            }


            .logo {
                font-size: 30px;
            }


            .container {
                width: 92%;

                margin: 35px auto 60px;
            }


            h1 {
                font-size: 36px;
            }


            .info {
                padding: 20px;
            }


            .total {
                font-size: 20px;
            }


            .actions {
                flex-direction: column;
            }


            .back,
            .receipt-button {
                width: 100%;
            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<header class="navbar">

    <div class="logo">

        Linglung <span>Books</span>

    </div>

</header>


<div class="container">


    <h1>
        Detail Pesanan 📦
    </h1>


    <!-- =========================
         INFORMASI PESANAN
    ========================= -->

    <div class="info">


        <p>

            <!-- KODE TRANSAKSI: menampilkan kode transaksi publik pada detail pesanan. -->
<strong>ID Pesanan:</strong>

            #<?= htmlspecialchars(
                $order['transaction_code'] ?? (string) $order['id'],
                ENT_QUOTES,
                'UTF-8'
            ); ?>

        </p>


        <p>

            <strong>Tanggal:</strong>

            <?= htmlspecialchars(
                $order['created_at']
            ); ?>

        </p>


        <p>

            <strong>Status:</strong>

            <br>


            <span class="status">

                <?= htmlspecialchars(match (strtolower($order['status'] ?? '')) { 'processing' => 'Diproses', 'packed' => 'Dikemas', 'shipped' => 'Dikirim', 'received' => 'Diterima', 'completed' => 'Selesai', 'returnrequested' => 'Retur Menunggu', 'returnapproved' => 'Retur Disetujui', 'returnrejected' => 'Retur Ditolak', 'returnshipped' => 'Retur Dikirim', 'returned' => 'Retur Tiba di Gudang', 'refunded' => 'Dana Dikembalikan', 'cancelled' => 'Dibatalkan', default => $order['status'] ?? 'Diproses' }, ENT_QUOTES, 'UTF-8'); ?>

            </span>

        </p>

        <p><strong>Verifikasi pembayaran:</strong>
            <?= htmlspecialchars(ucfirst($order['payment_verification'] ?? 'pending'), ENT_QUOTES, 'UTF-8'); ?>
        </p>

        <?php if (!empty($order['verification_note'])): ?>
            <p><strong>Catatan admin:</strong> <?= htmlspecialchars($order['verification_note'], ENT_QUOTES, 'UTF-8'); ?></p>
        <?php endif; ?>

        <?php if (!empty($order['va_number'])): ?>
            <p><strong>Bank VA:</strong> <?= htmlspecialchars($order['va_bank'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Nomor VA:</strong> <?= htmlspecialchars($order['va_number'], ENT_QUOTES, 'UTF-8'); ?></p>
            <p><strong>Referensi:</strong> <?= htmlspecialchars($order['payment_reference'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></p>
            <p style="color:#8B5E3C;font-size:12px;">Nomor VA ini digunakan sebagai referensi pesanan. Unggah bukti pembayaran agar dapat diverifikasi admin.</p>
        <?php endif; ?>

    </div>


    <!-- =========================
         INFORMASI PENGIRIMAN
    ========================= -->

    <div class="info">


        <div class="shipping-title">

            Informasi Pengiriman

        </div>


        <div class="shipping">


            <p>

                <strong>Nama Penerima:</strong>

                <br>

                <?= htmlspecialchars(
                    $order['recipient_name']
                ); ?>

            </p>


            <p>

                <strong>No. Telepon:</strong>

                <br>

                <?= htmlspecialchars(
                    $order['phone']
                ); ?>

            </p>


            <p>

                <strong>Alamat:</strong>

                <br>

                <span class="address">

                    <?= htmlspecialchars(
                        $order['address']
                    ); ?>

                </span>

            </p>


            <p>

                <strong>Metode Pembayaran:</strong>

                <br>

                <?= htmlspecialchars(match ($order['payment_method'] ?? '') { 'Transfer' => 'Transfer Bank',  'VA_BCA' => 'Virtual Account BCA', 'VA_BRI' => 'Virtual Account BRI', 'VA_BNI' => 'Virtual Account BNI', 'VA_MANDIRI' => 'Virtual Account Mandiri', default => 'Virtual Account ' . str_replace('VA_', '', (string)($order['payment_method'] ?? '')) }, ENT_QUOTES, 'UTF-8'); ?>

            </p>


        </div>


    </div>


    <!-- =========================
         DAFTAR BUKU
    ========================= -->

    <div class="table-wrapper">


        <table>


            <tr>

                <th>Cover</th>

                <th>Buku</th>

                <th>Harga</th>

                <th>Jumlah</th>

                <th>Subtotal</th>

            </tr>


            <?php

            $total = 0;

            if ($detailQuery) {

                while (
                    $item =
                    mysqli_fetch_assoc($detailQuery)
                ) {

                    $subtotal =
                        $item['price'] *
                        $item['quantity'];

                    $total += $subtotal;

            ?>


                <tr>


                    <td>

                        <?php if (!empty($item['cover'])): ?>

                            <img
                                class="cover"
                                src="../assets/img/<?= htmlspecialchars(
                                    $item['cover']
                                ); ?>"
                                alt="<?= htmlspecialchars(
                                    $item['title']
                                ); ?>"
                            >

                        <?php else: ?>

                            <i
                                class="fa-solid fa-book"
                                style="font-size: 30px; color: #6F4E37;"
                            ></i>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= htmlspecialchars(
                            $item['title']
                        ); ?>

                    </td>


                    <td>

                        Rp<?= number_format(
                            $item['price'],
                            0,
                            ",",
                            "."
                        ); ?>

                    </td>


                    <td>

                        <?= htmlspecialchars(
                            $item['quantity']
                        ); ?>

                    </td>


                    <td>

                        Rp<?= number_format(
                            $subtotal,
                            0,
                            ",",
                            "."
                        ); ?>

                    </td>


                </tr>


            <?php

                }

            }

            ?>


        </table>


    </div>


    <!-- =========================
         TOTAL
    ========================= -->

    <div class="total">

        Total :

        Rp<?= number_format(
            $total,
            0,
            ",",
            "."
        ); ?>

    </div>


    <?php if (($order['payment_verification'] ?? '') === 'rejected' && !in_array($order['status'], ['Completed', 'Cancelled'], true)): ?>
        <div class="info">
            <h3 style="margin-bottom:10px;color:#4B3621;">Bukti Pembayaran Ditolak</h3>
            <p style="margin-bottom:12px;">Catatan admin: <?= htmlspecialchars($order['verification_note'] ?? 'Silakan periksa kembali bukti pembayaran.', ENT_QUOTES, 'UTF-8'); ?></p>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                <label for="replacement_proof"><strong>Upload bukti yang benar (maks. 5 MB)</strong></label>
                <input type="file" id="replacement_proof" name="replacement_proof" accept=".jpg,.jpeg,.png,.webp" required style="display:block;margin:12px 0;">
                <button type="submit" name="resubmit_payment_proof" value="1" style="border:0;background:#6F4E37;color:#fff;padding:12px 20px;border-radius:10px;cursor:pointer;">Kirim Ulang Bukti</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- TINDAKAN STATUS PESANAN -->
    <?php if (!empty($confirmation_message)): ?><div class="info" style="border-left:4px solid #6F4E37;"><?= htmlspecialchars($confirmation_message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
    <?php $st = $order['status'] ?? ''; ?>
    <?php if ($st === 'Shipped' && ($order['payment_verification'] ?? '') === 'approved'): ?>
      <div class="info"><h3>Konfirmasi Penerimaan</h3><p>Pastikan buku sudah kamu terima sebelum menekan tombol ini.</p><form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><button type="submit" name="confirm_order_received" value="1" style="border:0;background:#6F4E37;color:#fff;padding:13px 22px;border-radius:10px;font-weight:600;cursor:pointer;">Pesanan Diterima</button></form></div>
    <?php elseif ($st === 'Received'): ?>
      <div class="info"><h3>Pilih tindakan berikutnya</h3><p>Jika buku sudah sesuai, selesaikan pesanan. Jika ada masalah, ajukan retur dengan video unboxing.</p><form method="POST" style="margin-bottom:18px;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><button type="submit" name="finish_order" value="1" style="border:0;background:#6F4E37;color:#fff;padding:12px 20px;border-radius:10px;font-weight:600;cursor:pointer;">Selesai</button></form><form method="POST" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><label for="return_proof"><strong>Video bukti unboxing (MP4, MOV, WEBM; maks. 100 MB)</strong></label><input type="file" id="return_proof" name="return_proof" accept="video/mp4,video/quicktime,video/webm,.mp4,.mov,.webm" required style="display:block;margin:10px 0;"><label for="return_note">Alasan retur</label><textarea id="return_note" name="return_note" rows="3" maxlength="2000" required style="display:block;width:100%;padding:10px;margin:8px 0 12px;border:1px solid #ddd;border-radius:8px;"></textarea><button type="submit" name="request_return" value="1" style="border:0;background:#9B3E35;color:#fff;padding:12px 20px;border-radius:10px;font-weight:600;cursor:pointer;">Ajukan Retur</button></form></div>
    <?php elseif ($st === 'ReturnApproved'): ?>
      <div class="info"><h3>Retur disetujui</h3><p>Silakan kirim barang ke gudang, lalu konfirmasikan pengiriman di bawah.</p><form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>"><button type="submit" name="return_sent" value="1" style="border:0;background:#6F4E37;color:#fff;padding:12px 20px;border-radius:10px;cursor:pointer;">Barang Retur Sudah Dikirim</button></form></div>
    <?php elseif (in_array($st, ['ReturnRequested','ReturnRejected','ReturnShipped','Returned','Refunded'], true)): ?>
      <div class="info"><h3>Status Retur</h3><p><?= htmlspecialchars(match($st){'ReturnRequested'=>'Pengajuan retur menunggu pemeriksaan admin.','ReturnRejected'=>'Pengajuan retur ditolak. Catatan: '.($order['return_admin_note']??'-'),'ReturnShipped'=>'Barang retur sedang dalam perjalanan ke gudang.','Returned'=>'Barang telah diterima gudang; admin perlu memproses pengembalian uang.','Refunded'=>'Pengembalian uang telah diproses admin.','default'=>'Retur diproses.'}, ENT_QUOTES, 'UTF-8'); ?></p></div>
    <?php elseif ($st === 'Completed'): ?><div class="info" style="border-left:4px solid #6F4E37;">Pesanan telah selesai.</div><?php endif; ?>

    <!-- =========================
         ACTIONS
    ========================= -->

    <div class="actions">


        <a
            class="global-back-button"
            href="<?= htmlspecialchars(
                $back,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
        >

            <i class="fa-solid fa-arrow-left"></i>

            Kembali

        </a>


        <a
            class="receipt-button"
            href="<?= htmlspecialchars(
                $receipt_url,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
        >

            <i class="fa-solid fa-receipt"></i>

            Lihat Struk

        </a>


    </div>


</div>


<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>