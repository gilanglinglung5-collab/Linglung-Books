<?php

if (session_status() === PHP_SESSION_NONE) {
    if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
}

include '../config/database.php';


/* =========================================================
   STATUS LOGIN DAN WISHLIST
========================================================= */

// Hanya sesi dengan role user yang dianggap sebagai login pelanggan.
if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') !== 'user') {
    unset($_SESSION['user_id'], $_SESSION['fullname'], $_SESSION['username'], $_SESSION['role']);
}
$is_logged_in = isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'user';

$wishlist_ids = [];

if ($is_logged_in) {
    $wishlist_user_id = (int) $_SESSION['user_id'];

    $wishlist_result = mysqli_query(
        $conn,
        "SELECT book_id FROM wishlist WHERE user_id = '$wishlist_user_id'"
    );

    if ($wishlist_result) {
        while ($wishlist_row = mysqli_fetch_assoc($wishlist_result)) {
            $wishlist_ids[] = (int) $wishlist_row['book_id'];
        }
    }
}


/* =========================================================
   HALAMAN SEBELUMNYA
========================================================= */

$back = $_GET['back'] ?? (
    $is_logged_in
        ? 'dashboard.php'
        : '../index.php'
);

if ($back === '') {
    $back = $is_logged_in
        ? 'dashboard.php'
        : '../index.php';
}


/* =========================================================
   NORMALISASI BACK KE ROOT INDEX
========================================================= */

$back_path = parse_url($back, PHP_URL_PATH);

if ($back_path === 'index.php') {
    $back = '../' . $back;
}


/* =========================================================
   VALIDASI BACK
========================================================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'index.php',
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_safe_back =
    $back === '../index.php'
    ||
    (
        strpos($back, '://') === false
        &&
        strpos($back, '//') !== 0
        &&
        strpos($back, '..') === false
        &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $is_logged_in
        ? 'dashboard.php'
        : '../index.php';
}


/* =========================================================
   URL HALAMAN BOOKS SAAT INI
========================================================= */

$current_url = basename($_SERVER['PHP_SELF']);

$current_query = $_GET;

if (!empty($current_query)) {
    $current_url .= '?' . http_build_query($current_query);
}


/* =========================================================
   FILTER PENCARIAN, KATEGORI, DAN RANGE HARGA
========================================================= */

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$category_id = isset($_GET['category'])
    ? (int) $_GET['category']
    : 0;


/* FILTER HARGA MINIMUM */

$min_price = (
    isset($_GET['min_price'])
    && $_GET['min_price'] !== ''
    && is_numeric($_GET['min_price'])
)
    ? max(0, (int) $_GET['min_price'])
    : null;


/* FILTER HARGA MAKSIMUM */

$max_price = (
    isset($_GET['max_price'])
    && $_GET['max_price'] !== ''
    && is_numeric($_GET['max_price'])
)
    ? max(0, (int) $_GET['max_price'])
    : null;


$per_page = 12;

$page = max(1, (int) ($_GET['page'] ?? 1));

$search_safe = mysqli_real_escape_string(
    $conn,
    $search
);


/* =========================================================
   TAMBAH KE KERANJANG
========================================================= */

if (isset($_POST['add_to_cart'])) {

    if (!$is_logged_in) {
        header(
            "Location: login.php?back=" .
            urlencode($current_url)
        );
        exit;
    }

    $user_id = (int) $_SESSION['user_id'];

    $book_id = isset($_POST['book_id'])
        ? (int) $_POST['book_id']
        : 0;


    /* CEK BUKU */

    $book_query = mysqli_query(
        $conn,
        "
        SELECT id, stock
        FROM books
        WHERE id = '$book_id'
        LIMIT 1
        "
    );


    if (
        $book_query &&
        mysqli_num_rows($book_query) > 0
    ) {

        $book = mysqli_fetch_assoc($book_query);

        $stock = (int) $book['stock'];


        /* CEK STOK */

        if ($stock > 0) {

            /* CEK KERANJANG */

            $cart_query = mysqli_query(
                $conn,
                "
                SELECT id, quantity
                FROM cart
                WHERE user_id = '$user_id'
                AND book_id = '$book_id'
                LIMIT 1
                "
            );


            if (
                $cart_query &&
                mysqli_num_rows($cart_query) > 0
            ) {

                $cart = mysqli_fetch_assoc($cart_query);

                $current_quantity = (int) $cart['quantity'];

                $new_quantity = $current_quantity + 1;

                if ($new_quantity > $stock) {
                    $new_quantity = $stock;
                }

                mysqli_query(
                    $conn,
                    "
                    UPDATE cart
                    SET quantity = '$new_quantity'
                    WHERE id = '" . (int) $cart['id'] . "'
                    AND user_id = '$user_id'
                    "
                );

            } else {

                /* TAMBAH BARANG BARU */

                mysqli_query(
                    $conn,
                    "
                    INSERT INTO cart (
                        user_id,
                        book_id,
                        quantity
                    )
                    VALUES (
                        '$user_id',
                        '$book_id',
                        1
                    )
                    "
                );
            }
        }
    }


    /* ARAHKAN KE KERANJANG */

    header(
        "Location: cart.php?back=" .
        urlencode($current_url)
    );

    exit;
}


/* =========================================================
   QUERY KATEGORI
========================================================= */

$categories = mysqli_query(
    $conn,
    "
    SELECT *
    FROM categories
    ORDER BY category_name ASC
    "
);


/* =========================================================
   QUERY DASAR BUKU
========================================================= */

$sql = "
    SELECT
        books.*,
        categories.category_name
    FROM books

    INNER JOIN categories
        ON books.category_id = categories.id

    WHERE 1=1
";


/* =========================================================
   PENCARIAN BUKU
========================================================= */

if ($search !== '') {

    $sql .= "
        AND (
            books.title LIKE '%$search_safe%'
            OR books.author LIKE '%$search_safe%'
            OR books.publisher LIKE '%$search_safe%'
            OR categories.category_name LIKE '%$search_safe%'
        )
    ";
}


/* =========================================================
   FILTER KATEGORI
========================================================= */

if ($category_id > 0) {
    $sql .= "
        AND books.category_id = $category_id
    ";
}


/* =========================================================
   FILTER RANGE HARGA
========================================================= */

if ($min_price !== null) {
    $sql .= "
        AND books.price >= $min_price
    ";
}

if ($max_price !== null) {
    $sql .= "
        AND books.price <= $max_price
    ";
}


/* =========================================================
   HITUNG JUMLAH BUKU
========================================================= */

$count_sql = "
    SELECT COUNT(*) AS total

    FROM books

    INNER JOIN categories
        ON books.category_id = categories.id

    WHERE 1=1
";


if ($search !== '') {

    $count_sql .= "
        AND (
            books.title LIKE '%$search_safe%'
            OR books.author LIKE '%$search_safe%'
            OR books.publisher LIKE '%$search_safe%'
            OR categories.category_name LIKE '%$search_safe%'
        )
    ";
}


if ($category_id > 0) {

    $count_sql .= "
        AND books.category_id = $category_id
    ";
}


/* FILTER HARGA PADA PERHITUNGAN JUMLAH BUKU */

if ($min_price !== null) {

    $count_sql .= "
        AND books.price >= $min_price
    ";
}

if ($max_price !== null) {

    $count_sql .= "
        AND books.price <= $max_price
    ";
}


$count_result = mysqli_query(
    $conn,
    $count_sql
);

$count_row = $count_result
    ? mysqli_fetch_assoc($count_result)
    : ['total' => 0];

$total_books = (int) ($count_row['total'] ?? 0);

$total_pages = max(
    1,
    (int) ceil($total_books / $per_page)
);

$page = min($page, $total_pages);

$offset = ($page - 1) * $per_page;


/* =========================================================
   AMBIL DATA BUKU
========================================================= */

$sql .= "
    ORDER BY books.id DESC
    LIMIT $per_page
    OFFSET $offset
";

$books = mysqli_query(
    $conn,
    $sql
);


/* =========================================================
   KELOMPOKKAN BUKU BERDASARKAN KATEGORI
========================================================= */

$books_by_category = [];

if ($books) {

    while ($book = mysqli_fetch_assoc($books)) {

        $category_name = $book['category_name'];

        if (!isset($books_by_category[$category_name])) {
            $books_by_category[$category_name] = [];
        }

        $books_by_category[$category_name][] = $book;
    }
}


/* =========================================================
   KATEGORI AKTIF
========================================================= */

$active_category = "Semua Kategori";

if ($category_id > 0 && $categories) {

    mysqli_data_seek($categories, 0);

    while ($cat = mysqli_fetch_assoc($categories)) {

        if ((int) $cat['id'] === $category_id) {
            $active_category = $cat['category_name'];
            break;
        }
    }

    mysqli_data_seek($categories, 0);
}

?>


<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Semua Buku | LinglungBooks</title>


    <link
        rel="stylesheet"
        href="../assets/css/style.css"
    >

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/back-button.css"
    >

    <link
        rel="stylesheet"
        href="../assets/css/enhancements.css"
    >


    <style>

        .books-page {
            max-width: 1400px;
            margin: 0 auto;
            padding: 45px 30px 80px;
        }


        .books-back {
            display: inline-flex;
            align-items: center;
            gap: 9px;
            margin-bottom: 30px;
            padding: 10px 15px;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 10px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: .3s;
        }


        .books-back:hover {
            background: #E8D6BE;
            transform: translateX(-3px);
        }


        .books-header {
            margin-bottom: 30px;
        }


        .books-header h1 {
            font-family: 'Cormorant Garamond', serif;
            font-size: 54px;
            line-height: 1;
            color: #4B3621;
            margin: 0 0 10px;
        }


        .books-header p {
            margin: 0;
            color: #777;
            font-size: 14px;
        }


        /* SEARCH DAN FILTER */

        .filter-box {
            background: #fff;
            border: 1px solid rgba(111,78,55,.08);
            border-radius: 18px;
            padding: 18px;
            margin-bottom: 35px;
            box-shadow: 0 8px 30px rgba(75,54,33,.06);
        }


        .filter-form {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }


        .search-wrapper {
            position: relative;
            flex: 1;
            min-width: 220px;
        }


        .search-wrapper i {
            position: absolute;
            left: 17px;
            top: 50%;
            transform: translateY(-50%);
            color: #8B5E3C;
            font-size: 14px;
        }


        .search-input {
            width: 100%;
            box-sizing: border-box;
            padding: 14px 18px 14px 45px;
            border: 1px solid #E2D8CC;
            border-radius: 12px;
            background: #FCFAF7;
            color: #4B3621;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            outline: none;
            transition: .3s;
        }


        .search-input::placeholder {
            color: #999;
        }


        .search-input:focus {
            background: #fff;
            border-color: #8B5E3C;
            box-shadow: 0 0 0 3px rgba(139,94,60,.08);
        }


        .category-wrapper {
            position: relative;
            min-width: 210px;
        }


        .category-wrapper i {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #8B5E3C;
            font-size: 13px;
            pointer-events: none;
        }


        .category-select {
            width: 100%;
            padding: 14px 38px 14px 42px;
            border: 1px solid #E2D8CC;
            border-radius: 12px;
            background: #FCFAF7;
            color: #4B3621;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            outline: none;
            cursor: pointer;
            transition: .3s;
        }


        .category-select:focus {
            background: #fff;
            border-color: #8B5E3C;
            box-shadow: 0 0 0 3px rgba(139,94,60,.08);
        }


        /* RANGE HARGA */

        .price-filter-wrapper {
            display: flex;
            align-items: center;
            gap: 8px;
            flex: 1 1 280px;
            min-width: 260px;
        }


        .price-input {
            width: 100%;
            min-width: 0;
            box-sizing: border-box;
            padding: 14px 12px;
            border: 1px solid #E2D8CC;
            border-radius: 12px;
            background: #FCFAF7;
            color: #4B3621;
            font-family: 'Poppins', sans-serif;
            font-size: 12px;
            outline: none;
            transition: .3s;
        }


        .price-input::placeholder {
            color: #999;
        }


        .price-input:focus {
            background: #fff;
            border-color: #8B5E3C;
            box-shadow: 0 0 0 3px rgba(139,94,60,.08);
        }


        .price-separator {
            color: #999;
            font-size: 13px;
            flex-shrink: 0;
        }


        .filter-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 14px 21px;
            border: none;
            border-radius: 12px;
            background: #6F4E37;
            color: #fff;
            font-family: 'Poppins', sans-serif;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            white-space: nowrap;
            transition: .3s;
        }


        .filter-button:hover {
            background: #8B5E3C;
            transform: translateY(-1px);
        }


        .reset-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            padding: 14px 18px;
            border-radius: 12px;
            background: #F3E8D8;
            color: #6F4E37;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            white-space: nowrap;
            transition: .3s;
        }


        .reset-button:hover {
            background: #E8D6BE;
        }


        /* JUMLAH HASIL */

        .result-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            margin-bottom: 35px;
        }


        .result-count {
            color: #777;
            font-size: 13px;
        }


        .result-count strong {
            color: #6F4E37;
            font-weight: 600;
        }


        .active-filter {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            padding: 7px 11px;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 500;
        }


        /* KATEGORI */

        .category-section {
            margin-bottom: 55px;
        }


        .category-heading {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
            padding-bottom: 12px;
            border-bottom: 1px solid #E8DED2;
        }


        .category-heading-left {
            display: flex;
            align-items: center;
            gap: 11px;
        }


        .category-icon {
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 9px;
            font-size: 13px;
        }


        .category-heading h2 {
            margin: 0;
            color: #4B3621;
            font-family: 'Cormorant Garamond', serif;
            font-size: 29px;
            line-height: 1;
        }


        .category-total {
            color: #999;
            font-size: 11px;
        }


        /* GRID BUKU */

        .books-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
            align-items: stretch;
        }


        .book-card {
            position: relative;
            background: #FFFFFF;
            border-radius: 18px;
            overflow: hidden;
            border: 1px solid rgba(111,78,55,.07);
            box-shadow: 0 7px 25px rgba(75,54,33,.06);
            display: flex;
            flex-direction: column;
            min-height: 610px;
            transition: transform .3s ease, box-shadow .3s ease;
        }


        .book-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 15px 35px rgba(75,54,33,.12);
        }


        /* TOMBOL WISHLIST */

        .wishlist-card-btn {
            grid-column: 1 / -1;
            width: 100%;
            min-height: 36px;
            margin: 0 0 2px;
            padding: 7px 8px;
            border: 1.5px solid #8B5E3C;
            border-radius: 9px;
            background: #8B5E3C;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            font-family: 'Poppins', sans-serif;
            font-size: 10px;
            line-height: 1.2;
            font-weight: 500;
            cursor: pointer;
            transition: .2s;
        }


        .wishlist-card-btn,
        .wishlist-card-btn span,
        .wishlist-card-btn i {
            color: #fff !important;
        }

        .wishlist-card-btn span {
            font-size: 10px !important;
            font-weight: 500 !important;
            line-height: 1.2 !important;
        }

        .wishlist-card-btn:hover {
            background: #754A30;
            border-color: #754A30;
            color: #fff;
            transform: translateY(-1px);
        }


        .wishlist-card-btn.active {
            color: #fff;
            border-color: #754A30;
            background: #754A30;
        }

        .wishlist-card-btn i {
            font-size: 12px;
        }


        /* COVER BUKU */

        .book-cover-wrapper {
            position: relative;
            width: 100%;
            height: 300px;
            background: #F3E8D8;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }


        .book-cover {
            width: 100%;
            height: 100%;
            object-fit: contain;
            display: block;
            transition: transform .45s ease;
        }


        .book-card:hover .book-cover {
            transform: scale(1.035);
        }


        .book-cover-placeholder {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #6F4E37;
            font-size: 45px;
        }


        /* INFORMASI BUKU */

        .book-info {
            padding: 18px;
            display: flex;
            flex-direction: column;
            flex: 1;
        }


        .book-category {
            display: inline-block;
            width: fit-content;
            max-width: 100%;
            padding: 5px 9px;
            background: #F3E8D8;
            color: #8B5E3C;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 600;
            margin-bottom: 10px;
        }


        .book-title {
            color: #4B3621;
            font-size: 17px;
            line-height: 1.4;
            font-weight: 600;
            margin-bottom: 7px;
            min-height: 48px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }


        .book-author {
            color: #888;
            font-size: 12px;
            line-height: 1.5;
            margin-bottom: 14px;
            min-height: 18px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }


        .book-price {
            color: #6F4E37;
            font-size: 17px;
            font-weight: 700;
            margin-top: auto;
            margin-bottom: 9px;
        }


        .stock {
            font-size: 11px;
            margin-bottom: 14px;
            min-height: 17px;
        }


        .stock.available {
            color: #567A32;
        }


        .stock.empty {
            color: #B23A2B;
            font-weight: 600;
        }


        /* TOMBOL AKSI */

        .book-actions {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-top: 0;
        }


        .detail-button,
        .cart-button {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 40px;
            padding: 10px 8px;
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
            font-size: 11px;
            font-weight: 500;
            transition: .3s;
            box-sizing: border-box;
        }


        .detail-button {
            background: #F3E8D8;
            color: #6F4E37;
            text-decoration: none;
            border: 1px solid #E8D6BE;
        }


        .detail-button:hover {
            background: #E8D6BE;
        }


        .cart-form {
            margin: 0;
            padding: 0;
        }


        .cart-button {
            width: 100%;
            border: none;
            background: #6F4E37;
            color: #FFFFFF;
            cursor: pointer;
        }


        .cart-button:hover {
            background: #8B5E3C;
            transform: translateY(-1px);
        }


        .cart-button.disabled {
            background: #D5D0CA;
            color: #888;
            cursor: not-allowed;
            transform: none;
        }


        /* BUKU KOSONG */

        .empty-books {
            text-align: center;
            padding: 80px 20px;
            background: #fff;
            border-radius: 18px;
            border: 1px solid rgba(111,78,55,.07);
            box-shadow: 0 7px 25px rgba(75,54,33,.05);
            color: #777;
        }


        .empty-books i {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 70px;
            height: 70px;
            margin: 0 auto 18px;
            background: #F3E8D8;
            color: #6F4E37;
            border-radius: 50%;
            font-size: 27px;
        }


        .empty-books h3 {
            color: #4B3621;
            margin: 0 0 8px;
            font-size: 20px;
        }


        .empty-books p {
            margin: 0;
            font-size: 13px;
        }


        /* PAGINATION */

        .lb-pagination {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-top: 40px;
        }


        .lb-pagination a,
        .lb-pagination span {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 38px;
            height: 38px;
            border-radius: 9px;
            font-size: 13px;
            text-decoration: none;
            box-sizing: border-box;
        }


        .lb-pagination a {
            background: #F3E8D8;
            color: #6F4E37;
            transition: .2s;
        }


        .lb-pagination a:hover {
            background: #E8D6BE;
        }


        .lb-pagination .current {
            background: #6F4E37;
            color: #fff;
            font-weight: 600;
        }


        /* RESPONSIVE */

        @media (max-width: 1150px) {

            .books-grid {
                grid-template-columns: repeat(3, 1fr);
            }

        }


        @media (max-width: 900px) {

            .filter-form {
                flex-wrap: wrap;
            }


            .search-wrapper {
                flex-basis: 100%;
            }


            .category-wrapper {
                flex: 1;
            }


            .price-filter-wrapper {
                flex-basis: 100%;
            }


            .filter-button,
            .reset-button {
                flex: 0 0 auto;
            }


            .books-grid {
                grid-template-columns: repeat(2, 1fr);
            }

        }


        @media (max-width: 650px) {

            .books-page {
                padding: 35px 18px 60px;
            }


            .books-header h1 {
                font-size: 43px;
            }


            .books-header p {
                font-size: 13px;
            }


            .filter-box {
                padding: 14px;
            }


            .filter-form {
                flex-direction: column;
                align-items: stretch;
            }


            .search-wrapper,
            .category-wrapper {
                width: 100%;
                min-width: 0;
                flex-basis: auto;
            }


            .price-filter-wrapper {
                width: 100%;
                min-width: 0;
                flex-basis: auto;
            }


            .price-input {
                font-size: 11px;
                padding: 13px 9px;
            }


            .filter-button,
            .reset-button {
                width: 100%;
            }


            .result-bar {
                align-items: flex-start;
                flex-direction: column;
                margin-bottom: 25px;
            }


            .category-heading h2 {
                font-size: 25px;
            }


            .books-grid {
                grid-template-columns: 1fr;
                gap: 18px;
            }


            .book-card {
                min-height: 0;
            }


            .book-cover-wrapper {
                height: 340px;
            }


            .book-actions {
                grid-template-columns: 1fr 1fr;
            }

        }

    </style>

</head>


<body>


<?php include '../includes/navbar_user.php'; ?>


<section class="books-page">


    <!-- TOMBOL KEMBALI -->

    <a
        href="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8'); ?>"
        class="global-back-button"
    >

        <i class="fa-solid fa-arrow-left"></i>

        Kembali

    </a>


    <!-- HEADER -->

    <div class="books-header">

        <h1>Semua Buku</h1>

        <p>
            Temukan bacaan yang sesuai dengan minatmu di LinglungBooks.
        </p>

    </div>


    <!-- PENCARIAN DAN FILTER -->

    <div class="filter-box">

        <form
            method="GET"
            class="filter-form"
        >

            <input
                type="hidden"
                name="back"
                value="<?= htmlspecialchars($back, ENT_QUOTES, 'UTF-8'); ?>"
            >


            <!-- SEARCH -->

            <div class="search-wrapper">

                <i class="fa-solid fa-magnifying-glass"></i>

                <input
                    type="text"
                    name="search"
                    class="search-input"
                    placeholder="Cari judul, penulis, genre, atau penerbit..."
                    value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>"
                >

            </div>


            <!-- KATEGORI -->

            <div class="category-wrapper">

                <i class="fa-solid fa-layer-group"></i>

                <select
                    name="category"
                    class="category-select"
                >

                    <option value="0">
                        Semua Kategori
                    </option>


                    <?php if ($categories): ?>

                        <?php mysqli_data_seek($categories, 0); ?>

                        <?php while ($category = mysqli_fetch_assoc($categories)): ?>

                            <option
                                value="<?= (int) $category['id']; ?>"
                                <?= ($category_id == $category['id']) ? 'selected' : ''; ?>
                            >

                                <?= htmlspecialchars(
                                    $category['category_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>

                            </option>

                        <?php endwhile; ?>

                    <?php endif; ?>

                </select>

            </div>


            <!-- RANGE HARGA -->

            <div class="price-filter-wrapper">

                <input
                    type="number"
                    name="min_price"
                    class="price-input"
                    placeholder="Harga minimum"
                    min="0"
                    value="<?= $min_price !== null ? $min_price : ''; ?>"
                >

                <span class="price-separator">
                    -
                </span>

                <input
                    type="number"
                    name="max_price"
                    class="price-input"
                    placeholder="Harga maksimum"
                    min="0"
                    value="<?= $max_price !== null ? $max_price : ''; ?>"
                >

            </div>


            <!-- TOMBOL CARI -->

            <button
                type="submit"
                class="filter-button"
            >

                <i class="fa-solid fa-magnifying-glass"></i>

                Cari

            </button>


            <!-- RESET -->

            <?php if (
                $search !== ''
                || $category_id > 0
                || $min_price !== null
                || $max_price !== null
            ): ?>

                <a
                    href="books.php?back=<?= urlencode($back); ?>"
                    class="reset-button"
                >

                    <i class="fa-solid fa-rotate-left"></i>

                    Reset

                </a>

            <?php endif; ?>

        </form>

    </div>


    <!-- JUMLAH HASIL -->

    <div class="result-bar">

        <div class="result-count">

            Menampilkan

            <strong><?= $total_books; ?></strong>

            buku

        </div>


        <?php if ($category_id > 0): ?>

            <div class="active-filter">

                <i class="fa-solid fa-layer-group"></i>

                <?= htmlspecialchars(
                    $active_category,
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>

            </div>

        <?php elseif ($search !== ''): ?>

            <div class="active-filter">

                <i class="fa-solid fa-magnifying-glass"></i>

                “<?= htmlspecialchars(
                    $search,
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>”

            </div>

        <?php elseif ($min_price !== null || $max_price !== null): ?>

            <div class="active-filter">

                <i class="fa-solid fa-money-bill-wave"></i>

                Harga:

                <?= $min_price !== null
                    ? 'Rp ' . number_format($min_price, 0, ',', '.')
                    : 'Bebas'; ?>

                -

                <?= $max_price !== null
                    ? 'Rp ' . number_format($max_price, 0, ',', '.')
                    : 'Bebas'; ?>

            </div>

        <?php endif; ?>

    </div>


    <!-- DAFTAR BUKU -->

    <?php if ($total_books > 0): ?>


        <?php foreach ($books_by_category as $category_name => $category_books): ?>


            <section class="category-section">


                <!-- JUDUL KATEGORI -->

                <div class="category-heading">

                    <div class="category-heading-left">

                        <div class="category-icon">

                            <i class="fa-solid fa-book-open"></i>

                        </div>


                        <h2>

                            <?= htmlspecialchars(
                                $category_name,
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </h2>

                    </div>


                    <div class="category-total">

                        <?= count($category_books); ?>

                        buku

                    </div>

                </div>


                <!-- GRID BUKU -->

                <div class="books-grid">


                    <?php foreach ($category_books as $book): ?>


                        <article class="book-card">


                            <!-- COVER BUKU -->

                            <div class="book-cover-wrapper">

                                <?php if (!empty($book['cover'])): ?>

                                    <img
                                        src="../assets/img/<?= htmlspecialchars(
                                            $book['cover'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>"
                                        alt="<?= htmlspecialchars(
                                            $book['title'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>"
                                        class="book-cover"
                                        loading="lazy"
                                    >

                                <?php else: ?>

                                    <div class="book-cover-placeholder">

                                        <i class="fa-solid fa-book"></i>

                                    </div>

                                <?php endif; ?>

                            </div>


                            <!-- INFORMASI BUKU -->

                            <div class="book-info">


                                <div class="book-category">

                                    <?= htmlspecialchars(
                                        $book['category_name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                </div>


                                <div class="book-title">

                                    <?= htmlspecialchars(
                                        $book['title'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                </div>


                                <div class="book-author">

                                    Oleh

                                    <?= htmlspecialchars(
                                        $book['author'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                </div>


                                <div class="book-price">

                                    Rp

                                    <?= number_format(
                                        $book['price'],
                                        0,
                                        ',',
                                        '.'
                                    ); ?>

                                </div>


                                <!-- STOK -->

                                <?php if ((int) $book['stock'] > 0): ?>

                                    <div class="stock available">

                                        Stok tersedia:

                                        <?= (int) $book['stock']; ?>

                                    </div>

                                <?php else: ?>

                                    <div class="stock empty">

                                        Stok habis

                                    </div>

                                <?php endif; ?>


                                <!-- TOMBOL AKSI -->

                                <div class="book-actions">


                                    <!-- WISHLIST -->

                                    <button
                                        type="button"
                                        class="wishlist-card-btn <?= in_array((int) $book['id'], $wishlist_ids, true) ? 'active' : ''; ?>"
                                        data-book-id="<?= (int) $book['id']; ?>"
                                        data-logged-in="<?= $is_logged_in ? '1' : '0'; ?>"
                                        data-login-url="login.php?back=<?= urlencode($current_url); ?>"
                                    >

                                        <i class="fa-<?= in_array((int) $book['id'], $wishlist_ids, true) ? 'solid' : 'regular'; ?> fa-heart"></i>

                                        <span>
                                            <?= in_array((int) $book['id'], $wishlist_ids, true)
                                                ? 'Hapus dari Wishlist'
                                                : 'Tambah ke Wishlist'; ?>
                                        </span>

                                    </button>


                                    <!-- DETAIL -->

                                    <a
                                        href="detail.php?id=<?= (int) $book['id']; ?>&back=<?= urlencode($current_url); ?>"
                                        class="detail-button"
                                    >

                                        <i class="fa-solid fa-eye"></i>

                                        Detail

                                    </a>


                                    <!-- KERANJANG -->

                                    <?php if ((int) $book['stock'] > 0): ?>

                                        <form
                                            method="POST"
                                            class="cart-form"
                                        >

                                            <input
                                                type="hidden"
                                                name="book_id"
                                                value="<?= (int) $book['id']; ?>"
                                            >

                                            <button
                                                type="submit"
                                                name="add_to_cart"
                                                class="cart-button"
                                            >

                                                <i class="fa-solid fa-cart-plus"></i>

                                                Keranjang

                                            </button>

                                        </form>

                                    <?php else: ?>

                                        <button
                                            type="button"
                                            class="cart-button disabled"
                                            disabled
                                        >

                                            <i class="fa-solid fa-ban"></i>

                                            Habis

                                        </button>

                                    <?php endif; ?>


                                </div>


                            </div>


                        </article>


                    <?php endforeach; ?>


                </div>


            </section>


        <?php endforeach; ?>


    <?php else: ?>


        <!-- JIKA BUKU TIDAK DITEMUKAN -->

        <div class="empty-books">

            <i class="fa-solid fa-book-open"></i>

            <h3>Buku Tidak Ditemukan</h3>

            <p>
                Coba gunakan kata kunci, kategori, atau rentang harga yang berbeda.
            </p>

        </div>


    <?php endif; ?>


    <!-- PAGINATION -->

    <?php if ($total_pages > 1): ?>

        <nav
            class="lb-pagination"
            aria-label="Navigasi halaman buku"
        >

            <?php
                $page_params = $_GET;
                unset($page_params['page']);
            ?>


            <?php if ($page > 1): ?>

                <?php $page_params['page'] = $page - 1; ?>

                <a
                    href="?<?= htmlspecialchars(
                        http_build_query($page_params),
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>"
                    aria-label="Halaman sebelumnya"
                >

                    &laquo;

                </a>

            <?php endif; ?>


            <?php for (
                $i = max(1, $page - 2);
                $i <= min($total_pages, $page + 2);
                $i++
            ): ?>

                <?php $page_params['page'] = $i; ?>


                <?php if ($i === $page): ?>

                    <span class="current">
                        <?= $i; ?>
                    </span>

                <?php else: ?>

                    <a
                        href="?<?= htmlspecialchars(
                            http_build_query($page_params),
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                    >

                        <?= $i; ?>

                    </a>

                <?php endif; ?>


            <?php endfor; ?>


            <?php if ($page < $total_pages): ?>

                <?php $page_params['page'] = $page + 1; ?>

                <a
                    href="?<?= htmlspecialchars(
                        http_build_query($page_params),
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>"
                    aria-label="Halaman berikutnya"
                >

                    &raquo;

                </a>

            <?php endif; ?>

        </nav>

    <?php endif; ?>


</section>


<?php include '../includes/footer_user.php'; ?>


<!-- SCRIPT BACK BUTTON -->

<script src="../assets/js/back-button.js"></script>


<!-- SCRIPT WISHLIST -->

<script>

document.querySelectorAll('.wishlist-card-btn').forEach(button => {

    button.addEventListener('click', async () => {

        if (button.dataset.loggedIn !== '1') {

            window.location.href = button.dataset.loginUrl;

            return;
        }


        const body = new URLSearchParams({
            book_id: button.dataset.bookId
        });


        try {

            const response = await fetch(
                'wishlist_toggle.php',
                {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body
                }
            );


            const result = await response.json();


            if (result.login) {

                window.location.href = button.dataset.loginUrl;

                return;
            }


            if (!result.success) {

                alert(result.message || 'Wishlist gagal diperbarui.');

                return;
            }


            button.classList.toggle(
                'active',
                result.active
            );


            button.querySelector('i').className =
                (result.active ? 'fa-solid' : 'fa-regular') +
                ' fa-heart';


            button.querySelector('span').textContent =
                result.active
                    ? 'Hapus dari Wishlist'
                    : 'Tambah ke Wishlist';


        } catch (error) {

            alert('Tidak dapat menghubungi server. Coba lagi.');

        }

    });

});

</script>


<script
    src="../assets/js/enhancements.js"
    defer
></script>


</body>
</html>