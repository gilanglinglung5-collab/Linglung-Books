<?php
if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}
include '../config/database.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'user') {
    header('Location: login.php?back=profile.php');
    exit;
}

$user_id = (int) $_SESSION['user_id'];
$message = '';
$message_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    $fullname = trim($_POST['fullname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($fullname === '' || mb_strlen($fullname) > 100) {
        $message = 'Nama lengkap wajib diisi dan maksimal 100 karakter.';
        $message_type = 'error';
    } elseif ($phone === '' || strlen($phone) > 20 || $address === '' || mb_strlen($address) > 2000) {
        $message = 'Nomor telepon dan alamat wajib diisi. Alamat maksimal 2000 karakter.';
        $message_type = 'error';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $message = 'Masukkan alamat email yang valid.';
        $message_type = 'error';
    } else {
        $check = mysqli_prepare($conn, 'SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1');
        mysqli_stmt_bind_param($check, 'si', $email, $user_id);
        mysqli_stmt_execute($check);
        $duplicate = mysqli_stmt_get_result($check);

        if ($duplicate && mysqli_num_rows($duplicate) > 0) {
            $message = 'Email tersebut sudah digunakan akun lain.';
            $message_type = 'error';
        } else {
            $update = mysqli_prepare($conn, "UPDATE users SET fullname = ?, email = ?, phone = ?, address = ? WHERE id = ? AND role = 'user'");
            mysqli_stmt_bind_param($update, 'ssssi', $fullname, $email, $phone, $address, $user_id);
            if (mysqli_stmt_execute($update)) {
                $_SESSION['fullname'] = $fullname;
                $message = 'Profil berhasil diperbarui.';
            } else {
                $message = 'Profil belum berhasil diperbarui. Silakan coba lagi.';
                $message_type = 'error';
            }
            mysqli_stmt_close($update);
        }
        mysqli_stmt_close($check);
    }
}

$stmt = mysqli_prepare($conn, "SELECT fullname, email, username, phone, address FROM users WHERE id = ? AND role = 'user' LIMIT 1");
mysqli_stmt_bind_param($stmt, 'i', $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = $result ? mysqli_fetch_assoc($result) : null;
mysqli_stmt_close($stmt);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya | LinglungBooks</title>
    <link rel="stylesheet" href="../assets/css/user.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        .profile-page{max-width:1000px;margin:55px auto 80px;padding:0 24px;font-family:'Poppins',sans-serif;color:#4B3621}
        .profile-heading{margin-bottom:28px}
        .profile-heading h1{font-family:'Cormorant Garamond',serif;font-size:46px;color:#6F4E37;margin:0 0 8px}
        .profile-heading p{color:#806D5D;font-size:14px}
        .profile-card{display:grid;grid-template-columns:280px minmax(0,1fr);background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 12px 35px rgba(75,54,33,.09)}
        .profile-side{background:#F3E8D8;padding:38px 26px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center}
        .profile-avatar{width:100px;height:100px;border-radius:50%;background:#6F4E37;color:#fff;display:flex;align-items:center;justify-content:center;font-size:38px;margin-bottom:18px;box-shadow:0 8px 20px rgba(75,54,33,.16)}
        .profile-side h2{font-size:19px;margin-bottom:6px;overflow-wrap:anywhere}
        .profile-side p{font-size:13px;color:#806D5D;overflow-wrap:anywhere}
        .profile-form{padding:38px}
        .profile-form h2{font-size:20px;margin-bottom:24px}
        .profile-field{margin-bottom:20px}
        .profile-field label{display:block;font-size:13px;font-weight:600;margin-bottom:8px}
        .profile-field input{width:100%;padding:13px 15px;border:1px solid #D8C8B8;border-radius:10px;background:#FFFDF9;color:#4B3621;font:14px 'Poppins',sans-serif;outline:none}
        .profile-field input:focus{border-color:#8B5E3C;box-shadow:0 0 0 3px rgba(139,94,60,.1)}
        .profile-field input[readonly]{background:#F4F1ED;color:#887B70;cursor:not-allowed}
        .profile-help{font-size:12px;color:#8B7B6C;margin-top:7px}
        .profile-alert{padding:13px 15px;border-radius:10px;margin-bottom:20px;font-size:13px;background:#EAF5EA;color:#27632A}
        .profile-alert.error{background:#FCE8E6;color:#A12622}
        .profile-actions{display:flex;justify-content:flex-end;gap:12px;margin-top:28px;flex-wrap:wrap}
        .profile-button{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:12px 18px;border-radius:10px;text-decoration:none;border:0;font:600 13px 'Poppins',sans-serif;cursor:pointer}
        .profile-button.primary{background:#6F4E37;color:white}.profile-button.primary:hover{background:#4B3621}
        .profile-button.secondary{background:#F3E8D8;color:#6F4E37}
        @media(max-width:700px){.profile-card{grid-template-columns:1fr}.profile-side{padding:30px 20px}.profile-form{padding:28px 22px}.profile-heading h1{font-size:38px}.profile-actions{flex-direction:column}.profile-button{width:100%}}
    </style>
    <link rel="stylesheet" href="../assets/css/enhancements.css">
    <link rel="stylesheet" href="../assets/css/back-button.css">
</head>
<body>
<?php include '../includes/navbar_user.php'; ?>
<main class="profile-page">
    <header class="profile-heading">
        <h1>Profil Saya</h1>
        <p>Kelola informasi akun LinglungBooks kamu di sini.</p>
    </header>
    <section class="profile-card">
        <aside class="profile-side">
            <div class="profile-avatar"><i class="fa-solid fa-user"></i></div>
            <h2><?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?></h2>
            <p>@<?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?></p>
        </aside>
        <div class="profile-form">
            <h2>Informasi Akun</h2>
            <?php if ($message !== ''): ?>
                <div class="profile-alert <?= $message_type === 'error' ? 'error' : ''; ?>"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="profile-field">
                    <label for="fullname">Nama lengkap</label>
                    <input id="fullname" name="fullname" type="text" maxlength="100" value="<?= htmlspecialchars($user['fullname'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="profile-field">
                    <label for="email">Alamat email</label>
                    <input id="email" name="email" type="email" maxlength="150" value="<?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="profile-field">
                    <label for="phone">Nomor telepon</label>
                    <input id="phone" name="phone" type="tel" maxlength="20" value="<?= htmlspecialchars($user['phone'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                </div>
                <div class="profile-field">
                    <label for="address">Alamat pengiriman</label>
                    <textarea id="address" name="address" rows="4" maxlength="2000" required style="width:100%;padding:13px 15px;border:1px solid #D8C8B8;border-radius:10px;background:#FFFDF9;color:#4B3621;font:14px 'Poppins',sans-serif;resize:vertical;box-sizing:border-box;"><?= htmlspecialchars($user['address'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
                </div>
                <div class="profile-field">
                    <label for="username">Username</label>
                    <input id="username" type="text" value="<?= htmlspecialchars($user['username'], ENT_QUOTES, 'UTF-8'); ?>" readonly>
                    <p class="profile-help">Username saat ini belum bisa diubah.</p>
                </div>
                <div class="profile-actions">
                    <a class="profile-button secondary global-back-button" href="logout.php" onclick="return confirm('Yakin ingin keluar dari akun?');"><i class="fa-solid fa-right-from-bracket"></i> Keluar</a>
                    <a class="profile-button secondary" href="dashboard.php"><i class="fa-solid fa-arrow-left"></i> Kembali ke Beranda</a>
                    <button class="profile-button primary" type="submit" name="save_profile"><i class="fa-solid fa-floppy-disk"></i> Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </section>
</main>
<?php include '../includes/footer_user.php'; ?>
    <script src="../assets/js/enhancements.js" defer></script>
</body>
</html>
