<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}


/* =========================
   TENTUKAN HALAMAN SEBELUMNYA
========================= */

$default_back = 'dashboard.php';

$back = $_GET['back'] ?? $default_back;


/* =========================
   NORMALISASI INDEX
========================= */

if ($back === 'index.php') {
    $back = '../index.php';
}


/* =========================
   VALIDASI HALAMAN KEMBALI
========================= */

$back_path = parse_url($back, PHP_URL_PATH);

$allowed_back_pages = [
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$is_root_index = ($back === '../index.php');

$is_safe_back =
    $is_root_index ||
    (
        strpos($back, '://') === false &&
        strpos($back, '//') !== 0 &&
        strpos($back, '..') === false &&
        in_array(
            basename($back_path ?: ''),
            $allowed_back_pages,
            true
        )
    );

if (!$is_safe_back) {
    $back = $default_back;
}


/* =========================
   WAJIB LOGIN
========================= */

if (!isset($_SESSION['user_id'])) {

    header(
        "Location: login.php?back=" .
        urlencode($back)
    );

    exit;
}


include '../config/database.php';


/* =========================
   VALIDASI ORDER ID
========================= */

if (
    !isset($_GET['id']) ||
    !is_numeric($_GET['id'])
) {

    header(
        "Location: orders.php?back=" .
        urlencode($back)
    );

    exit;
}


$order_id = (int) $_GET['id'];

$user_id = (int) $_SESSION['user_id'];


/* =========================
   AMBIL DATA ORDER
========================= */

$orderQuery = mysqli_query(
    $conn,
    "
    SELECT *
    FROM orders
    WHERE id = '$order_id'
    AND user_id = '$user_id'
    LIMIT 1
    "
);


$order = $orderQuery
    ? mysqli_fetch_assoc($orderQuery)
    : null;


if (!$order) {

    header(
        "Location: orders.php?back=" .
        urlencode($back)
    );

    exit;
}


/* =========================
   AMBIL DETAIL PESANAN
========================= */

$detailQuery = mysqli_query(
    $conn,
    "
    SELECT
        order_details.*,
        books.title,
        books.cover
    FROM order_details
    JOIN books
        ON order_details.book_id = books.id
    WHERE order_details.order_id = '$order_id'
    "
);


/* =========================
   HITUNG TOTAL
========================= */

$total = 0;

$items = [];

if ($detailQuery) {

    while ($item = mysqli_fetch_assoc($detailQuery)) {

        $subtotal =
            $item['price'] *
            $item['quantity'];

        $total += $subtotal;

        $items[] = [
            'title' => $item['title'],
            'cover' => $item['cover'],
            'price' => $item['price'],
            'quantity' => $item['quantity'],
            'subtotal' => $subtotal
        ];
    }
}


/* =========================
   PAYMENT PROOF
========================= */

$payment_proof = $order['payment_proof'] ?? '';

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <!-- KODE TRANSAKSI: kode publik dicetak pada judul struk. -->
Struk Pesanan #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order['id'], ENT_QUOTES, 'UTF-8'); ?> | LinglungBooks
    </title>


    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;500;600&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Poppins, sans-serif;
        }


        body {
            background: #F8F3EC;
            color: #3E2C23;
            min-height: 100vh;
            padding: 40px 20px;
        }


        /* =========================
           CONTAINER
        ========================= */

        .receipt-wrapper {
            width: 100%;
            max-width: 850px;
            margin: 0 auto;
        }


        /* =========================
           RECEIPT
        ========================= */

        .receipt {
            background: #FFFFFF;

            border-radius: 22px;

            padding: 45px;

            box-shadow:
                0 15px 40px rgba(75, 54, 33, 0.10);

            position: relative;
        }


        /* =========================
           HEADER
        ========================= */

        .receipt-header {
            text-align: center;

            padding-bottom: 25px;

            border-bottom: 2px dashed #D8C6B5;
        }


        .logo {
            font-family: 'Cormorant Garamond', serif;

            font-size: 45px;

            font-weight: 700;

            color: #4B3621;
        }


        .logo span {
            color: #8B5E3C;
        }


        .receipt-title {
            margin-top: 5px;

            font-size: 16px;

            color: #777;
        }


        /* =========================
           ORDER INFO
        ========================= */

        .order-info {
            display: grid;

            grid-template-columns: 1fr 1fr;

            gap: 20px;

            padding: 25px 0;

            border-bottom: 1px solid #E8DDD2;
        }


        .info-box h4 {
            color: #8B5E3C;

            font-size: 13px;

            margin-bottom: 5px;

            text-transform: uppercase;

            letter-spacing: .5px;
        }


        .info-box p {
            font-size: 14px;

            line-height: 1.6;
        }


        /* =========================
           CUSTOMER
        ========================= */

        .customer {
            padding: 25px 0;

            border-bottom: 1px solid #E8DDD2;
        }


        .section-title {
            font-size: 18px;

            font-weight: 600;

            color: #4B3621;

            margin-bottom: 15px;
        }


        .customer p {
            font-size: 14px;

            line-height: 1.7;
        }


        .customer strong {
            color: #4B3621;
        }


        .address {
            white-space: pre-line;
        }


        /* =========================
           ITEMS
        ========================= */

        .items {
            padding: 25px 0;

            border-bottom: 1px solid #E8DDD2;
        }


        .item {
            display: flex;

            align-items: center;

            gap: 15px;

            padding: 15px 0;

            border-bottom: 1px solid #F0E8E0;
        }


        .item:last-child {
            border-bottom: none;
        }


        .book-cover {
            width: 65px;

            height: 85px;

            object-fit: contain;

            border-radius: 6px;

            background: #F7F1EB;
        }


        .no-cover {
            width: 65px;

            height: 85px;

            display: flex;

            align-items: center;

            justify-content: center;

            background: #F7F1EB;

            border-radius: 6px;

            color: #8B5E3C;

            font-size: 25px;
        }


        .item-info {
            flex: 1;
        }


        .item-title {
            font-weight: 600;

            color: #4B3621;

            margin-bottom: 5px;
        }


        .item-detail {
            font-size: 13px;

            color: #777;
        }


        .item-subtotal {
            font-weight: 600;

            color: #6F4E37;

            white-space: nowrap;
        }


        /* =========================
           TOTAL
        ========================= */

        .total-section {
            padding: 25px 0;

            border-bottom: 2px dashed #D8C6B5;
        }


        .total-row {
            display: flex;

            justify-content: space-between;

            align-items: center;
        }


        .total-label {
            font-size: 18px;

            font-weight: 600;

            color: #4B3621;
        }


        .total-value {
            font-size: 25px;

            font-weight: 600;

            color: #8B5E3C;
        }


        /* =========================
           PAYMENT
        ========================= */

        .payment {
            padding: 25px 0;

            border-bottom: 1px solid #E8DDD2;
        }


        .payment-method {
            display: inline-flex;

            align-items: center;

            gap: 8px;

            background: #F3E8D8;

            color: #6F4E37;

            padding: 9px 17px;

            border-radius: 20px;

            font-size: 14px;

            margin-bottom: 12px;
        }


        .payment p {
            font-size: 14px;

            line-height: 1.7;
        }


        .proof {
            margin-top: 12px;

            color: #557A55;
        }


        /* =========================
           STATUS
        ========================= */

        .status-box {
            padding: 20px 0;

            text-align: center;
        }


        .status {
            display: inline-block;

            padding: 9px 20px;

            background: #F3E8D8;

            border-radius: 25px;

            color: #6F4E37;

            font-size: 14px;

            font-weight: 500;
        }


        /* =========================
           BUTTON
        ========================= */

        .actions {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 25px;
        }


        .back-button,
        .pdf-button {
            display: inline-flex;

            align-items: center;

            justify-content: center;

            gap: 8px;

            background: #6F4E37;

            color: white;

            text-decoration: none;

            padding: 13px 28px;

            border-radius: 30px;

            transition: .3s;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }

        .pdf-button {
            background: #4B3621;
        }

        .back-button:hover,
        .pdf-button:hover {
            background: #8B5E3C;
            transform: translateY(-2px);
        }

        /* =========================
           CETAK / SIMPAN PDF
        ========================= */
        @page {
            size: A4;
            margin: 7mm;
        }

        @media print {
            html, body {
                background: #FFFFFF !important;
                color: #3E2C23 !important;
                padding: 0 !important;
                margin: 0 !important;
                min-height: auto !important;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }

            /* Perkecil keseluruhan struk agar lebih mudah muat satu halaman. */
            .receipt-wrapper {
                width: 100% !important;
                max-width: none !important;
                margin: 0 !important;
                zoom: .78;
            }

            .receipt {
                box-shadow: none !important;
                border: 1px solid #E8DDD2 !important;
                border-radius: 0 !important;
                padding: 6mm !important;
            }

            .receipt-header {
                padding-bottom: 9px !important;
                border-bottom-width: 1px !important;
            }

            .logo {
                font-size: 27px !important;
                line-height: 1.05 !important;
            }

            .receipt-title {
                margin-top: 2px !important;
                font-size: 10px !important;
            }

            .order-info {
                gap: 12px !important;
                padding: 9px 0 !important;
            }

            .info-box h4 {
                font-size: 8px !important;
                margin-bottom: 2px !important;
            }

            .info-box p,
            .customer p,
            .payment p {
                font-size: 9px !important;
                line-height: 1.35 !important;
            }

            .customer,
            .items,
            .payment {
                padding: 10px 0 !important;
            }

            .section-title {
                font-size: 11px !important;
                margin-bottom: 6px !important;
            }

            .item {
                gap: 8px !important;
                padding: 5px 0 !important;
            }

            .book-cover,
            .no-cover {
                width: 34px !important;
                height: 46px !important;
                border-radius: 3px !important;
            }

            .no-cover {
                font-size: 15px !important;
            }

            .item-title {
                font-size: 9px !important;
                margin-bottom: 1px !important;
            }

            .item-detail {
                font-size: 8px !important;
            }

            .item-subtotal {
                font-size: 9px !important;
            }

            .total-section {
                padding: 10px 0 !important;
                border-bottom-width: 1px !important;
            }

            .total-label {
                font-size: 11px !important;
            }

            .total-value {
                font-size: 15px !important;
            }

            .payment-method {
                padding: 4px 9px !important;
                margin-bottom: 5px !important;
                font-size: 9px !important;
            }

            .proof {
                margin-top: 4px !important;
            }

            .status-box {
                padding: 8px 0 !important;
            }

            .status {
                padding: 5px 12px !important;
                font-size: 9px !important;
            }

            .receipt-footer {
                margin-top: 8px !important;
                font-size: 8px !important;
            }

            .actions {
                display: none !important;
            }

            .item,
            .info-box,
            .total-section,
            .payment,
            .status-box {
                break-inside: avoid;
                page-break-inside: avoid;
            }

            a {
                color: inherit !important;
                text-decoration: none !important;
            }
        }


        /* =========================
           FOOTER
        ========================= */

        .receipt-footer {
            text-align: center;

            margin-top: 25px;

            color: #999;

            font-size: 12px;
        }


        /* =========================
           MOBILE
        ========================= */

        @media (max-width: 650px) {

            body {
                padding: 20px 12px;
            }


            .receipt {
                padding: 25px 20px;

                border-radius: 16px;
            }


            .logo {
                font-size: 36px;
            }


            .order-info {
                grid-template-columns: 1fr;

                gap: 12px;
            }


            .item {
                align-items: flex-start;
            }


            .item-subtotal {
                font-size: 13px;
            }


            .total-row {
                gap: 15px;
            }


            .total-label {
                font-size: 16px;
            }


            .total-value {
                font-size: 20px;
            }


            .back-button,
            .pdf-button {
                width: 100%;
            }

        }

    </style>

<link rel="stylesheet" href="../assets/css/back-button.css">
    <link rel="stylesheet" href="../assets/css/enhancements.css">
</head>


<body>


<div class="receipt-wrapper">


    <div class="receipt">


        <!-- =========================
             HEADER
        ========================= -->

        <div class="receipt-header">

            <div class="logo">

                Linglung <span>Books</span>

            </div>

            <div class="receipt-title">

                Struk Pesanan

            </div>

        </div>


        <!-- =========================
             ORDER INFO
        ========================= -->

        <div class="order-info">


            <div class="info-box">

                <h4>
                    Nomor Pesanan
                </h4>

                <p>
                    #<?= htmlspecialchars($order['transaction_code'] ?? (string) $order['id'], ENT_QUOTES, 'UTF-8'); ?>
                </p>

            </div>


            <div class="info-box">

                <h4>
                    Tanggal Pesanan
                </h4>

                <p>
                    <?= htmlspecialchars(
                        $order['created_at']
                    ); ?>
                </p>

            </div>


        </div>


        <!-- =========================
             CUSTOMER
        ========================= -->

        <div class="customer">


            <div class="section-title">

                Informasi Penerima

            </div>


            <p>

                <strong>Nama:</strong>

                <?= htmlspecialchars(
                    $order['recipient_name']
                ); ?>

            </p>


            <p>

                <strong>No. Telepon:</strong>

                <?= htmlspecialchars(
                    $order['phone']
                ); ?>

            </p>


            <p>

                <strong>Alamat:</strong>

                <span class="address">

                    <?= htmlspecialchars(
                        $order['address']
                    ); ?>

                </span>

            </p>


        </div>


        <!-- =========================
             ITEMS
        ========================= -->

        <div class="items">


            <div class="section-title">

                Detail Pembelian

            </div>


            <?php foreach ($items as $item): ?>


                <div class="item">


                    <?php if (!empty($item['cover'])): ?>

                        <img
                            src="../assets/img/<?= htmlspecialchars(
                                $item['cover']
                            ); ?>"
                            alt="<?= htmlspecialchars(
                                $item['title']
                            ); ?>"
                            class="book-cover"
                        >

                    <?php else: ?>

                        <div class="no-cover">

                            <i class="fa-solid fa-book"></i>

                        </div>

                    <?php endif; ?>


                    <div class="item-info">


                        <div class="item-title">

                            <?= htmlspecialchars(
                                $item['title']
                            ); ?>

                        </div>


                        <div class="item-detail">

                            Rp<?= number_format(
                                $item['price'],
                                0,
                                ",",
                                "."
                            ); ?>

                            ×

                            <?= (int) $item['quantity']; ?>

                        </div>


                    </div>


                    <div class="item-subtotal">

                        Rp<?= number_format(
                            $item['subtotal'],
                            0,
                            ",",
                            "."
                        ); ?>

                    </div>


                </div>


            <?php endforeach; ?>


        </div>


        <!-- =========================
             TOTAL
        ========================= -->

        <div class="total-section">


            <div class="total-row">


                <div class="total-label">

                    Total Pembayaran

                </div>


                <div class="total-value">

                    Rp<?= number_format(
                        $total,
                        0,
                        ",",
                        "."
                    ); ?>

                </div>


            </div>


        </div>


        <!-- =========================
             PAYMENT
        ========================= -->

        <div class="payment">


            <div class="section-title">

                Pembayaran

            </div>


            <div class="payment-method">

                <i class="fa-solid fa-wallet"></i>

                <?= htmlspecialchars(match ($order['payment_method'] ?? '') { 'Transfer' => 'Transfer Bank', 'DANA' => 'DANA', 'GoPay' => 'GoPay', 'QRIS' => 'QRIS', default => 'COD' }, ENT_QUOTES, 'UTF-8'); ?>

            </div>


            <?php if (
                !empty($payment_proof)
            ): ?>

                <p class="proof">

                    <i class="fa-solid fa-circle-check"></i>

                    Bukti pembayaran telah diunggah.

                </p>

            <?php elseif (
                strtolower(
                    $order['payment_method']
                ) === 'cod'
            ): ?>

                <p>

                    Pembayaran dilakukan saat pesanan
                    diterima.

                </p>

            <?php endif; ?>


        </div>


        <!-- =========================
             STATUS
        ========================= -->

        <div class="status-box">


            <div class="status">

                <i class="fa-solid fa-circle-info"></i>

                Status:

                <?= htmlspecialchars(
                    $order['status']
                ); ?>

            </div>


        </div>


        <!-- =========================
             ACTION
        ========================= -->

        <div class="actions">


            <button
                type="button"
                class="pdf-button"
                onclick="saveReceiptAsPDF()"
            >
                <i class="fa-solid fa-file-pdf"></i>
                Simpan sebagai PDF
            </button>

            <a
                href="<?= htmlspecialchars(
                    $back,
                    ENT_QUOTES,
                    'UTF-8'
                ); ?>"
                class="global-back-button"
            >
                <i class="fa-solid fa-arrow-left"></i>
                Kembali
            </a>


        </div>


    </div>


    <div class="receipt-footer">

        Terima kasih telah berbelanja di
        LinglungBooks.

    </div>


</div>


<script>
    function saveReceiptAsPDF() {
        window.print();
    }
</script>

<script src="../assets/js/back-button.js"></script>
    <script src="../assets/js/enhancements.js" defer></script>
</body>

</html>