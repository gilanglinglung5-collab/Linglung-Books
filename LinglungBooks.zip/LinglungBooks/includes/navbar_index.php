<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') !== 'user') {
    unset($_SESSION['user_id'], $_SESSION['fullname'], $_SESSION['username'], $_SESSION['role']);
}
$is_logged_in = isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'user';


/* =========================================================
   LINK LANDING PAGE
   index.php berada di ROOT
========================================================= */

$home_link = 'index.php';

$back_from_index = urlencode('../index.php');

$books_link    = 'user/books.php?back=' . $back_from_index;
$about_link    = 'user/about.php?back=' . $back_from_index;
$contact_link  = 'user/contact.php?back=' . $back_from_index;
$login_link    = 'user/login.php?back=' . $back_from_index;
$register_link = 'user/register.php?back=' . $back_from_index;

?>

<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>

<style>

/* Hilangkan ruang putih bawaan browser di atas navbar pada semua halaman */
html,
body {
    margin: 0 !important;
    padding: 0 !important;
}


.lb-navbar {
    width: 100%;
    background: #F8F3EC;
    border-bottom: 1px solid rgba(75, 54, 33, 0.12);
    position: relative;
    z-index: 1000;
    font-family: 'Poppins', sans-serif;
}

.lb-nav-container {
    max-width: 1450px;
    margin: 0 auto;
    padding: 18px 35px;
    display: flex;
    align-items: center;
    gap: 38px;
}

.lb-logo {
    text-decoration: none;
    color: #4B3621;
    font-family: 'Cormorant Garamond', serif;
    font-size: 35px;
    font-weight: 700;
    white-space: nowrap;
    flex-shrink: 0;
    transition: 0.3s ease;
}

.lb-logo span {
    color: #8B5E3C;
}

.lb-logo:hover {
    opacity: 0.75;
}

.lb-nav-menu {
    display: flex;
    align-items: center;
    gap: 30px;
    flex: 1;
}

.lb-nav-text {
    position: relative;
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #4B3621;
    font-size: 14px;
    font-weight: 500;
    white-space: nowrap;
    padding: 10px 0;
    transition: 0.3s ease;
}

.lb-nav-text:hover {
    color: #8B5E3C;
}

.lb-nav-text.active {
    color: #8B5E3C;
    font-weight: 600;
}

.lb-nav-text.active::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background: #8B5E3C;
    border-radius: 10px;
}

.lb-nav-icon {
    position: relative;
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: #4B3621;
    border-radius: 10px;
    transition: 0.3s ease;
}

.lb-nav-icon i {
    font-size: 18px;
}

.lb-nav-icon:hover {
    background: #F3E8D8;
    color: #8B5E3C;
}

.lb-nav-icon::after {
    content: attr(data-tooltip);
    position: absolute;
    top: 50px;
    left: 50%;
    transform: translateX(-50%);
    background: #4B3621;
    color: #FFFFFF;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 11px;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.2s ease;
}

.lb-nav-icon:hover::after {
    opacity: 1;
}

.lb-nav-account {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-shrink: 0;
}

.lb-login {
    text-decoration: none;
    color: #6F4E37;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 5px;
    white-space: nowrap;
    transition: 0.3s ease;
}

.lb-login:hover {
    color: #4B3621;
}

.lb-register {
    text-decoration: none;
    background: #6F4E37;
    color: #FFFFFF;
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    transition: 0.3s ease;
}

.lb-register:hover {
    background: #4B3621;
}

@media (max-width: 1200px) {

    .lb-nav-container {
        padding: 17px 25px;
        gap: 25px;
    }

    .lb-nav-menu {
        gap: 20px;
    }

    .lb-nav-text {
        font-size: 13px;
    }
}

@media (max-width: 950px) {

    .lb-nav-container {
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }

    .lb-logo {
        width: 100%;
        text-align: center;
    }

    .lb-nav-menu {
        width: 100%;
        justify-content: center;
        flex-wrap: wrap;
        gap: 18px;
    }

    .lb-nav-account {
        justify-content: center;
    }
}

@media (max-width: 600px) {

    .lb-nav-container {
        padding: 15px;
    }

    .lb-logo {
        font-size: 30px;
    }

    .lb-nav-menu {
        gap: 12px;
    }

    .lb-nav-text {
        font-size: 12px;
    }

    .lb-nav-icon {
        width: 38px;
        height: 38px;
    }

    .lb-nav-icon i {
        font-size: 15px;
    }

    .lb-login {
        font-size: 12px;
    }

    .lb-register {
        font-size: 12px;
        padding: 8px 12px;
    }
}

</style>


<nav class="lb-navbar">

    <div class="lb-nav-container">

        <!-- LOGO -->

        <a href="<?= $home_link ?>" class="lb-logo">
            Linglung<span>Books</span>
        </a>


        <!-- MENU -->

        <div class="lb-nav-menu">

            <a
                href="<?= $home_link ?>"
                class="lb-nav-text active"
            >
                Beranda
            </a>


            <a
                href="<?= $books_link ?>"
                class="lb-nav-text"
            >
                Buku
            </a>


            <a
                href="<?= $about_link ?>"
                class="lb-nav-text"
            >
                Tentang Kami
            </a>


            <a
                href="<?php echo $is_logged_in ? 'user/wishlist.php' : 'user/login.php?back=wishlist.php'; ?>"
                class="lb-nav-icon"
                data-tooltip="Wishlist"
                aria-label="Wishlist (login diperlukan)"
            >
                <i class="fa-regular fa-heart"></i>
            </a>


            <a
                href="<?= $contact_link ?>"
                class="lb-nav-icon"
                data-tooltip="Kontak"
            >
                <i class="fa-solid fa-envelope"></i>
            </a>

        </div>


        <!-- AKUN -->

        <div class="lb-nav-account">

            <?php if ($is_logged_in): ?>
                <a href="user/dashboard.php" class="lb-login" title="Dashboard pengguna">
                    <i class="fa-solid fa-user"></i>
                    <?= htmlspecialchars($_SESSION['fullname'] ?? 'Pengguna', ENT_QUOTES, 'UTF-8'); ?>
                </a>
                <a href="user/logout.php" class="lb-register">Keluar</a>
            <?php else: ?>
                <a href="<?= $login_link ?>" class="lb-login">Login</a>
                <a href="<?= $register_link ?>" class="lb-register">Daftar</a>
            <?php endif; ?>

        </div>

    </div>

</nav>