<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}

$is_logged_in = isset($_SESSION['user_id']);


/* =========================================================
   HALAMAN SEKARANG
========================================================= */

$current_url = basename($_SERVER['PHP_SELF']);

$current_query = $_SERVER['QUERY_STRING'] ?? '';

if ($current_query !== '') {

    parse_str($current_query, $query_params);

    unset($query_params['back']);

    if (!empty($query_params)) {
        $current_url .= '?' . http_build_query($query_params);
    }
}


/* =========================================================
   HALAMAN SEBELUMNYA
========================================================= */

$back = $_GET['back'] ?? 'dashboard.php';

if ($back === '') {
    $back = 'dashboard.php';
}


/* =========================================================
   LINK BERANDA
========================================================= */

$home_link = ($back === 'index.php')
    ? '../index.php'
    : 'dashboard.php';


/* =========================================================
   LINK FOOTER
========================================================= */

$back_for_link = urlencode($current_url);

$books_link    = 'books.php?back=' . $back_for_link;
$about_link    = 'about.php?back=' . $back_for_link;
$contact_link  = 'contact.php?back=' . $back_for_link;
$messages_link = 'messages.php?back=' . $back_for_link;
$cart_link     = 'cart.php?back=' . $back_for_link;
$orders_link   = 'orders.php?back=' . $back_for_link;

$login_link    = 'login.php?back=' . $back_for_link;
$register_link = 'register.php?back=' . $back_for_link;
$logout_link   = 'logout.php';

?>

<style>

.lb-footer {
    margin-top: 80px;
    background: #4B3621;
    color: #F8F3EC;
    font-family: 'Poppins', sans-serif;
}

.lb-footer-container {
    max-width: 1350px;
    margin: 0 auto;
    padding: 60px 35px 50px;
    display: grid;
    grid-template-columns: 1.7fr 1fr 1fr 1.2fr;
    gap: 55px;
}

.lb-footer-brand {
    display: flex;
    flex-direction: column;
}

.lb-footer-logo {
    display: inline-block;
    width: fit-content;
    margin-bottom: 16px;
    text-decoration: none;
    color: #F8F3EC;
    font-family: 'Cormorant Garamond', serif;
    font-size: 36px;
    font-weight: 700;
    transition: 0.3s ease;
}

.lb-footer-logo span {
    color: #D9B99B;
}

.lb-footer-logo:hover {
    opacity: 0.8;
}

.lb-footer-brand p {
    max-width: 370px;
    margin: 0;
    color: #E7D8C8;
    font-size: 13px;
    line-height: 1.9;
}

.lb-footer-column {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.lb-footer-column h3 {
    margin: 0 0 10px;
    color: #F3E8D8;
    font-family: 'Cormorant Garamond', serif;
    font-size: 23px;
    font-weight: 700;
}

.lb-footer-column a {
    width: fit-content;
    display: block;
    text-decoration: none;
    color: #DCCBBC;
    font-size: 13px;
    transition: 0.3s ease;
}

.lb-footer-column a:hover {
    color: #FFFFFF;
    transform: translateX(4px);
}

.lb-footer-info p {
    max-width: 300px;
    margin: 0;
    color: #DCCBBC;
    font-size: 13px;
    line-height: 1.9;
}

.lb-footer-bottom {
    border-top: 1px solid rgba(248, 243, 236, 0.15);
    padding: 20px 25px;
    text-align: center;
}

.lb-footer-bottom p {
    margin: 0;
    color: #CDBBAA;
    font-size: 12px;
}

@media (max-width: 950px) {

    .lb-footer-container {
        grid-template-columns: 1fr 1fr;
        gap: 45px;
    }
}

@media (max-width: 600px) {

    .lb-footer {
        margin-top: 60px;
    }

    .lb-footer-container {
        grid-template-columns: 1fr;
        padding: 45px 25px;
        gap: 35px;
    }

    .lb-footer-brand p,
    .lb-footer-info p {
        max-width: 100%;
    }

    .lb-footer-logo {
        font-size: 32px;
    }
}

</style>


<footer class="lb-footer">

    <div class="lb-footer-container">

        <!-- BRAND -->

        <div class="lb-footer-brand">

            <a href="<?= $home_link ?>" class="lb-footer-logo">
                Linglung<span>Books</span>
            </a>

            <p>
                Temukan buku favoritmu dan nikmati pengalaman
                membaca yang lebih menyenangkan bersama
                LinglungBooks.
            </p>

        </div>


        <!-- NAVIGASI -->

        <div class="lb-footer-column">

            <h3>Navigasi</h3>

            <a href="<?= $home_link ?>">
                Beranda
            </a>

            <a href="<?= $books_link ?>">
                Semua Buku
            </a>

            <a href="<?= $about_link ?>">
                Tentang Kami
            </a>

            <a href="<?= $contact_link ?>">
                Hubungi Kami
            </a>

        </div>


        <!-- BELANJA & AKUN -->

        <div class="lb-footer-column">

            <h3>Belanja &amp; Akun</h3>

            <?php if ($is_logged_in): ?>

                <a href="<?= $cart_link ?>">
                    Keranjang
                </a>

                <a href="<?= $orders_link ?>">
                    Pesanan Saya
                </a>

                <a href="<?= $messages_link ?>">
                    Pesan Saya
                </a>

                <a href="<?= $logout_link ?>">
                    Keluar
                </a>

            <?php else: ?>

                <a href="<?= $login_link ?>">
                    Login
                </a>

                <a href="<?= $register_link ?>">
                    Daftar
                </a>

            <?php endif; ?>

        </div>


        <!-- TENTANG LINGLUNGBOOKS -->

        <div class="lb-footer-column lb-footer-info">

            <h3>LinglungBooks</h3>

            <p>
                Platform toko buku online yang membantu kamu
                menemukan berbagai cerita, pengetahuan, dan
                bacaan favorit dalam satu tempat.
            </p>

        </div>

    </div>


    <!-- COPYRIGHT -->

    <div class="lb-footer-bottom">

        <p>
            &copy; <?= date('Y'); ?> LinglungBooks. All rights reserved.
        </p>

    </div>

</footer>