<?php

if (session_status() === PHP_SESSION_NONE) {
    session_name('LINGLUNG_USER');
    session_start();
}


/* =========================================================
   STATUS LOGIN
========================================================= */

if (isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') !== 'user') {
    unset($_SESSION['user_id'], $_SESSION['fullname'], $_SESSION['username'], $_SESSION['role']);
}
$is_logged_in = isset($_SESSION['user_id']) && ($_SESSION['role'] ?? '') === 'user';


/* =========================================================
   HALAMAN AKTIF
========================================================= */

$current_page = basename($_SERVER['PHP_SELF']);


/* =========================================================
   HALAMAN SEBELUMNYA
========================================================= */

$back = $_GET['back'] ?? '';

if ($back === '') {
    $back = $is_logged_in ? 'dashboard.php' : '../index.php';
}


/* =========================================================
   NORMALISASI BACK DARI ROOT INDEX
========================================================= */

$back_path = parse_url($back, PHP_URL_PATH);

if ($back_path !== null) {

    $normalized_back_path = str_replace('\\', '/', $back_path);

    /*
     * Kalau berasal dari index.php root,
     * arahnya harus ../index.php
     */
    if (
        basename($normalized_back_path) === 'index.php'
        &&
        (
            $back === 'index.php'
            ||
            $back === '../index.php'
            ||
            $normalized_back_path === 'index.php'
        )
    ) {
        $back_query = parse_url($back, PHP_URL_QUERY);

        $back = '../index.php';

        if ($back_query !== null && $back_query !== '') {
            $back .= '?' . $back_query;
        }
    }
}


/* =========================================================
   VALIDASI BACK
========================================================= */

$allowed_back_pages = [
    'dashboard.php',
    'books.php',
    'about.php',
    'contact.php',
    'messages.php',
    'cart.php',
    'checkout.php',
    'orders.php',
    'wishlist.php',
    'order_detail.php',
    'detail.php',
    'profile.php',
    'login.php',
    'register.php'
];

$back_path = parse_url($back, PHP_URL_PATH);

$normalized_back_path = str_replace(
    '\\',
    '/',
    $back_path ?? ''
);


/* ROOT INDEX */

$is_root_index = (
    $back === '../index.php'
    ||
    $normalized_back_path === '../index.php'
);


/* HALAMAN USER */

$is_user_page = (
    strpos($back, '://') === false
    &&
    strpos($back, '//') !== 0
    &&
    strpos($back, '..') === false
    &&
    in_array(
        basename($normalized_back_path),
        $allowed_back_pages,
        true
    )
);


/* JIKA TIDAK AMAN */

if (!$is_root_index && !$is_user_page) {

    $back = $is_logged_in
        ? 'dashboard.php'
        : '../index.php';
}


/* =========================================================
   LINK BERANDA
========================================================= */

if ($back === '../index.php') {

    /*
     * Kalau halaman ini dibuka dari Index,
     * Beranda kembali ke Index.
     */
    $home_link = '../index.php';

} else {

    /*
     * Kalau halaman ini dibuka dari halaman user,
     * Beranda menuju Dashboard.
     */
    $home_link = 'dashboard.php';
}


/* =========================================================
   URL HALAMAN SAAT INI
   HANYA HALAMAN SAAT INI.
   BACK LAMA TIDAK IKUT DIBAWA.
========================================================= */

$current_url = basename($_SERVER['PHP_SELF']);

$current_query = $_SERVER['QUERY_STRING'] ?? '';

if ($current_query !== '') {

    parse_str($current_query, $query_params);

    /*
     * Hapus back lama.
     *
     * Kita hanya ingin halaman yang SEKARANG dibuka
     * menjadi back untuk halaman berikutnya.
     */
    unset($query_params['back']);

    if (!empty($query_params)) {
        $current_url .= '?' . http_build_query($query_params);
    }
}


/* =========================================================
   LINK NAVBAR
========================================================= */

$back_for_link = urlencode($current_url);

$books_link = 'books.php?back=' . $back_for_link;

$about_link = 'about.php?back=' . $back_for_link;

$contact_link = 'contact.php?back=' . $back_for_link;

$messages_link = 'messages.php?back=' . $back_for_link;

$cart_link = 'cart.php?back=' . $back_for_link;

$orders_link = 'orders.php?back=' . $back_for_link;

$wishlist_link = 'wishlist.php?back=' . $back_for_link;

$profile_link = 'profile.php';

$login_link = 'login.php?back=' . $back_for_link;

$register_link = 'register.php?back=' . $back_for_link;

$logout_link = 'logout.php';

?>


<link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
>


<style>

/* Hilangkan ruang putih bawaan browser di atas navbar pada semua halaman */
html,
body {
    margin: 0 !important;
    padding: 0 !important;
}


.lb-navbar {
    display: block !important;
    width: 100% !important;
    background: #F8F3EC;
    border-bottom: 1px solid rgba(75, 54, 33, 0.12);
    position: relative;
    z-index: 1000;
    font-family: 'Poppins', sans-serif;
    margin: 0 !important;
    padding: 0 !important;
    float: none !important;
}

.lb-navbar > .lb-nav-container {
    width: 100% !important;
    max-width: 1450px !important;
    margin: 0 auto !important;
    padding: 18px 35px !important;
    display: flex !important;
    align-items: center !important;
    justify-content: initial !important;
    gap: 38px !important;
    float: none !important;
    box-sizing: border-box !important;
}

.lb-logo {
    text-decoration: none;
    color: #4B3621;
    font-family: 'Cormorant Garamond', serif;
    font-size: 35px;
    font-weight: 700;
    white-space: nowrap;
    flex-shrink: 0;
    transition: 0.3s ease;
}

.lb-logo span {
    color: #8B5E3C;
}

.lb-logo:hover {
    opacity: 0.75;
}

.lb-navbar .lb-nav-menu {
    display: flex;
    align-items: center;
    gap: 30px;
    flex: 1;
}

.lb-nav-text {
    position: relative;
    display: flex;
    align-items: center;
    text-decoration: none;
    color: #4B3621;
    font-size: 14px;
    font-weight: 500;
    white-space: nowrap;
    padding: 10px 0;
    transition: 0.3s ease;
}

.lb-nav-text:hover {
    color: #8B5E3C;
}

.lb-nav-text.active {
    color: #8B5E3C;
    font-weight: 600;
}

.lb-nav-text.active::after {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 2px;
    background: #8B5E3C;
    border-radius: 10px;
}

.lb-nav-icon {
    position: relative;
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
    color: #4B3621;
    border-radius: 10px;
    transition: 0.3s ease;
}

.lb-nav-icon i {
    font-size: 18px;
}

.lb-nav-icon:hover,
.lb-nav-icon.active {
    background: #F3E8D8;
    color: #8B5E3C;
}

.lb-nav-icon::after {
    content: attr(data-tooltip);
    position: absolute;
    top: 50px;
    left: 50%;
    transform: translateX(-50%);
    background: #4B3621;
    color: #FFFFFF;
    padding: 6px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 400;
    font-family: 'Poppins', sans-serif;
    white-space: nowrap;
    opacity: 0;
    pointer-events: none;
    transition: 0.2s ease;
}

.lb-nav-icon:hover::after {
    opacity: 1;
}

.lb-navbar .lb-nav-account {
    display: flex;
    align-items: center;
    gap: 14px;
    flex-shrink: 0;
    white-space: nowrap;
}

.lb-profile-link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    min-height: 40px;
    padding: 8px 11px;
    border: 1px solid #D8C3AD;
    border-radius: 9px;
    color: #6F4E37;
    background: #FFFDF9;
    text-decoration: none;
    font-size: 13px;
    font-weight: 600;
    transition: .25s ease;
}

.lb-profile-link:hover,
.lb-profile-link.active {
    background: #F3E8D8;
    border-color: #8B5E3C;
    color: #4B3621;
}

.lb-user-name {
    max-width: 170px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: #4B3621;
    font-size: 13px;
    font-weight: 500;
}

.lb-login {
    text-decoration: none;
    color: #6F4E37;
    font-size: 14px;
    font-weight: 600;
    padding: 10px 5px;
    white-space: nowrap;
    transition: 0.3s ease;
}

.lb-login:hover {
    color: #4B3621;
}

.lb-register {
    text-decoration: none;
    background: #6F4E37;
    color: #FFFFFF;
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    transition: 0.3s ease;
}

.lb-register:hover {
    background: #4B3621;
}

.lb-logout {
    text-decoration: none;
    color: #8B5E3C;
    border: 1px solid #8B5E3C;
    padding: 9px 17px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    white-space: nowrap;
    transition: 0.3s ease;
}

.lb-logout:hover {
    background: #8B5E3C;
    color: #FFFFFF;
}

@media (max-width: 1200px) {

    .lb-nav-container {
        padding: 17px 25px;
        gap: 25px;
    }

    .lb-navbar .lb-nav-menu {
        gap: 20px;
    }

    .lb-nav-text {
        font-size: 13px;
    }

    .lb-user-name {
        display: inline;
        max-width: 110px;
    }

    .lb-profile-link {
        padding: 8px;
    }

    .lb-profile-label {
        display: none;
    }
}

@media (max-width: 950px) {

    .lb-nav-container {
        flex-wrap: wrap;
        justify-content: center;
        gap: 15px;
    }

    .lb-logo {
        width: 100%;
        text-align: center;
    }

    .lb-navbar .lb-nav-menu {
        width: 100%;
        justify-content: center;
        flex-wrap: wrap;
        gap: 18px;
    }

    .lb-navbar .lb-nav-account {
        justify-content: center;
    }
}

@media (max-width: 600px) {

    .lb-nav-container {
        padding: 15px;
    }

    .lb-logo {
        font-size: 30px;
    }

    .lb-navbar .lb-nav-menu {
        gap: 12px;
    }

    .lb-nav-text {
        font-size: 12px;
    }

    .lb-nav-icon {
        width: 38px;
        height: 38px;
    }

    .lb-nav-icon i {
        font-size: 15px;
    }

    .lb-login {
        font-size: 12px;
    }

    .lb-register,
    .lb-logout {
        font-size: 12px;
        padding: 8px 12px;
    }
}


/* Navbar mengikuti posisi Dashboard dan profil memakai avatar bulat */
.lb-navbar > .lb-nav-container {
    width: calc(100% - 48px) !important;
    max-width: 1360px !important;
    min-height: 82px;
    margin: 0 auto !important;
    padding: 12px 0 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    gap: 28px !important;
    box-sizing: border-box !important;
}
.lb-navbar .lb-logo { flex: 0 0 auto; }
.lb-navbar .lb-nav-menu {
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex: 0 1 auto;
    gap: 30px !important;
    white-space: nowrap;
}
.lb-navbar .lb-nav-account {
    display: flex !important;
    align-items: center !important;
    justify-content: flex-end !important;
    flex: 0 0 auto;
    margin-left: auto;
}
.lb-navbar .lb-profile-link {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 10px !important;
    padding: 4px 0 !important;
    border: 0 !important;
    border-radius: 0 !important;
    background: transparent !important;
    color: #4B3621 !important;
    text-decoration: none !important;
    max-width: 300px;
}
.lb-navbar .lb-profile-link:hover,
.lb-navbar .lb-profile-link.active { color: #8B5E3C !important; }
.lb-navbar .lb-profile-avatar {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    flex: 0 0 42px;
    width: 42px;
    height: 42px;
    border-radius: 50%;
    background: #6F4E37 !important;
    color: #FFFFFF !important;
    font-size: 19px;
    box-shadow: 0 5px 14px rgba(75,54,33,.12);
}
.lb-navbar .lb-profile-avatar i { color: #FFFFFF !important; }
.lb-navbar .lb-user-name {
    display: inline-block !important;
    max-width: 220px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: inherit;
    font-family: 'Poppins', sans-serif;
    font-size: 14px;
    font-weight: 500;
}
.lb-navbar .lb-profile-label { display: none !important; }
@media (max-width: 1200px) {
    .lb-navbar > .lb-nav-container {
        width: calc(100% - 36px) !important;
        gap: 20px !important;
    }
    .lb-navbar .lb-nav-menu { gap: 18px !important; }
    .lb-navbar .lb-user-name { max-width: 160px; }
}
@media (max-width: 950px) {
    .lb-navbar > .lb-nav-container {
        width: calc(100% - 30px) !important;
        flex-wrap: wrap;
        justify-content: center !important;
        gap: 14px !important;
    }
    .lb-navbar .lb-logo { width: auto; text-align: center; }
    .lb-navbar .lb-nav-menu {
        width: 100%;
        order: 3;
        flex-wrap: wrap;
        gap: 16px !important;
    }
    .lb-navbar .lb-nav-account { margin-left: 0; }
}
@media (max-width: 600px) {
    .lb-navbar > .lb-nav-container {
        width: calc(100% - 24px) !important;
        padding: 12px 0 !important;
    }
    .lb-navbar .lb-logo { font-size: 29px; }
    .lb-navbar .lb-nav-menu { gap: 10px !important; }
    .lb-navbar .lb-user-name { max-width: 135px; font-size: 12px; }
    .lb-navbar .lb-profile-avatar {
        flex-basis: 36px; width: 36px; height: 36px; font-size: 16px;
    }
}

</style>


<nav class="lb-navbar">

    <div class="lb-nav-container">


        <!-- LOGO -->

        <a
            href="<?= htmlspecialchars($home_link, ENT_QUOTES, 'UTF-8'); ?>"
            class="lb-logo"
        >
            Linglung<span>Books</span>
        </a>


        <!-- MENU -->

        <div class="lb-nav-menu">


            <!-- BERANDA -->

            <a
                href="<?= htmlspecialchars($home_link, ENT_QUOTES, 'UTF-8'); ?>"
                class="lb-nav-text <?= (
                    $current_page === 'dashboard.php'
                ) ? 'active' : ''; ?>"
            >
                Beranda
            </a>


            <!-- BUKU -->

            <a
                href="<?= htmlspecialchars($books_link, ENT_QUOTES, 'UTF-8'); ?>"
                class="lb-nav-text <?= (
                    $current_page === 'books.php' ||
                    $current_page === 'detail.php'
                ) ? 'active' : ''; ?>"
            >
                Buku
            </a>


            <!-- TENTANG -->

            <a
                href="<?= htmlspecialchars($about_link, ENT_QUOTES, 'UTF-8'); ?>"
                class="lb-nav-text <?= (
                    $current_page === 'about.php'
                ) ? 'active' : ''; ?>"
            >
                Tentang Kami
            </a>


            <!-- KONTAK -->

            <a
                href="<?= htmlspecialchars($contact_link, ENT_QUOTES, 'UTF-8'); ?>"
                class="lb-nav-icon <?= (
                    $current_page === 'contact.php'
                ) ? 'active' : ''; ?>"
                data-tooltip="Kontak"
            >
                <i class="fa-solid fa-envelope"></i>
            </a>


            <?php if ($is_logged_in): ?>

                <!-- PESAN -->

                <a
                    href="<?= htmlspecialchars($messages_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-nav-icon <?= (
                        $current_page === 'messages.php'
                    ) ? 'active' : ''; ?>"
                    data-tooltip="Pesan"
                >
                    <i class="fa-solid fa-message"></i>
                </a>


                <!-- WISHLIST -->

                <a
                    href="<?= htmlspecialchars($wishlist_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-nav-icon <?= $current_page === 'wishlist.php' ? 'active' : ''; ?>"
                    data-tooltip="Wishlist"
                    aria-label="Wishlist"
                >
                    <i class="fa-solid fa-heart"></i>
                </a>


                <!-- KERANJANG -->

                <a
                    href="<?= htmlspecialchars($cart_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-nav-icon <?= (
                        $current_page === 'cart.php'
                    ) ? 'active' : ''; ?>"
                    data-tooltip="Keranjang"
                >
                    <i class="fa-solid fa-cart-shopping"></i>
                </a>


                <!-- PESANAN -->

                <a
                    href="<?= htmlspecialchars($orders_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-nav-icon <?= (
                        $current_page === 'orders.php' ||
                        $current_page === 'order_detail.php'
                    ) ? 'active' : ''; ?>"
                    data-tooltip="Pesanan"
                >
                    <i class="fa-solid fa-box"></i>
                </a>

            <?php endif; ?>

        </div>


        <!-- AKUN -->

        <div class="lb-nav-account">

            <?php if ($is_logged_in): ?>

                <a
                    href="<?= htmlspecialchars($profile_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-profile-link <?= $current_page === 'profile.php' ? 'active' : ''; ?>"
                    aria-label="Buka profil pengguna"
                    title="Profil pengguna"
                >
                    <span class="lb-profile-avatar" aria-hidden="true">
                        <i class="fa-solid fa-user"></i>
                    </span>
                    <span class="lb-user-name">
                        <?= htmlspecialchars(
                            $_SESSION['fullname'] ?? 'Pengguna',
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>
                    </span>
                </a>

            <?php else: ?>

                <a
                    href="<?= htmlspecialchars($login_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-login"
                >
                    Login
                </a>

                <a
                    href="<?= htmlspecialchars($register_link, ENT_QUOTES, 'UTF-8'); ?>"
                    class="lb-register"
                >
                    Daftar
                </a>

            <?php endif; ?>

        </div>

    </div>

</nav>