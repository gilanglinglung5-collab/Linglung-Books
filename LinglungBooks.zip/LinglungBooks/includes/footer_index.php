<?php

/* =========================================================
   LINK UNTUK LANDING PAGE
   index.php berada di ROOT
========================================================= */

$home_link     = 'index.php';
$books_link    = 'user/books.php?back=index.php';
$about_link    = 'user/about.php?back=index.php';
$contact_link  = 'user/contact.php?back=index.php';
$login_link    = 'user/login.php?back=index.php';
$register_link = 'user/register.php?back=index.php';

?>

<style>

.lb-footer {
    margin-top: 80px;
    background: #4B3621;
    color: #F8F3EC;
    font-family: 'Poppins', sans-serif;
}

.lb-footer-container {
    max-width: 1350px;
    margin: 0 auto;
    padding: 60px 35px 50px;
    display: grid;
    grid-template-columns: 1.7fr 1fr 1fr 1.2fr;
    gap: 55px;
}

.lb-footer-brand {
    display: flex;
    flex-direction: column;
}

.lb-footer-logo {
    display: inline-block;
    width: fit-content;
    margin-bottom: 16px;
    text-decoration: none;
    color: #F8F3EC;
    font-family: 'Cormorant Garamond', serif;
    font-size: 36px;
    font-weight: 700;
    transition: 0.3s ease;
}

.lb-footer-logo span {
    color: #D9B99B;
}

.lb-footer-logo:hover {
    opacity: 0.8;
}

.lb-footer-brand p {
    max-width: 370px;
    margin: 0;
    color: #E7D8C8;
    font-size: 13px;
    line-height: 1.9;
}

.lb-footer-column {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.lb-footer-column h3 {
    margin: 0 0 10px;
    color: #F3E8D8;
    font-family: 'Cormorant Garamond', serif;
    font-size: 23px;
    font-weight: 700;
}

.lb-footer-column a {
    width: fit-content;
    display: block;
    text-decoration: none;
    color: #DCCBBC;
    font-size: 13px;
    transition: 0.3s ease;
}

.lb-footer-column a:hover {
    color: #FFFFFF;
    transform: translateX(4px);
}

.lb-footer-info p {
    max-width: 300px;
    margin: 0;
    color: #DCCBBC;
    font-size: 13px;
    line-height: 1.9;
}

.lb-footer-bottom {
    border-top: 1px solid rgba(248, 243, 236, 0.15);
    padding: 20px 25px;
    text-align: center;
}

.lb-footer-bottom p {
    margin: 0;
    color: #CDBBAA;
    font-size: 12px;
}

@media (max-width: 950px) {

    .lb-footer-container {
        grid-template-columns: 1fr 1fr;
        gap: 45px;
    }
}

@media (max-width: 600px) {

    .lb-footer {
        margin-top: 60px;
    }

    .lb-footer-container {
        grid-template-columns: 1fr;
        padding: 45px 25px;
        gap: 35px;
    }

    .lb-footer-brand p,
    .lb-footer-info p {
        max-width: 100%;
    }

    .lb-footer-logo {
        font-size: 32px;
    }
}

</style>


<footer class="lb-footer">

    <div class="lb-footer-container">

        <!-- BRAND -->

        <div class="lb-footer-brand">

            <a href="<?= $home_link ?>" class="lb-footer-logo">
                Linglung<span>Books</span>
            </a>

            <p>
                Temukan buku favoritmu dan nikmati pengalaman
                membaca yang lebih menyenangkan bersama
                LinglungBooks.
            </p>

        </div>


        <!-- NAVIGASI -->

        <div class="lb-footer-column">

            <h3>Navigasi</h3>

            <a href="<?= $home_link ?>">
                Beranda
            </a>

            <a href="<?= $books_link ?>">
                Semua Buku
            </a>

            <a href="<?= $about_link ?>">
                Tentang Kami
            </a>

            <a href="<?= $contact_link ?>">
                Hubungi Kami
            </a>

        </div>


        <!-- AKUN -->

        <div class="lb-footer-column">

            <h3>Belanja &amp; Akun</h3>

            <a href="<?= $login_link ?>">
                Login
            </a>

            <a href="<?= $register_link ?>">
                Daftar
            </a>

        </div>


        <!-- TENTANG LINGLUNGBOOKS -->

        <div class="lb-footer-column lb-footer-info">

            <h3>LinglungBooks</h3>

            <p>
                Platform toko buku online yang membantu kamu
                menemukan berbagai cerita, pengetahuan, dan
                bacaan favorit dalam satu tempat.
            </p>

        </div>

    </div>


    <!-- COPYRIGHT -->

    <div class="lb-footer-bottom">

        <p>
            &copy; <?= date('Y'); ?> LinglungBooks. All rights reserved.
        </p>

    </div>

</footer>