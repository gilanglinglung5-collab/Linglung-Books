<?php

session_name('LINGLUNG_USER');
    session_start();

include 'config/database.php';

// Ambil daftar wishlist milik pengguna yang sedang login.
$wishlist_ids = [];
if (isset($_SESSION['user_id'])) {
    $wishlist_user_id = (int) $_SESSION['user_id'];
    $wishlist_result = mysqli_query($conn, "SELECT book_id FROM wishlist WHERE user_id = '$wishlist_user_id'");
    if ($wishlist_result) {
        while ($wishlist_row = mysqli_fetch_assoc($wishlist_result)) {
            $wishlist_ids[] = (int) $wishlist_row['book_id'];
        }
    }
}


/* =========================================================
   URL HALAMAN SAAT INI
========================================================= */

$current_url = basename($_SERVER['PHP_SELF']);

$current_query = $_SERVER['QUERY_STRING'] ?? '';

if ($current_query !== '') {
    $current_url .= '?' . $current_query;
}


/* =========================================================
   FILTER
========================================================= */

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$category_id = isset($_GET['category'])
    ? (int) $_GET['category']
    : 0;

$search_safe = mysqli_real_escape_string(
    $conn,
    $search
);


/* =========================================================
   QUERY 8 BEST SELLER
========================================================= */

$sql = "
    SELECT
        books.*,
        categories.category_name,
        COALESCE(sales.total_sold, 0) AS total_sold
    FROM books
    LEFT JOIN categories
        ON books.category_id = categories.id
    LEFT JOIN (
        SELECT
            order_details.book_id,
            SUM(order_details.quantity) AS total_sold
        FROM order_details
        INNER JOIN orders
            ON order_details.order_id = orders.id
        WHERE LOWER(TRIM(orders.status)) <> 'cancelled'
        GROUP BY order_details.book_id
    ) AS sales
        ON books.id = sales.book_id
    WHERE 1=1
";


/* =========================================================
   SEARCH
========================================================= */

if ($search !== '') {

    $sql .= "
        AND (
            books.title LIKE '%$search_safe%'
            OR books.author LIKE '%$search_safe%'
            OR books.publisher LIKE '%$search_safe%'
            OR categories.category_name LIKE '%$search_safe%'
        )
    ";
}


/* =========================================================
   CATEGORY
========================================================= */

if ($category_id > 0) {

    $sql .= "
        AND books.category_id = $category_id
    ";
}


/* =========================================================
   BEST SELLER
========================================================= */

$sql .= "
    GROUP BY books.id
    HAVING total_sold > 0
    ORDER BY total_sold DESC, books.id DESC
    LIMIT 8
";


$query = mysqli_query(
    $conn,
    $sql
);


/* =========================================================
   QUERY KATEGORI
========================================================= */

$categories = mysqli_query(
    $conn,
    "
    SELECT
        id,
        category_name,
        icon
    FROM categories
    ORDER BY category_name ASC
    "
);

?>

<!DOCTYPE html>

<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>LinglungBooks</title>


    <!-- GOOGLE FONT -->

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Cormorant+Garamond:wght@600;700&display=swap"
        rel="stylesheet"
    >


    <!-- FONT AWESOME -->

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    >


    <!-- CSS USER -->

    <link
        rel="stylesheet"
        href="assets/css/user.css"
    >


    <!-- CSS KHUSUS INDEX -->

    <link
        rel="stylesheet"
        href="assets/css/index.css"
    >

<style>
.wishlist-card-btn{grid-column:1 / -1;width:100%;min-height:42px;margin:0 0 2px;border:1.5px solid #ead4bd;border-radius:10px;background:#fff;color:#8b5e3c;display:flex;align-items:center;justify-content:center;gap:9px;font-weight:700;cursor:pointer;transition:.2s}
.wishlist-card-btn:hover{background:#fbf4ec;transform:translateY(-1px)}.wishlist-card-btn.active{color:#e53955;border-color:#e9aab5;background:#fff6f7}.wishlist-card-btn i{font-size:16px}
</style>
    <link rel="stylesheet" href="assets/css/enhancements.css">
    <link rel="stylesheet" href="assets/css/book-cards-shared.css?v=3">
</head>


<body>


<?php include 'includes/navbar_index.php'; ?>


<!-- =========================================================
     HERO
========================================================= -->

<section class="hero">

    <div class="hero-text">

        <h1>
            Temukan Cerita yang Selalu Berkesan.
        </h1>

        <p>
            Selamat datang di LinglungBooks, toko buku online
            elegan tempat setiap halaman membuka petualangan baru.
        </p>

        <a
            href="#categories"
            class="explore"
        >
            Jelajahi Kategori
        </a>

    </div>

</section>


<!-- =========================================================
     KATEGORI
========================================================= -->

<section
    class="categories"
    id="categories"
>

    <h2>
        Jelajahi Berdasarkan Kategori
    </h2>

    <p class="subtitle">
        Pilih kategori buku favoritmu.
    </p>


    <div class="category-container">

        <?php if (
            $categories &&
            mysqli_num_rows($categories) > 0
        ): ?>

            <?php while (
                $category = mysqli_fetch_assoc($categories)
            ): ?>

                <?php

                $icon = !empty($category['icon'])
                    ? $category['icon']
                    : 'fa-tags';

                ?>

                <a
                    href="index.php?category=<?= (int) $category['id']; ?>#books"
                    class="category-card"
                >

                    <i
                        class="fa-solid <?= htmlspecialchars(
                            $icon,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                    ></i>

                    <h3>
                        <?= htmlspecialchars(
                            $category['category_name'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>
                    </h3>

                </a>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-book">

                <i class="fa-solid fa-tags"></i>

                <h3>
                    Belum Ada Kategori
                </h3>

                <p>
                    Kategori buku belum tersedia.
                </p>

            </div>

        <?php endif; ?>

    </div>

</section>


<!-- =========================================================
     BEST SELLER
========================================================= -->

<section
    class="featured"
    id="books"
>

    <h2>
        Buku Best Seller
    </h2>

    <p class="subtitle">
        Temukan buku yang paling banyak dipilih oleh pembaca.
    </p>


    <!-- SEARCH -->

    <form
        method="GET"
        class="search-form"
    >

        <input
            type="text"
            name="search"
            placeholder="Cari buku atau penulis..."
            value="<?= htmlspecialchars(
                $search,
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
        >

        <?php if ($category_id > 0): ?>

            <input
                type="hidden"
                name="category"
                value="<?= $category_id; ?>"
            >

        <?php endif; ?>

        <button type="submit">
            Cari
        </button>

    </form>


    <!-- BOOK GRID -->

    <div class="book-container">

        <?php if (
            $query &&
            mysqli_num_rows($query) > 0
        ): ?>

            <?php while (
                $book = mysqli_fetch_assoc($query)
            ): ?>

                <article class="book-card">


                    <!-- COVER -->

                    <div class="book-cover-wrapper">
<?php if (
                            !empty($book['cover'])
                        ): ?>

                            <img
                                src="assets/img/<?= htmlspecialchars(
                                    $book['cover'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                alt="<?= htmlspecialchars(
                                    $book['title'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                class="book-cover"
                                loading="lazy"
                            >

                        <?php else: ?>

                            <div class="book-cover-placeholder">

                                <i class="fa-solid fa-book"></i>

                            </div>

                        <?php endif; ?>

                    </div>


                    <!-- INFO -->

                    <div class="book-info">


                        <!-- CATEGORY -->

                        <div class="book-category">

                            <?= htmlspecialchars(
                                $book['category_name'] ??
                                'Tanpa Kategori',
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- TITLE -->

                        <div class="book-title">

                            <?= htmlspecialchars(
                                $book['title'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- AUTHOR -->

                        <div class="book-author">

                            Oleh

                            <?= htmlspecialchars(
                                $book['author'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>

                        </div>


                        <!-- PRICE -->

                        <div class="book-price">

                            Rp

                            <?= number_format(
                                $book['price'],
                                0,
                                ',',
                                '.'
                            ); ?>

                        </div>


                        <!-- STOCK -->

                        <?php if (
                            (int) $book['stock'] > 0
                        ): ?>

                            <div class="stock available">

                                Stok tersedia:

                                <?= (int) $book['stock']; ?>

                            </div>

                        <?php else: ?>

                            <div class="stock empty">

                                Stok habis

                            </div>

                        <?php endif; ?>


                        <!-- ACTIONS -->

                        <div class="book-actions">

                            <button type="button" class="wishlist-card-btn <?= in_array((int) $book['id'], $wishlist_ids, true) ? 'active' : ''; ?>"
                                data-book-id="<?= (int) $book['id']; ?>"
                                data-logged-in="<?= isset($_SESSION['user_id']) ? '1' : '0'; ?>"
                                data-login-url="user/login.php?back=<?= urlencode($current_url); ?>">
                                <i class="fa-<?= in_array((int) $book['id'], $wishlist_ids, true) ? 'solid' : 'regular'; ?> fa-heart"></i>
                                <span><?= in_array((int) $book['id'], $wishlist_ids, true) ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist'; ?></span>
                            </button>

                            <!-- DETAIL -->

                            <a
                                href="user/login.php?back=<?= urlencode($current_url); ?>"
                                class="detail-button"
                            >

                                <i class="fa-solid fa-eye"></i>

                                Detail

                            </a>


                            <!-- CART -->

                            <?php if (
                                (int) $book['stock'] > 0
                            ): ?>

                                <a
                                    href="user/login.php?back=<?= urlencode($current_url); ?>"
                                    class="cart-button"
                                >

                                    <i class="fa-solid fa-cart-plus"></i>

                                    Keranjang

                                </a>

                            <?php else: ?>

                                <span
                                    class="cart-button"
                                    style="
                                        background:#D5D0CA;
                                        color:#888;
                                        cursor:not-allowed;
                                    "
                                >

                                    <i class="fa-solid fa-ban"></i>

                                    Habis

                                </span>

                            <?php endif; ?>


                        </div>

                    </div>

                </article>

            <?php endwhile; ?>

        <?php else: ?>

            <div class="empty-book">

                <i class="fa-solid fa-book-open"></i>

                <h3>
                    Belum Ada Buku Best Seller
                </h3>

                <p>
                    Buku Best Seller akan muncul otomatis setelah ada pesanan yang tercatat.
                    Pesanan yang dibatalkan tidak dihitung.
                </p>

            </div>

        <?php endif; ?>

    </div>


    <!-- LIHAT SEMUA -->

    <div class="see-all-container">

        <a
            href="user/books.php?back=<?= urlencode('../index.php'); ?>"
            class="see-all-btn"
        >

            Lihat Semua Buku

            <i class="fa-solid fa-arrow-right"></i>

        </a>

    </div>

</section>


<?php include 'includes/footer_index.php'; ?>


<script>
document.querySelectorAll('.wishlist-card-btn').forEach(button => {
    button.addEventListener('click', async () => {
        if (button.dataset.loggedIn !== '1') { window.location.href = button.dataset.loginUrl; return; }
        const body = new URLSearchParams({book_id: button.dataset.bookId});
        try {
            const response = await fetch('user/wishlist_toggle.php', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body});
            const result = await response.json();
            if (result.login) { window.location.href = button.dataset.loginUrl; return; }
            if (!result.success) { alert(result.message || 'Wishlist gagal diperbarui.'); return; }
            button.classList.toggle('active', result.active);
            button.querySelector('i').className = (result.active ? 'fa-solid' : 'fa-regular') + ' fa-heart';
            button.querySelector('span').textContent = result.active ? 'Hapus dari Wishlist' : 'Tambah ke Wishlist';
        } catch (error) { alert('Tidak dapat menghubungi server. Coba lagi.'); }
    });
});
</script>
    <script src="assets/js/enhancements.js" defer></script>
</body>

</html>