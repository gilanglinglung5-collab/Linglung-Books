-- Jalankan satu kali pada database linglung_books sebelum memakai revisi ini.
USE linglung_books;

ALTER TABLE users
  ADD COLUMN phone VARCHAR(20) NULL AFTER password,
  ADD COLUMN address TEXT NULL AFTER phone;

ALTER TABLE orders
  MODIFY COLUMN status ENUM(
    'Processing','Packed','Shipped','Received','Completed',
    'ReturnRequested','ReturnApproved','ReturnRejected','ReturnShipped',
    'Returned','Refunded','Cancelled'
  ) NOT NULL DEFAULT 'Processing',
  ADD COLUMN return_status VARCHAR(30) NULL DEFAULT NULL,
  ADD COLUMN return_proof VARCHAR(255) NULL,
  ADD COLUMN return_note TEXT NULL,
  ADD COLUMN return_admin_note TEXT NULL,
  ADD COLUMN return_requested_at DATETIME NULL,
  ADD COLUMN return_received_at DATETIME NULL,
  ADD COLUMN refund_status VARCHAR(30) NULL DEFAULT NULL,
  ADD COLUMN refund_note TEXT NULL;

-- Pesanan lama dan status lama tetap dipertahankan.
-- Akun yang sudah ada dapat mengisi phone dan address melalui Profil Saya.
