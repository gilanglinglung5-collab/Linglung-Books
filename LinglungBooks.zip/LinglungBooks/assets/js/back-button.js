/* Samakan tombol kembali: satu kotak bertuliskan "Kembali" di bawah navbar. */
document.addEventListener('DOMContentLoaded', function () {
    const selectors = [
        'a.detail-back', 'a.about-back', 'a.checkout-back', 'a.messages-back',
        'a.cart-back', 'a.books-back', 'a.contact-back', 'a.register-back',
        'a.login-back', 'a.back-button', 'a.back-btn', 'a.btn-back',
        'a.back', 'a.receipt-btn-secondary', '.header > a.btn',
        '.header > a.back-btn'
    ];

    const candidates = Array.from(document.querySelectorAll(selectors.join(',')))
        .filter(function (el) {
            return el.textContent.trim().length > 0 && !el.classList.contains('global-back-button');
        });

    if (!candidates.length) return;

    const back = candidates[0];
    back.classList.add('global-back-button');
    back.textContent = 'Kembali';

    // Tempatkan sesudah navbar jika tersedia, bukan di atas navbar.
    const navbar = document.querySelector(
        'nav.lb-navbar, nav.navbar, header.navbar, .navbar'
    );
    const wrapper = document.createElement('div');
    wrapper.className = 'global-back-wrap';
    wrapper.appendChild(back);

    if (navbar) {
        navbar.insertAdjacentElement('afterend', wrapper);
    } else {
        // Halaman tanpa navbar: letakkan sebelum konten/header utama.
        const content = document.querySelector(
            'main, .container, .login-container, .register-container, .content, .main-content'
        );
        if (content && content.parentNode) {
            content.parentNode.insertBefore(wrapper, content);
        } else {
            document.body.insertBefore(wrapper, document.body.firstChild);
        }
    }

    // Hilangkan tombol kembali duplikat yang sebelumnya berada di bagian bawah.
    candidates.slice(1).forEach(function (el) {
        if (el.classList.contains('bottom-btn') || el.closest('.bottom-actions')) {
            el.remove();
        }
    });
});
