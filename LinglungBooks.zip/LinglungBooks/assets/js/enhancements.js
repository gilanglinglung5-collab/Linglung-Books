(() => {
  // Preview gambar untuk form upload; fitur tambahan lain sengaja tidak diaktifkan.
  document.querySelectorAll('input[type=\"file\"]').forEach(input => {
    input.addEventListener('change', () => {
      const file = input.files && input.files[0];
      if (!file || !file.type.startsWith('image/')) return;
      let wrap = input.parentElement.querySelector('.lb-preview-wrap');
      if (!wrap) { wrap = document.createElement('div'); wrap.className = 'lb-preview-wrap'; input.insertAdjacentElement('afterend', wrap); }
      wrap.innerHTML = '';
      const img = document.createElement('img'); img.alt = 'Preview gambar'; img.src = URL.createObjectURL(file); wrap.appendChild(img);
      const label = document.createElement('span'); label.textContent = file.name; wrap.appendChild(label);
    });
  });
})();
